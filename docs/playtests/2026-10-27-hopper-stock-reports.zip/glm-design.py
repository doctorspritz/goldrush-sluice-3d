from pathlib import Path
import subprocess,json,os,time,signal
r=Path(__file__).parent
prompt='''Design one bounded next implementation step for a realistic placer-gold mining game: excessively wet clay-rich pay can bridge a hopper outlet or blind a shaker screen. Give a minimal conserved-state model, measurable inputs/parameters, the physical conditions for forming and releasing a blockage, save/reload state, and discriminating tests. Keep mineral mass, gold and water explicitly conserved; do not use an arbitrary recovery multiplier or universal wetness penalty. Distinguish reference bulk inventory from solid volume, free water and compaction. State what requires empirical calibration and which claims a simple model cannot establish. Avoid pretending that numerical solver refusal is physical clogging. Preserve accurate particle-based wet sluice/riffle simulation downstream. No codebase access is available or needed: this is a generic design exercise, not a code review. Do not use tools, browse, run processes, edit files, contact others or ask questions. Return a practical design in at most600words, with one clearly scoped implementation slice and3-5meaningful tests.'''
(r/'glm-design-prompt.txt').write_text(prompt)
# No repository cwd, attachments, code, source paths or project context are sent.
config={'permission':{'*':'deny'},'agent':{'plan':{'steps':1}}};env={**os.environ,'OPENCODE_CONFIG_CONTENT':json.dumps(config)}
args=['opencode','run','--model','zai-coding-plan/glm-5.3','--agent','plan','--format','json','--title','Generic wet hopper design',prompt];begin=time.monotonic()
with (r/'glm-design-events.jsonl').open('xb') as out,(r/'glm-design.stderr').open('xb') as err:
 child=subprocess.Popen(args,stdout=out,stderr=err,env=env,cwd='/private/tmp',start_new_session=True)
 try:exitcode=child.wait(timeout=150)
 except subprocess.TimeoutExpired:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  exitcode=124
texts=[];usage=[];errors=[]
for line in (r/'glm-design-events.jsonl').read_text().splitlines():
 try:j=json.loads(line)
 except ValueError:continue
 if j.get('type')=='text':texts.append(j.get('part',{}).get('text',''))
 if j.get('type')=='step_finish':usage.append(j.get('part',{}))
 if j.get('type')=='error':errors.append(j)
(r/'glm-design.md').write_text('\n\n'.join(texts));result={'model':'zai-coding-plan/glm-5.3','exit':exitcode,'wall_seconds':time.monotonic()-begin,'response_text':bool(texts),'usage':usage,'errors':errors,'scope':'Generic design prompt only, no source files or repository context; all tools denied.'};(r/'glm-design.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print('\n\n'.join(texts)[:5000])
