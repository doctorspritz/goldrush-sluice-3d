from pathlib import Path
import subprocess,json,os,re,sys
r=Path(__file__).parent;label=sys.argv[1];args=sys.argv[2:];parents={int(a):int(b) for a,b in (x.split() for x in subprocess.check_output(['ps','-axo','pid=,ppid='],text=True).splitlines())};heavy={}
for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines():
 a=line.strip().split(None,1)
 if len(a)==2 and Path(a[1]).name in ['cargo','rustc','mining','chrome-headless-shell','tailings-replay']:heavy[int(a[0])]=Path(a[1]).name
for line in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
 a=line.strip().split(None,1)
 if len(a)==2 and re.search(r'(vitest|playwright[^ ]* test|next[ /]build|storybook)',a[1]) and re.match(r'\S*(node|npm|pnpm|npx)( |$)',a[1]):heavy[int(a[0])]='node-heavy'
roots=[]
for pid,name in heavy.items():
 parent=parents.get(pid,0);seen=set();child=False
 while parent and parent not in seen:
  if parent in heavy:child=True;break
  seen.add(parent);parent=parents.get(parent,0)
 if not child:roots.append({'pid':pid,'name':name})
(r/(label+'-existing-jobs.json')).write_text(json.dumps(roots,indent=2));assert len(roots)<2,roots
env={**os.environ,'CARGO_TARGET_DIR':'/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target','SLUICE_TARGET_DIR':'/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target','SLUICE_BUILD_JOBS':'1','SLUICE_SAVE_PATH':str(r/(label+'-unused.json'))}
p=subprocess.run(['python3',str(r/'supervise.py'),'--seconds','300','--log',str(r/(label+'.log')),'--',*args],env=env);sys.exit(p.returncode)
