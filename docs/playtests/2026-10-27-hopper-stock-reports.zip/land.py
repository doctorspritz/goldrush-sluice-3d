from pathlib import Path
import subprocess,json,hashlib,zipfile
w=Path.cwd();r=Path(__file__).parent;s=json.loads((r/'start.json').read_text());receipt=json.loads((r/'receipt.json').read_text());commands=[]
def run(*args,input=None):
 p=subprocess.run(args,input=input,capture_output=True,text=True);commands.append({'args':list(args),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(r/'landing-commands.json').write_text(json.dumps(commands,indent=2));p.check_returncode();return p.stdout.rstrip('\n')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='docs/playtests/2026-10-27-hopper-stock'
files=['.beads/issues.jsonl',*receipt['changed_sources'],*receipt['new_sources'],'docs/physics/plant-screen.md','plans/2026-10-22-realistic-operation.md',*[prefix+q for q in ['.md','.json','-reports.zip','-comparison.jpg','-levels.jpg','-motion.mp4']]]
fingerprints={n:h(w/n) for n in files};(r/'final-file-manifest.json').write_text(json.dumps(fingerprints,indent=2))
def custody():
 assert len(receipt['source_manifest'])==765 and all(h(w/n)==v for n,v in receipt['source_manifest'].items())
 assert all(h(w/n)==v for n,v in fingerprints.items())
 original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose')
 assert all(h(original/n)==v for n,v in s['original_files'].items())
 assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==s['stash']
 assert not receipt['installation']['performed']
 assert h(Path(receipt['installation']['installed_executable']))==s['app_sha256']==receipt['installation']['installed_executable_sha256']
 assert h(Path(receipt['installation']['candidate'])/'Contents/MacOS/mining')==receipt['installation']['candidate_executable_sha256']
 assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes'])
 assert (r/'receipt.json').read_bytes()==(w/(prefix+'.json')).read_bytes()
 old=(r/'issues-before.jsonl').read_bytes();new=(w/'.beads/issues.jsonl').read_bytes();owned=json.loads((r/'owned-tracker-rows.json').read_text())
 assert len(old.splitlines())==len(new.splitlines())==262 and len(owned)==2
 assert [x for x in old.splitlines(keepends=True) if json.loads(x)['id'] not in owned]==[x for x in new.splitlines(keepends=True) if json.loads(x)['id'] not in owned]
 assert {j['id']:j for line in new.splitlines() if (j:=json.loads(line))['id'] in owned}==owned
 assert all(j['status']=='in_progress' for j in owned.values())
 assert len(receipt['quality'])==4 and all(j['exit']==0 for j in receipt['quality']) and receipt['focused_checks']['app']==82
 assert all(j['passed'] for j in receipt['native']['reports'].values())
 assert all(receipt['native']['frozen_physical_fields_exact'].values())
 assert receipt['video']['passed'] and receipt['native']['rgb_comparison']['changed_pixels']>0
 assert len(receipt['native_checks'])==8 and receipt['native']['reports']['candidate-motion']['hopper_last']['gravel_m3'] < receipt['native']['reports']['candidate-motion']['hopper_first']['gravel_m3']
 assert all(receipt['source_manifest'][n]==v for n,v in s['sources'].items() if n.startswith(('crates/mining-sim/','crates/mining-physics/','crates/sim3d/','crates/game/')) or n.endswith('.wgsl'))
 assert not receipt['empirically_calibrated'] and not receipt['full_operation_complete'] and receipt['goal_status']=='active'
 assert receipt['benchmark']['bulk_budget_passed'] and receipt['benchmark']['dry_mass_budget_passed'] and receipt['benchmark']['failure'] is None and not receipt['benchmark']['passed']
 assert receipt['preservation']['cleanup']['exit']==0
 with zipfile.ZipFile(w/(prefix+'-reports.zip')) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
  for n in receipt['changed_sources']+receipt['new_sources']:assert z.read('source/'+n)==(w/n).read_bytes()
custody();assert run('git','rev-parse','HEAD')==s['head'];assert run('git','branch','--show-current')=='codex/direct-mining';assert not run('git','diff','--cached','--name-only')
assert {x[3:] for x in run('git','status','--porcelain','-uall').splitlines()}==set(files)
assert run('git','remote','get-url','origin')=='https://github.com/doctorspritz/goldrush-sluice-3d.git'
assert json.loads(run('gh','repo','view','--json','nameWithOwner,isPrivate,viewerPermission'))=={'nameWithOwner':'doctorspritz/goldrush-sluice-3d','isPrivate':False,'viewerPermission':'ADMIN'}
run('git','fetch','--prune','origin');assert run('git','rev-parse','origin/codex/direct-mining')==s['head'],'Remote changed; inspect before landing'
run('git','merge-base','--is-ancestor','origin/main','HEAD');run('git','diff','--check');run('git','add','--',*files)
assert set(run('git','diff','--cached','--name-only').splitlines())==set(files)
run('git','diff','--cached','--check');(r/'staged-stat.txt').write_text(run('git','diff','--cached','--stat'));custody()
# Preserve shared hooks/config. Their tracker-wide export is outside the owned
# rows. Explicit quality gates and allowlisted tree avoid unrelated export;
# no hook/trust/config edit or stash mutation.
tree=run('git','write-tree');message='fix(render): show finite volume in the hopper\n\nReplace the hidden fill ellipsoid with a tapered inventory mesh and an\nabove-rim heap, using shared bowl dimensions and existing filtered soil\ntextures. Support legacy, empty and lower stock; update only on changes.\n\nPass 82 app tests, strict lint, formatting and signed packaging. Review\nactual native before/after, finite levels, legacy and live-feed captures;\npreserve frozen physical fields and all solver/shader source fingerprints.\nNative physics remains below real time; retain installation hold and all\nunfinished realistic operation requirements. Preserve original dirty files,\nstash, installed app and 260 unrelated literal tracker rows.\n';(r/'commit-message.txt').write_text(message)
commit=run('git','commit-tree',tree,'-p',s['head'],input=message);run('git','update-ref','-m','commit: visible finite hopper stock','HEAD',commit,s['head'])
assert not run('git','status','--porcelain','-uall');run('git','pull','--rebase','--prune');assert run('git','rev-parse','HEAD')==commit
run('git','push','origin','HEAD:refs/heads/codex/direct-mining');remote=run('git','ls-remote','origin','refs/heads/codex/direct-mining').split()[0]
assert remote==run('git','rev-parse','@{upstream}')==commit;assert not run('git','status','--porcelain','-uall');custody()
result={'commit':commit,'remote':remote,'all_owned_changes_committed_and_pushed':True,'status':run('git','status','--short','--branch'),'preservation_verified':True,'installation':'held','files':files};(r/'landing.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
