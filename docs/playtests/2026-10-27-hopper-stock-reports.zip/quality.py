from pathlib import Path
import subprocess,json,time,hashlib
r=Path(__file__).parent;w=Path.cwd();jobs=[('app-test',['cargo','+nightly','test','-p','mining','--bin','mining','--profile','playable','--locked','--jobs','1','--','--test-threads=1']),('app-lint',['cargo','+nightly','clippy','-p','mining','--bin','mining','--tests','--profile','playable','--locked','--jobs','1','--no-deps','--','-D','warnings']),('format',['cargo','+nightly','fmt','-p','mining','--','--check']),('package',['bash','scripts/package-mining-macos.sh',str(r/'app')])];results=[]
for label,args in jobs:
 t=time.monotonic();p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);results.append({'label':label,'args':args,'exit':p.returncode,'wall_seconds':time.monotonic()-t});(r/'quality.json').write_text(json.dumps(results,indent=2));print(label,p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-5000:],flush=True);raise SystemExit(p.returncode)
paths=set(subprocess.check_output(['git','ls-files'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines());source={n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in sorted(paths) if n.endswith(('.rs','.wgsl'))};(r/'qualified-sources.json').write_text(json.dumps(source,indent=2))
