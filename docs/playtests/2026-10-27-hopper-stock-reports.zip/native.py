from pathlib import Path
import subprocess,json,time,hashlib,sys
r=Path(__file__).parent;old=r.parent/'screen-throughput-20261027';fixtures=r.parent/'plant-screen-20261027/gpu-fixtures-v8';apps={'reference':old/'app/First Bend.app/Contents/MacOS/mining','candidate':r/'app/First Bend.app/Contents/MacOS/mining'};checks=[]
assert hashlib.sha256(apps['reference'].read_bytes()).hexdigest()==json.loads((old/'receipt.json').read_text())['installation']['candidate_executable_sha256']
assert len(json.loads((r/'quality.json').read_text()))==4 and all(j['exit']==0 for j in json.loads((r/'quality.json').read_text()))
def run(label,variant,source,view,freeze=True,seconds=1,hz=2):
 args=[str(apps[variant]),'--load',str(source),'--capture-motion',str(r/label),'--capture-view',view,'--capture-seconds',str(seconds),'--capture-hz',str(hz)]+(['--freeze'] if freeze else [])
 begin=time.monotonic();p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'variant':variant,'args':args,'exit':p.returncode,'wall_seconds':time.monotonic()-begin});(r/'native-checks.json').write_text(json.dumps(checks,indent=2));print(label,p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-6000:],flush=True);raise SystemExit(p.returncode)
 assert json.loads((r/label/'frames.json').read_text())['passed']
for variant in ['reference','candidate']:run(variant+'-plant',variant,fixtures/'modern.save.json','plant')
run('candidate-hopper','candidate',fixtures/'modern.save.json','hopper')
run('candidate-low','candidate',r/'low.save.json','hopper')
run('candidate-empty','candidate',r/'empty.save.json','hopper')
run('candidate-legacy','candidate',fixtures/'legacy-render.save.json','hopper')
run('candidate-motion','candidate',fixtures/'modern.save.json','hopper',False,3,10)
label='candidate-benchmark';args=[str(apps['candidate']),'--load',str(fixtures/'modern.save.json'),'--flow-benchmark',str(r/(label+'.json')),'--benchmark-seconds','20'];p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);b=json.loads((r/(label+'.json')).read_text());assert p.returncode in [0,1] and b['failure'] is None and b['bulk_budget_passed'] and b['dry_mass_budget_passed'];checks.append({'label':label,'args':args,'exit':p.returncode,'performance_passed':b['passed']});(r/'native-checks.json').write_text(json.dumps(checks,indent=2));print(label,p.returncode,b['mean_fps'],b['simulation_wall_ratio'],flush=True)
