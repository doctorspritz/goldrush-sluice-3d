from pathlib import Path
import json,hashlib,statistics
from PIL import Image,ImageDraw,ImageChops,ImageStat
r=Path(__file__).parent;load=lambda n:json.loads((r/n).read_text());reports={}
for folder in ['reference-plant','candidate-plant','candidate-hopper','candidate-low','candidate-empty','candidate-legacy','candidate-motion']:
 j=load(folder+'/frames.json');assert j['passed'] and j['failure'] is None;fs=j['frames'];reports[folder]={'passed':True,'frames':len(fs),'physical_span_s':fs[-1]['sim_time']-fs[0]['sim_time'],'wall_span_s':fs[-1]['wall']-fs[0]['wall'],'gold_balance_error_g':j['gold_balance_error_g'],'water_balance_error_m3':j['water_balance_error_m3']}
 if folder.startswith('candidate-'):reports[folder]['hopper_first']=fs[0]['hopper_material'];reports[folder]['hopper_last']=fs[-1]['hopper_material']
 assert abs(j['gold_balance_error_g'])<1e-7 and abs(j['water_balance_error_m3'])<2e-5
ref=load('reference-plant/frames.json')['frames'][0];new=load('candidate-plant/frames.json')['frames'][0]
keys=['sim_time','flow','tracks','surface','machine','tailings','loose_gold','plant'];same={k:ref.get(k)==new.get(k) for k in keys};assert all(same.values())
a=Image.open(r/'reference-plant/frame-0000.png').convert('RGB');b=Image.open(r/'candidate-plant/frame-0000.png').convert('RGB');d=ImageChops.difference(a,b);changed=sum(any(p) for p in d.getdata());assert changed>0
native={'reports':reports,'frozen_physical_fields_exact':same,'rgb_comparison':{'changed_pixels':changed,'total_pixels':a.width*a.height,'difference_bbox':d.getbbox(),'mean_absolute_channel_difference_0_255':sum(ImageStat.Stat(d).mean)/3},'review':'Pending human-model image inspection'}
(r/'native-analysis.json').write_text(json.dumps(native,indent=2))
for filename,items in [('comparison.jpg',[('Before, same finite59L stock','reference-plant/frame-0000.png'),('After, same finite59L stock','candidate-plant/frame-0000.png')]),('stock-levels.jpg',[('59L actual stock','candidate-hopper/frame-0000.png'),('5L remaining stock','candidate-low/frame-0000.png'),('Empty (stock transferred to hand)','candidate-empty/frame-0000.png'),('Legacy hopper, actual finite stock','candidate-legacy/frame-0000.png')])]:
 width=1440;height=470*((len(items)+1)//2);sheet=Image.new('RGB',(width,height),'#181818');draw=ImageDraw.Draw(sheet)
 for i,(label,path) in enumerate(items):
  im=Image.open(r/path).convert('RGB');im.thumbnail((720,450));x=i%2*720;y=i//2*470;sheet.paste(im,(x,y));draw.text((x+10,y+451),label,fill='white')
 sheet.save(r/filename,quality=90)
print(json.dumps(native,indent=2))
