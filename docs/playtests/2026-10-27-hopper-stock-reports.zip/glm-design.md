Maximum steps reached; no tools were used (none were permitted). The full deliverable — the design itself — follows.

## Implementation slice: feed-conditioning blockage layer (hopper outlet + screen), ahead of the untouched particle riffle sim

**State per hopper/screen unit (all conserved):**
- `M_min` mineral, `M_au` gold, `M_clay` clay, `M_w` water — four mass pools; nothing may enter/exit except logged transfers.
- `V_s = M_min/ρ_min + M_clay/ρ_clay` (true solid volume); `V_ref` separate ledger for "yards shoveled" (reference bulk, inflated by swell); compaction `φ = V_ref/V_s ≥ 1`.
- Pore volume `V_pore(φ)`; saturation `S = (M_w/ρ_w)/V_pore`; free water is only what exceeds `V_pore`.
- Bridge integrity `b ∈ [0,1]`; occluded fraction of outlet/screen area.

**Blockage physics (threshold rules, not solver artifacts):**
- Form: `db/dt = k_form·max(0, S − PL)·max(0, f_clay − f0)·max(0, 1 − D/(k·d95))` where `PL` is clay plastic limit, `D` aperture/mesh, `d95` clump size (arching criterion, silo-style). Dry or clay-poor feed can never bridge — the factors are zero, not penalized.
- Release: shear inputs (vibrator, water jet, manual rod) add erosion `db/dt = −k_rel·(shear)`; jet water is conserved into the slurry stream and lowers S only via modeled drainage. At `b = 0` flow resumes with exactly the stored masses.
- While blocked, feed and water accumulate in the pools; gold is never destroyed or multiplied. A blinded screen passes fines in proportion to open area, masses balanced to underflow+overflow.
- Any numerical failure in an underlying solver must surface as an error event — never reinterpreted as a blockage.

**Calibration required (gameplay tunables, not physics):** `PL`, arching ratio `k`, `k_form`, `k_rel`, drainage rate, attrition rate that liberates gold from clay clumps (if modeled). **A model this simple cannot establish:** real arch strength or clay rheology, realistic throughput numbers, or the true recovery response of gold locked in clay aggregates — attrition-liberation rate is calibrated, not derived.

**Save/reload:** serialize the eight scalars (`M_min, M_au, M_clay, M_w, V_ref, φ, b, occluded`); on load assert `Σ(pools) == ledger` within 1e-9 relative before resuming.

**Tests:**
1. **Conservation:** randomized 10k-step feed sequence; `M_au, M_min, M_w` in (inventory + blockage store + all effluents) equal inflows exactly; `V_ref` tracks shoveled yards independently of `V_s`.
2. **Falsification:** dry (`S < PL`) or low-clay (`f_clay < f0`) feeds produce `b = 0` always, regardless of run length — no universal wetness penalty exists in code.
3. **Release round-trip:** form a bridge, apply vibrator+jet, confirm `b → 0`, effluent masses equal accumulated input minus residual pool.
4. **Save/reload mid-blockage:** reload, state bit-identical, invariants hold, release path still works.
5. **Downstream neutrality:** identical feed with and without the conditioning layer delivers identical particle streams to the riffle sim (same counts, sizes, gold masses); any recovery change traces to composition/slurry flow, never a hidden multiplier.

Remaining work beyond this slice (out of scope): multi-compartment hoppers, screen cloth wear, clay-ball attrition submodel.