import argparse,pathlib,subprocess,time,os,signal,sys,threading,json
p=argparse.ArgumentParser();p.add_argument('--seconds',type=float,default=240);p.add_argument('--log',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
command=a.command[1:] if a.command[:1]==['--'] else a.command
root=pathlib.Path(__file__).parent
baseline=set(json.loads((root/'start.json').read_text())['crashes'])
def crashes(): return {x.name for x in pathlib.Path('/Library/Logs/DiagnosticReports').iterdir() if x.name.startswith('panic-full-') or x.name.startswith('.WindowServer-')}
if crashes()-baseline:sys.exit('New crash report; no check launched: '+str(crashes()-baseline))
log=open(a.log,'xb');child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
print('Owned check PID',child.pid,flush=True)
state={'bytes':0,'discarded':0};limit=2*1024*1024

def drain():
 for block in iter(lambda:child.stdout.read1(8192),b''):
  take=min(len(block),max(0,limit-state['bytes']));log.write(block[:take]);state['bytes']+=take;state['discarded']+=len(block)-take;log.flush()
 log.flush()
reader=threading.Thread(target=drain);reader.start();deadline=time.monotonic()+a.seconds;reason=None
while child.poll() is None:
 new=crashes()-baseline
 if new or time.monotonic()>deadline:
  reason='new crash '+str(new) if new else 'deadline'
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  break
 time.sleep(.25)
reader.join();log.close()
result={'exit':child.returncode,'stopped_reason':reason,'log_bytes':state['bytes'],'discarded_log_bytes':state['discarded']}
pathlib.Path(a.log+'.supervisor.json').write_text(json.dumps(result,indent=2))
print(pathlib.Path(a.log).read_text(errors='replace')[-6500:]);print('SUPERVISOR',json.dumps(result),flush=True)
sys.exit(125 if reason and reason.startswith('new crash') else 124 if reason else child.returncode)
