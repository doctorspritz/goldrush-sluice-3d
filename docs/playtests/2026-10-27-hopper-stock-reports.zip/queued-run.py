from pathlib import Path
import subprocess,json,sys,time
r=Path(__file__).parent;label=sys.argv[1];args=sys.argv[2:];deadline=time.monotonic()+300;observations=[]
baseline=set(json.loads((r/'start.json').read_text())['crashes'])
while True:
    new={p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-baseline
    if new:sys.exit('New crash report: '+str(new))
    status=json.loads(subprocess.check_output(['python3',str(r/'process-status.py')],text=True))
    observations.append({'at_monotonic':time.monotonic(),**status});(r/(label+'-queue.json')).write_text(json.dumps(observations,indent=2))
    if status['available']:break
    if time.monotonic()>=deadline:
        print('PENDING: no job launched; workload remained full for this bounded queue window.',flush=True);sys.exit(75)
    time.sleep(2)
# Launch once. This never retries a failed test, compile, capture or benchmark.
sys.exit(subprocess.run(['python3',str(r/'run.py'),label,*args]).returncode)
