set terminal pngcairo size 1600,900 font "Arial,12"
set output "retention.png"
set datafile missing "nan"
set multiplot layout 2,3 rowsfirst title "Nominal 3.75 L/s - fixed-mass quartz pulse; weighted-parcel refinement"
set xlabel "Seconds after pulse"
set ylabel "Resident quartz fraction"
set xrange [0:8]
set grid
set key bottom right
set linetype 1 lc rgb "#0072B2" lw 2
set linetype 2 lc rgb "#D55E00" lw 2
set linetype 3 lc rgb "#009E73" lw 2
set yrange [0:1.04]
set title "Bare channel / 47 um"
plot "data/bare_nominal-q2-d0.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/bare_nominal-q4-d0.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/bare_nominal-q6-d0.dat" using 1:2 with lines lt 3 title "648 parcels total"
set title "Bare channel / 97 um"
plot "data/bare_nominal-q2-d1.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/bare_nominal-q4-d1.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/bare_nominal-q6-d1.dat" using 1:2 with lines lt 3 title "648 parcels total"
set title "Bare channel / 173 um"
plot "data/bare_nominal-q2-d2.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/bare_nominal-q4-d2.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/bare_nominal-q6-d2.dat" using 1:2 with lines lt 3 title "648 parcels total"
set title "Riffles / 47 um"
plot "data/riffles_nominal-q2-d0.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/riffles_nominal-q4-d0.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/riffles_nominal-q6-d0.dat" using 1:2 with lines lt 3 title "648 parcels total"
set title "Riffles / 97 um"
plot "data/riffles_nominal-q2-d1.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/riffles_nominal-q4-d1.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/riffles_nominal-q6-d1.dat" using 1:2 with lines lt 3 title "648 parcels total"
set title "Riffles / 173 um"
plot "data/riffles_nominal-q2-d2.dat" using 1:2 with lines lt 1 title "24 parcels total", "data/riffles_nominal-q4-d2.dat" using 1:2 with lines lt 2 title "192 parcels total", "data/riffles_nominal-q6-d2.dat" using 1:2 with lines lt 3 title "648 parcels total"
unset multiplot
