from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).parent;w=Path.cwd();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='docs/playtests/2026-10-27-screen-throughput'
# Require all nine exact replay comparisons and rehash the actual outputs.
e=json.loads((r/'state-equivalence.json').read_text());assert set(e)=={'warm','loaded','stopped'}
for case,items in e.items():
 assert set(items)=={'initial-screen.json','states.jsonl','final-screen.json'}
 for name,j in items.items():
  assert j['exact'] and (r/('reference-'+case)/name).read_bytes()==(r/('candidate-'+case)/name).read_bytes() and h(r/('candidate-'+case)/name)==j['sha256']
for n in [prefix+'.md','docs/physics/plant-screen.md','plans/2026-10-22-realistic-operation.md']:
 p=w/n;s=p.read_text()
 for a,b in {'checks pass:**15':'checks pass:** 15','geometry,31':'geometry, 31','and1 actual':'and 1 actual','new2048':'new 2048','All360':'All 360','over120ticks':'over 120 ticks','warm,loaded andstopped':'warm, loaded and stopped','The480tick':'The 480-tick','retains1170':'retains 1170','/120ticks':'/120 ticks','Native20second':'Native 20-second','required60second':'required 60-second','all1,296,000RGB':'all 1,296,000 RGB','contains39':'contains 39','over1.997wall':'over 1.997 wall','and1.017physical':'and 1.017 physical','contains17frames':'contains 17 frames','over2.838wall':'over 2.838 wall','and1.167physical':'and 1.167 physical','pass10':'pass 10','with7screenshots':'with 7 screenshots','change,260':'change, 260','Beads1.0.4':'Beads 1.0.4','verifies2048':'verifies 2048','work;360':'work; 360','measured6.7':'measured 6.7','passes47':'passes 47','checks,2048':'checks, 2048','and360':'and 360','falls6.7':'falls 6.7','remain0.443':'remain 0.443','Stages2–6':'Stages 2–6'}.items():s=s.replace(a,b)
 p.write_text(s)
# Raw PNG sequences remain local; archive timing/state metadata and hashes,
# representative contact sheets, controls and the published wall-time movie.
manifest={str(p.relative_to(r)):{'bytes':p.stat().st_size,'sha256':h(p)} for n in ['candidate-motion-screen','candidate-demo-motion-outlet'] for p in (r/n).glob('*.png')};(r/'raw-motion-images.json').write_text(json.dumps(manifest,indent=2))
omitted=json.loads((r/'omitted-large-evidence.json').read_text());src=json.loads((r/'receipt.json').read_text())
with zipfile.ZipFile(w/(prefix+'-reports.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in r.iterdir():
  if p.is_file() and p.name not in omitted and p.suffix in ['.json','.log','.py','.txt','.stderr','.rs','.jpg']:z.write(p,p.name)
 for directory in [*['reference-'+n for n in ['warm','loaded','stopped']],*['candidate-'+n for n in ['warm','loaded','stopped']],*[p.name for p in r.glob('timing-*') if p.is_dir()], 'gpu-fixtures','reference-frozen-screen','candidate-frozen-screen','candidate-motion-screen','candidate-demo-motion-outlet','native-screen-controls']:
  for p in (r/directory).iterdir():
   if p.is_file() and p.name!='states.jsonl' and (p.suffix=='.json' or p.suffix=='.png' and directory not in ['candidate-motion-screen','candidate-demo-motion-outlet']):z.write(p,str(p.relative_to(r)))
 for n in src['changed_sources']+src['new_sources']:z.write(w/n,'source/'+n)
 assert z.testzip() is None
assert (w/(prefix+'-reports.zip')).stat().st_size<95_000_000
print({'archive_bytes':(w/(prefix+'-reports.zip')).stat().st_size,'exact_replay_files':9,'raw_motion_frames_manifest':len(manifest)})
