from pathlib import Path
import subprocess,json,time,sys,hashlib
r=Path(__file__).parent;old=r.parent/'plant-screen-20261027';fixture=old/'gpu-fixtures-v8/modern.save.json';apps={'reference':old/'app-v8/First Bend.app/Contents/MacOS/mining','candidate':r/'app/First Bend.app/Contents/MacOS/mining'};checks=[]
previous=json.loads((old/'receipt.json').read_text());assert hashlib.sha256(apps['reference'].read_bytes()).hexdigest()==previous['installation']['candidate_executable_sha256']
assert all(j['exit']==0 for j in json.loads((r/'quality.json').read_text()))
def run(label,variant,source,args,expected=0):
    command=[str(apps[variant])]+(['--load',str(source)] if source else [])+args;begin=time.monotonic()
    p=subprocess.run(['python3',str(r/'queued-run.py'),label,*command],capture_output=True,text=True)
    (r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'variant':variant,'args':command,'exit':p.returncode,'expected':expected,'wall_seconds':time.monotonic()-begin});(r/'native-checks.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode not in ([0,1] if expected is None else [expected]):print(p.stdout[-6000:]);sys.exit(p.returncode or 99)
    if expected is None:
        b=json.loads((r/(label+'.json')).read_text());assert b['failure'] is None and b['bulk_budget_passed'] and b['dry_mass_budget_passed']
for trial,variant in enumerate(['reference','candidate','candidate','reference']):
    label=f'native-benchmark-{trial}-{variant}';run(label,variant,fixture,['--flow-benchmark',str(r/(label+'.json')),'--benchmark-seconds','20'],None)
for variant in ['reference','candidate']:
    label=variant+'-frozen-screen';run(label,variant,fixture,['--freeze','--capture-motion',str(r/label),'--capture-view','screen','--capture-seconds','1','--capture-hz','2'])
run('candidate-motion-screen','candidate',fixture,['--capture-motion',str(r/'candidate-motion-screen'),'--capture-view','screen','--capture-seconds','2','--capture-hz','30'])
run('candidate-demo-motion-outlet','candidate',None,['--capture-motion',str(r/'candidate-demo-motion-outlet'),'--capture-view','outlet','--capture-seconds','3','--capture-hz','6'])
run('native-screen-controls','candidate',fixture,['--check-screen',str(r/'native-screen-controls/receipt.json')])
