from pathlib import Path
import subprocess,json,shutil,sys,hashlib,statistics,itertools
r=Path(__file__).parent;checks=[]
def run(label,args,expected=0):
    p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],capture_output=True,text=True)
    (r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'args':args,'exit':p.returncode,'expected':expected});(r/'candidate-checks.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode!=expected:print(p.stdout[-6000:]);sys.exit(p.returncode or 99)
def hash_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def compare(a,b):
    assert a.stat().st_size==b.stat().st_size
    with a.open('rb') as left,b.open('rb') as right:
        for x,y in itertools.zip_longest(iter(lambda:left.read(1024*1024),b''),iter(lambda:right.read(1024*1024),b'')):assert x==y,(a,b)
    return {'bytes':a.stat().st_size,'sha256':hash_file(a),'exact':True}
run('build-shared-brackets',['cargo','+nightly','build','-p','mining-sim','--example','screen_replay','--profile','playable','--locked','--jobs','1'])
(r/'candidate').mkdir();binary=r/'candidate/mining';shutil.copyfile('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/playable/examples/screen_replay',binary);binary.chmod(0o755)
(r/'candidate-binary.json').write_text(json.dumps({'path':str(binary),'sha256':hash_file(binary)},indent=2))
equivalence={}
for case in ['warm','loaded','stopped']:
    run('candidate-'+case,[str(binary),str(r/(case+'-input.json')),str(r/('candidate-'+case)),'120','1'])
    equivalence[case]={name:compare(r/('reference-'+case)/name,r/('candidate-'+case)/name) for name in ['initial-screen.json','states.jsonl','final-screen.json']}
    (r/'state-equivalence.json').write_text(json.dumps(equivalence,indent=2));print({'case':case,'all_120_complete_states_exact':True},flush=True)
timings=[]
for case in ['warm','loaded','stopped']:
    for trial,variant in enumerate(['reference','candidate','candidate','reference']):
        name=f'timing-{case}-{trial}-{variant}';app=r/variant/'mining'
        run(name,[str(app),str(r/(case+'-input.json')),str(r/name),'120','3','--metrics-only'])
        j=json.loads((r/name/'metrics.json').read_text());assert j['full_state_trace'] is None and j['trace_bytes']==0
        compare(r/name/'final-screen.json',r/('reference-'+case)/'final-screen.json')
        timings.append({'name':name,'case':case,'variant':variant,'step_seconds':[row['step_seconds'] for row in j['runs']]})
        (r/'timings.json').write_text(json.dumps(timings,indent=2))
summary={}
for case in ['warm','loaded','stopped']:
    values={variant:[t for row in timings if row['case']==case and row['variant']==variant for t in row['step_seconds']] for variant in ['reference','candidate']}
    med={k:statistics.median(v) for k,v in values.items()}
    summary[case]={'seconds_per_120_ticks':values,'median_seconds_per_120_ticks':med,'median_step_reduction_percent':(1-med['candidate']/med['reference'])*100,'all_final_states_exact':True}
(r/'timing-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
for tag,args in [('invalid-ticks',[str(binary),str(r/'warm-input.json'),str(r/'invalid-unused'),'0','1']),('existing-directory',[str(binary),str(r/'warm-input.json'),str(r/'candidate-warm'),'1','1'])]:run(tag,args,1)
