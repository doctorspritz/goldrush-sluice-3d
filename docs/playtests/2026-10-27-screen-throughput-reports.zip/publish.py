from pathlib import Path
import json,subprocess,hashlib,re,shutil,zipfile,statistics
r=Path(__file__).parent;w=Path.cwd();load=lambda n:json.loads((r/n).read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=load('start.json');source=load('qualified-sources.json');prefix='docs/playtests/2026-10-27-screen-throughput'
assert len(source)==764 and all(h(w/n)==v for n,v in source.items())
changed=[n for n in start['sources'] if source[n]!=start['sources'][n]];new=[n for n in source if n not in start['sources']]
assert changed==['crates/mining-sim/src/screen.rs'] and new==['crates/mining-sim/examples/screen_replay.rs']
quality=load('quality.json');assert len(quality)==5 and all(j['exit']==0 for j in quality)
counts={n:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(r/(name+'.log')).read_text()))) for n,name in [('contact','unit-shared-brackets'),('integration','screen-integration'),('actual_metal','metal-plant')]};assert counts=={'contact':15,'integration':31,'actual_metal':1};counts['total']=sum(counts.values())
assert load('state-equivalence.json')['all_equal'] if 'all_equal' in load('state-equivalence.json') else all(j.get('equal',j.get('exact',True)) for j in load('state-equivalence.json').values() if isinstance(j,dict))
native=load('native-analysis.json');controls=load('native-screen-controls/receipt.json');video=load('video.json');assert controls['passed'] and video['passed'] and all(j['passed'] for j in native['reports'].values())
bench=[load(f'native-benchmark-{i}-{kind}.json') for i,kind in enumerate(['reference','candidate','candidate','reference'])]
for b in bench:assert b['failure'] is None and not b['passed'] and b['bulk_budget_passed'] and b['dry_mass_budget_passed'] and abs(b['gold_balance_error_g'])<1e-7 and abs(b['water_balance_error_m3'])<2e-5
p=subprocess.run(['/Users/simonheikkila/.codex/skills/cleanup/scripts/cleanup.sh'],capture_output=True,text=True);(r/'cleanup.log').write_text(p.stdout+p.stderr);p.check_returncode();cleanup={'exit':p.returncode,'summary':p.stdout};(r/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose');installed=original/'target/bundles/First Bend.app/Contents/MacOS/mining';candidate=r/'app/First Bend.app'
assert h(installed)==start['app_sha256'];assert all(h(original/n)==v for n,v in start['original_files'].items());assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==start['stash'];assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(start['crashes']);subprocess.run(['codesign','--verify','--deep','--strict',str(candidate)],check=True)
# Update only the two already owned issue rows. No global export.
def bd(label,*args):
 p=subprocess.run(['bd','--sandbox',*args,'--json'],capture_output=True,text=True);(r/(label+'.stderr')).write_text(p.stderr);p.check_returncode();j=json.loads(p.stdout);(r/(label+'.json')).write_text(json.dumps(j,indent=2));return j
notes='27 Oct exact shared screen drive endpoints: cached dyadic bracket endpoints/midpoints and exact admitted endpoints preserve phase arithmetic. 2048 contact controls, 360 complete finite-screen states and actual Metal fixture comparisons pass; GPU save equality accounts only for keyed contact-map row ordering. Same 120-tick finite-stock A/B/B/A CPU medians improve6.73% warm,7.83% loaded,7.20% stopped. Native A/B/B/A windows range0.443-0.477x physical with54.54-57.17FPS; no consistent whole-game gain or real-time acceptance established. Frozen native physical fields and RGB exact, maintenance/save/restart passes. Installation remains HELD; previous signed app unchanged. Evidence docs/playtests/2026-10-27-screen-throughput.md. No water/riffle/terrain/contact-step/tolerance coarsening. Keep IN_PROGRESS; complete realistic operation, wet/dense screen, elastic impacts, calibrated throughput/recovery and all failure scope remain required.'
for id in ['sluice-realtime','menace-sfu.2']:bd('update-'+id,'update',id,'--status','in_progress','--append-notes',notes)
before=(r/'issues-before.jsonl').read_bytes();assert (w/'.beads/issues.jsonl').read_bytes()==before;existing={json.loads(x)['id']:json.loads(x) for x in before.splitlines()};owned={};display={'parent','dependents','epic_total_children','epic_closed_children','epic_closeable'}
for id in ['sluice-realtime','menace-sfu.2']:
 fresh=bd('final-'+id,'--readonly','show',id)[0];row=dict(existing[id]);row.update({k:v for k,v in fresh.items() if k not in display and k!='dependencies'})
 if 'dependencies' in fresh:row['dependencies']=[{'issue_id':id,'depends_on_id':d.get('depends_on_id',d.get('id')),'type':d.get('type',d.get('dependency_type'))} for d in fresh['dependencies']]
 assert row['status']=='in_progress';owned[id]=row
out=b''.join((json.dumps(owned[json.loads(line)['id']],separators=(',',':'),ensure_ascii=False)+'\n').encode() if json.loads(line)['id'] in owned else line for line in before.splitlines(keepends=True));assert len(out.splitlines())==len(before.splitlines())==262
assert [x for x in before.splitlines(keepends=True) if json.loads(x)['id'] not in owned]==[x for x in out.splitlines(keepends=True) if json.loads(x)['id'] not in owned];(w/'.beads/issues.jsonl').write_bytes(out);(r/'owned-tracker-rows.json').write_text(json.dumps(owned,indent=2))
visual={'reviewed':['candidate-frozen-screen/frame-0000.png','candidate-demo-motion-outlet/frame-0010.png','candidate-motion-screen-sheet.jpg','candidate-demo-motion-outlet-sheet.jpg','native-screen-controls/receipt-screen-320.png'],'findings':['Frozen native frame is pixel-identical to previous screen candidate.','Grains move downstream but remain sparse weighted proxies; no dense wet deck is present.','Close wire mesh aliases visibly.','Developed outlet moves forward and downward but its surface and river shoreline remain provisional.','No visual improvement or manual driving qualification claimed.','Finite hopper inventory needs a visible fill surface.']}
(r/'visual-review.json').write_text(json.dumps(visual,indent=2))
receipt={'stage':'Exact screen drive bracket reuse','baseline_commit':start['head'],'started_utc':start['started_utc'],'goal_status':'active','full_operation_complete':False,'empirically_calibrated':False,'source_manifest':source,'changed_sources':changed,'new_sources':new,'focused_checks':counts,'full_workspace_suite_passed':False,'quality':quality,'state_equivalence':load('state-equivalence.json'),'timing_summary':load('timing-summary.json'),'timings':load('timings.json'),'metal_saved_state':load('metal-fixture-map-order-comparison.json'),'native':native,'native_checks':load('native-checks.json'),'native_controls':controls,'visual_review':visual,'video':video,'benchmarks':bench,'installation':{'performed':False,'reason':'No consistent whole-game speedup; physical throughput remains below real time.','installed_executable':str(installed),'installed_executable_sha256':h(installed),'candidate':str(candidate),'candidate_executable_sha256':h(candidate/'Contents/MacOS/mining'),'candidate_signature_verified':True},'tracker':{'owned_ids':list(owned),'total_rows':262,'unrelated_literal_rows':260},'preservation':{'nine_original_files_exact':True,'stash':start['stash'],'no_new_crash_reports':True,'cleanup':cleanup},'limits':['Finite-stock CPU test adds no new feed and does not advance wet/terrain solvers.','All timing samples and outliers retained; observed median gain is not whole-game speedup.','Native performance windows are20s after5s warm-up, not the required60s real-time acceptance.','Original contact law and all wet/terrain settings remain unchanged.','Dilute dry weighted spheres; dense wet feed, clay/blinding, persistent elastic impacts and calibration remain required.','No full operation completion, manual driving or real-time claim.']}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));(w/(prefix+'.json')).write_bytes((r/'receipt.json').read_bytes())
shutil.copyfile(r/'screen.jpg',w/(prefix+'-screen.jpg'));shutil.copyfile(r/'screen-motion.mp4',w/(prefix+'-screen.mp4'))
doc='''# Exact screen CPU optimization — installation remains held

Shared exact drive endpoints and recursive midpoints remove repeated trigonometry from the wire contact search. Evaluated values are reused only at identical floating-point times; the original phase arithmetic order, continuous contact search, intervals, skin, friction, restitution and work limits remain. Original water, riffle and terrain solvers/settings are untouched.

**47 affected checks pass:**15 contact/geometry,31 screen/feed/plant integration and1 actual Metal route. Selected strict Clippy, formatting and signed packaging pass. The new2048-case contact control compares hit time, normal, surface velocity, index, refusal and query work exactly with the uncached method. A bounded `screen_replay` diagnostic restores finite saved screen stock and adds no feed. All360 complete states over120ticks each in warm,loaded andstopped cases match byte-for-byte, including every particle, output, inventory and work counter. Initial/final states also match. This is not a full-workspace suite.

The480tick actual Metal route retains1170 full-state handoffs and live plant restore. Both full saved fixtures match the previous candidate after sorting only unique keyed contact-history rows exported from HashMaps; no particle, cell or scalar values are normalized. Gold residual−7.73e−12g, bulk7.56e−9m³, water1.99e−7m³.

| Finite stock, median CPU seconds /120ticks | Reference | Candidate | Reduction |
|---|---:|---:|---:|
| Warm |0.36318|0.33872|6.73%|
| Loaded |0.76072|0.70112|7.83%|
| Stopped |0.51770|0.48044|7.20%|

A/B/B/A order gives six samples per variant and case. All raw timings/outliers are retained. Timers exclude cloning and JSON/disk. This isolates screen step cost; it does not measure whole-game speed or dense/wet processing.

| Native20second window, same initial save | Render FPS | Physical seconds / wall second |
|---|---:|---:|
| Reference A |57.17|0.46162|
| Candidate B |54.54|0.47663|
| Candidate B |56.71|0.44275|
| Reference A |56.50|0.44636|

All four runs retain material/water budgets and have no runtime failure. **There is no consistent native whole-game gain and real time still fails.** These short windows do not qualify the required60second acceptance. The previous signed independent-gold app remains installed; this screen candidate is held.

Frozen restored native physical fields and all1,296,000RGB pixels match the previous screen candidate. The new motion recording contains39 actual frames over1.997wall seconds and1.017physical seconds; its video uses recorded wall timing. The developed outlet recording contains17frames over2.838wall seconds and1.167physical seconds. Capture overhead affects cadence. Synthetic Bevy keyboard events pass10 maintenance/save/restart checks with7screenshots; OS focus, key delivery and manual driving are not exercised.

Visual inspection confirms moving but sparse grain proxies, strong fine-wire aliasing and provisional outlet/river optics. No rendering improvement is claimed. Finite hopper inventory still needs a visible surface. Dense slurry, persistent elastic screen response, wet clay/clogging/blinding, empirical calibration, flexible wash-plant modules and all other operation/failure requirements remain open in the [operation plan](../../plans/2026-10-22-realistic-operation.md).

![Frozen native candidate](2026-10-27-screen-throughput-screen.jpg)

[Actual wall-time motion](2026-10-27-screen-throughput-screen.mp4) · [Receipt](2026-10-27-screen-throughput.json) · [Evidence/reproduction inputs](2026-10-27-screen-throughput-reports.zip)

One task-owned heavy job ran at a time and queued for global capacity. No new panic/WindowServer reports appeared. Scoped cleanup ran; unrelated processes were preserved. The nine original dirty files, stash and installed app remain exact. Only two tracker rows change,260 unrelated literal rows remain. Beads1.0.4 has no sync command; scoped rows land with the verified commit. Raw large traces and redundant endpoint saves remain local with hashes; the archive contains finite input states, metrics, scripts, logs and native evidence to reproduce them.
'''
(w/(prefix+'.md')).write_text(doc)
p=w/'docs/physics/plant-screen.md';p.write_text(p.read_text().rstrip()+'''\n\nExact drive-bracket reuse now shares evaluated endpoint and midpoint offsets/velocities across candidate wires and recursive children. Admitted endpoints reuse a value only when its floating-point time matches exactly; original phase arithmetic order is retained. A test-only uncached reference verifies2048 hit/miss cases and identical query work;360 complete finite-screen replay states and coupled Metal save comparisons also match. This removes repeated trigonometry without changing the declared physical model, contact tolerances, interval sizes or work budgets. The measured6.7–7.8% median isolated CPU reduction does not establish native real-time throughput. See [evidence](../playtests/2026-10-27-screen-throughput.md).\n''')
p=w/'plans/2026-10-22-realistic-operation.md';p.write_text(p.read_text().rstrip()+'''\n\n27 October: [exact screen bracket reuse](../docs/playtests/2026-10-27-screen-throughput.md) passes47 affected checks,2048 exact contact cases and360 full-state replay comparisons. Finite-stock median screen CPU cost falls6.7–7.8%; paired native windows show no consistent whole-game gain and remain0.443–0.477x physical time. Frozen native RGB/physics and maintenance/save checks pass. Installation remains held; original water/riffle/terrain settings and installed app are preserved. Visible hopper stock, dense/wet processing, persistent elasticity, calibration and every unfinished Stages2–6 operation/failure requirement remain open.\n''')
omitted={str(p.relative_to(r)):{'bytes':p.stat().st_size,'sha256':h(p)} for p in r.rglob('*') if p.is_file() and (p.name=='states.jsonl' or p.parent==r and (p.name.endswith('.save.json') or p.name.endswith('-unused.json')))};(r/'omitted-large-evidence.json').write_text(json.dumps(omitted,indent=2))
with zipfile.ZipFile(w/(prefix+'-reports.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in r.iterdir():
  if p.is_file() and p.name not in omitted and p.suffix in ['.json','.log','.py','.txt','.stderr','.rs']:z.write(p,p.name)
 for directory in [*['reference-'+n for n in ['warm','loaded','stopped']],*['candidate-'+n for n in ['warm','loaded','stopped']],*[p.name for p in r.glob('timing-*') if p.is_dir()], 'gpu-fixtures','reference-frozen-screen','candidate-frozen-screen','candidate-motion-screen','candidate-demo-motion-outlet','native-screen-controls']:
  for p in (r/directory).iterdir():
   if p.is_file() and p.name!='states.jsonl' and p.suffix in ['.json','.png']:z.write(p,str(p.relative_to(r)))
 for n in changed+new:z.write(w/n,'source/'+n)
 assert z.testzip() is None
assert (w/(prefix+'-reports.zip')).stat().st_size<95_000_000
print(json.dumps({'checks':counts,'changed':changed,'new':new,'archive_bytes':(w/(prefix+'-reports.zip')).stat().st_size,'installation':'held','cleanup':cleanup},indent=2))
