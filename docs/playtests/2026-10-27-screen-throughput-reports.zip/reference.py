from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path(__file__).parent;old=r.parent/'plant-screen-20261027';checks=[]
def run(label,args):
    p=subprocess.run(['python3',str(r/'run.py'),label,*args],capture_output=True,text=True)
    (r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'args':args,'exit':p.returncode});(r/'reference-checks.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode:print(p.stdout[-6000:]);sys.exit(p.returncode)
run('format-reference-ready',['cargo','+nightly','fmt','-p','mining-sim'])
run('build-reference-ready',['cargo','+nightly','build','-p','mining-sim','--example','screen_replay','--profile','playable','--locked','--jobs','1'])
binary=r/'reference-screen-replay';shutil.copyfile('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/playable/examples/screen_replay',binary);binary.chmod(0o755)
inputs={};h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for case,file in [('warm','gpu-fixtures-v8/modern.save.json'),('loaded','q8-after-benchmark.save.json'),('stopped','q8-after-benchmark.save.json')]:
    source=old/file;screen=json.loads(source.read_text())['plant']['screen']
    if case=='stopped':screen['motor_on']=False
    target=r/(case+'-input.json');target.write_text(json.dumps(screen,separators=(',',':')))
    inputs[case]={'parent':str(source),'parent_sha256':h(source),'screen':str(target),'screen_sha256':h(target),'motor_on':screen['motor_on'],'active':len(screen['particles'])}
    (r/'inputs.json').write_text(json.dumps(inputs,indent=2))
    run('reference-'+case,[str(binary),str(target),str(r/('reference-'+case)),'120','1'])
(r/'reference-binary.json').write_text(json.dumps({'path':str(binary),'sha256':h(binary)},indent=2))
