from pathlib import Path
import subprocess,os,json,time,sys,hashlib
r=Path(__file__).parent;checks=[];common=['--profile','playable','--locked','--jobs','1'];env={**os.environ,'SLUICE_SCREEN_OUTPUT':str(r/'gpu-fixtures')}
jobs=[('screen-lint',['cargo','+nightly','clippy','-p','mining-sim','--lib','--example','screen_replay','--test','screen','--test','screen_feed','--test','plant',*common,'--no-deps','--','-D','warnings']),('screen-integration',['cargo','+nightly','test','-p','mining-sim','--test','screen','--test','screen_feed','--test','plant',*common,'--','--test-threads=1','--nocapture']),('metal-plant',['cargo','+nightly','test','-p','mining-physics','--test','screen_plant',*common,'--','--ignored','--test-threads=1','--nocapture']),('package',['bash','scripts/package-mining-macos.sh',str(r/'app')]),('format',['cargo','+nightly','fmt','-p','mining-sim','--','--check'])]
for label,args in jobs:
    begin=time.monotonic();p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],env=env,capture_output=True,text=True)
    (r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'args':args,'exit':p.returncode,'wall_seconds':time.monotonic()-begin});(r/'quality.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode:print(p.stdout[-6500:]);sys.exit(p.returncode)
baseline=json.loads((r/'start.json').read_text())['sources'];names=list(baseline)+[n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if n.endswith(('.rs','.wgsl'))]
(r/'qualified-sources.json').write_text(json.dumps({n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names},indent=2))
