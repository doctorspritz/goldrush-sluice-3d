from pathlib import Path
import json,statistics,subprocess,sys
r=Path(__file__).parent;source=r/'candidate-motion-screen';j=json.loads((source/'frames.json').read_text());assert j['passed'];frames=j['frames'];assert len(frames)>20
movie=r/'screen-motion.mp4';assert not movie.exists();times=[f['wall'] for f in frames];intervals=[b-a for a,b in zip(times,times[1:])];tail=statistics.median(intervals);rows=[]
for i,f in enumerate(frames):
 p=(source/f['file']).resolve();assert p.is_file() and "'" not in str(p)
 rows.extend(["file '"+str(p)+"'",'duration '+str(intervals[i] if i<len(intervals) else tail)])
rows.append(rows[-2]);manifest=r/'screen-video-frames.txt';manifest.write_text('\n'.join(rows)+'\n')
args=['ffmpeg','-v','error','-n','-threads','1','-filter_threads','1','-f','concat','-safe','0','-i',str(manifest),'-vf','scale=960:-2','-r','30','-c:v','libx264','-threads','1','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(movie)]
p=subprocess.run(['python3',str(r/'queued-run.py'),'screen-video',*args],capture_output=True,text=True);(r/'screen-video-driver.log').write_text(p.stdout+p.stderr);p.check_returncode()
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(movie)],text=True));duration=float(probe['format']['duration']);expected=times[-1]-times[0]+tail;assert abs(duration-expected)<.15
result={'file':str(movie),'native_frames':len(frames),'duration_s':duration,'expected_capture_wall_duration_s':expected,'physical_simulation_duration_s':frames[-1]['sim_time']-frames[0]['sim_time'],'encoded_fps':30,'width':probe['streams'][0]['width'],'height':probe['streams'][0]['height'],'source':'Actual native screenshots, resampled using recorded capture wall times; capture overhead affects cadence. No synthetic animation or physical-time rescaling.','command':args,'passed':True}
(r/'video.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
