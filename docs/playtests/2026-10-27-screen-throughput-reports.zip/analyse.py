from pathlib import Path
import json,hashlib,statistics
from PIL import Image,ImageChops,ImageStat,ImageDraw
r=Path(__file__).parent
load=lambda n:json.loads((r/n).read_text())
a=load('reference-frozen-screen/frames.json');b=load('candidate-frozen-screen/frames.json')
keys=['sim_time','flow','tracks','surface','machine','tailings','loose_gold','plant']
checks={k:a['frames'][0].get(k)==b['frames'][0].get(k) for k in keys};assert all(checks.values())
im1=Image.open(r/'reference-frozen-screen/frame-0000.png').convert('RGB');im2=Image.open(r/'candidate-frozen-screen/frame-0000.png').convert('RGB');d=ImageChops.difference(im1,im2);pixels=list(d.getdata());changed=sum(any(v) for v in pixels)
comparison={'physical_fields_exact':checks,'rgb':{'size':list(im1.size),'different_pixels':changed,'total_pixels':len(pixels),'mean_absolute_channel_difference_0_255':sum(ImageStat.Stat(d).mean)/3,'maximum_channel_difference':max(e[1] for e in d.getextrema())},'scope':'Frozen restored candidate versus previous screen candidate; not the installed older application.'}
(r/'native-equivalence.json').write_text(json.dumps(comparison,indent=2))
reports={}
for name in ['reference-frozen-screen','candidate-frozen-screen','candidate-motion-screen','candidate-demo-motion-outlet']:
 j=load(name+'/frames.json');assert j['passed'];fs=j['frames'];intervals=[y['wall']-x['wall'] for x,y in zip(fs,fs[1:])]
 reports[name]={'passed':j['passed'],'frames':len(fs),'captured_wall_span_s':fs[-1]['wall']-fs[0]['wall'],'physical_span_s':fs[-1]['sim_time']-fs[0]['sim_time'],'advancing_intervals':j['advancing_intervals'],'median_capture_interval_s':statistics.median(intervals),'max_capture_interval_s':max(intervals),'gold_balance_error_g':j['gold_balance_error_g'],'water_balance_error_m3':j['water_balance_error_m3'],'presentation':j['water_presentation']}
 if 'motion' in name:
  sheet=Image.new('RGB',(1440,900),'#181818');draw=ImageDraw.Draw(sheet)
  for tile,i in enumerate([0,len(fs)//3,2*len(fs)//3,len(fs)-1]):
   f=fs[i];im=Image.open(r/name/f['file']).convert('RGB');im.thumbnail((720,430));x=tile%2*720;y=tile//2*450;sheet.paste(im,(x,y));draw.text((x+8,y+432),f"{f['file']} wall {f['wall']:.3f}s physical {f['sim_time']:.3f}s",fill='white')
  sheet.save(r/(name+'-sheet.jpg'),quality=90)
ctrl=load('native-screen-controls/receipt.json');assert ctrl['passed'] and len(ctrl['checks'])==10 and len(ctrl['stages'])==7
for f in ctrl['stages']:assert Path(f['screenshot']).is_file()
(r/'native-analysis.json').write_text(json.dumps({'reports':reports,'controls':{'passed':True,'checks':10,'screenshots':7,'input_source':ctrl['input_source']},'frozen':comparison},indent=2))
Image.open(r/'candidate-frozen-screen/frame-0000.png').convert('RGB').save(r/'screen.jpg',quality=90)
print(json.dumps({'comparison':comparison,'motion':{n:{k:v for k,v in j.items() if k!='presentation'} for n,j in reports.items()}},indent=2))
