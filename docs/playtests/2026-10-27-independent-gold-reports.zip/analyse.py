from pathlib import Path
import json,math,hashlib
from PIL import Image,ImageChops,ImageDraw
r=Path(__file__).parent
reports={};sheets=[];flight_errors=[];velocity_errors=[];comparisons=[]
for p in sorted(r.glob('*/frames.json')):
    j=json.loads(p.read_text());assert j['passed'],p
    frames=j['frames'];assert frames
    for f in frames:assert (p.parent/f['file']).is_file()
    reports[p.parent.name]={'frames':len(frames),'passed':j['passed'],'first_sim_time':frames[0]['sim_time'],'last_sim_time':frames[-1]['sim_time'],'water_balance_error_m3':j['water_balance_error_m3'],'gold_balance_error_g':j['gold_balance_error_g']}
    if 'motion' not in p.parent.name:continue
    canvas=Image.new('RGB',(1440,math.ceil(len(frames)/6)*174),(18,24,24));draw=ImageDraw.Draw(canvas)
    previous={}
    for i,f in enumerate(frames):
        with Image.open(p.parent/f['file']) as im:
            im=im.convert('RGB');im.thumbnail((240,150));canvas.paste(im,((i%6)*240,(i//6)*174+24))
        draw.text(((i%6)*240+5,(i//6)*174+5),f"{i} / {f['sim_time']:.3f}s",fill=(240,240,240))
        t=f.get('tailings')
        if t is None:continue
        for key in t['released']:
            amount=t['active'][key]+t['received'][key]+t['exported'][key]
            assert abs(amount-t['released'][key])<=max(abs(t['released'][key])*1e-9,1e-15),(p,key,amount)
        for packet in t['sample']:
            g=packet['grain'];old=previous.get(packet['id'])
            if old and not packet['contact_pending'] and not old[1]['contact_pending']:
                dt=f['sim_time']-old[0];a=old[1]['grain'];expected=[a['position'][k]+a['velocity'][k]*dt-(4.905*dt*dt if k==1 else 0.) for k in range(3)]
                flight_errors.append(math.dist(expected,g['position']))
                velocity_errors.append(math.dist([a['velocity'][k]-(9.81*dt if k==1 else 0.) for k in range(3)],g['velocity']))
            previous[packet['id']]=(f['sim_time'],packet)
    name=p.parent.name+'-contact.jpg';canvas.save(r/name,quality=88);sheets.append(name)
    if frames[0].get('tailings'):
        reports[p.parent.name]['tailings_first_last']=[{k:f['tailings'][k] for k in ['released_count','airborne','contact_pending','received','active']} for f in [frames[0],frames[-1]]]
assert not flight_errors or (max(flight_errors,default=0.)<5e-4 and max(velocity_errors,default=0.)<5e-4)
for scene in ['demo','qualified']:
    for view in ['sluice','outlet','river']:
        before=r/f'before-{scene}-frozen-{view}';after=r/f'after-{scene}-frozen-{view}'
        a=json.loads((before/'frames.json').read_text())['frames'][0];b=json.loads((after/'frames.json').read_text())['frames'][0]
        row={'scene':scene,'view':view,'flow_equal':a['flow']==b['flow'],'water_tracks_equal':a['tracks']==b['tracks'],'surface_samples_equal':a['surface']==b['surface'],'machine_equal':a['machine']==b['machine']}
        with Image.open(before/a['file']) as old,Image.open(after/b['file']) as new:
            diff=ImageChops.difference(old.convert('RGB'),new.convert('RGB'));row['different_rgb_pixels']=sum(max(v)>0 for v in diff.getdata());row['total_pixels']=old.width*old.height
            comparison=Image.new('RGB',(1440,480),(18,24,24));d=ImageDraw.Draw(comparison)
            for index,(im,label) in enumerate([(old,'Previous spatial tailings'),(new,'Independent downstream gold')]):
                im=im.convert('RGB');im.thumbnail((720,450));comparison.paste(im,(index*720,30));d.text((index*720+8,8),f'{scene} / {view} / {label}',fill=(240,240,240))
            comparison.save(r/f'{scene}-{view}-comparison.jpg',quality=90)
        assert all(row[k] for k in ['flow_equal','water_tracks_equal','surface_samples_equal','machine_equal']),row
        comparisons.append(row)
modern=json.loads((r/'gpu-fixtures/modern.save.json').read_text());legacy=json.loads((r/'gpu-fixtures/legacy-render.save.json').read_text())
assert {k:v for k,v in modern['site'].items() if k!='loose_gold'}=={k:v for k,v in legacy['site'].items() if k!='loose_gold'}
assert {k:v for k,v in modern['sluice'].items() if k!='tailings'}=={k:v for k,v in legacy['sluice'].items() if k!='tailings'}
result={'native_reports':reports,'native_frames':sum(j['frames'] for j in reports.values()),'flight_comparisons':len(flight_errors),'maximum_native_ballistic_position_error_m':max(flight_errors,default=0.),'maximum_native_ballistic_velocity_error_mps':max(velocity_errors,default=0.),'frozen_comparisons':comparisons,'fixture_site_equal_except_independent_gold_owner':True,'fixture_sluice_equal_except_destination_inventory':True,'motion_contact_sheets':sheets,'limits':['Dilute one-way point-parcel gold; turbulence, shape/contact and dense slurry feedback remain uncalibrated.','Fixture comparison pairs endpoint ownership; whole runtime policies and historical flight are not identical.','Native capture affects cadence; benchmark is reported separately.']}
gold_reports={}
for p in sorted(r.glob('after-*/frames.json')):
 j=json.loads(p.read_text());frames=j['frames'];stats=[]
 for f in frames:
  g=f.get('loose_gold');assert g is not None,p
  active=g['material']['gold_g'];closure=active+g['exported_g']+g['excavated_g']+g['withdrawn_g']-g['admitted_g']
  assert abs(closure)<=max(g['admitted_g']*1e-9,1e-15),(p,closure)
  for particle in g['sample']:
   assert particle['grain']['resting']==(particle['supported'] or particle['buried'])
  stats.append({'sim_time':f['sim_time'],'particles':g['particles'],'active_g':active,'exported_g':g['exported_g'],'admitted_g':g['admitted_g'],'sample_buried':sum(v['buried'] for v in g['sample']),'sample_supported':sum(v['supported'] for v in g['sample']),'sample_mobile':sum(v['mobile'] for v in g['sample']),'closure_g':closure})
 gold_reports[p.parent.name]={'first':stats[0],'last':stats[-1]}
result['world_gold']=gold_reports
(r/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['native_reports','frozen_comparisons']},indent=2))
