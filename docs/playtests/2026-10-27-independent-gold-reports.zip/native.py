from pathlib import Path
import subprocess, os, json, time, sys
r=Path(__file__).parent
before=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/bundles/First Bend.app/Contents/MacOS/mining')
after=r/'app/First Bend.app/Contents/MacOS/mining'
checks=[]
def run(name,app,fixture,args,expected=0):
    command=[str(app)]+(['--load',str(fixture)] if fixture else [])+args
    begin=time.monotonic()
    p=subprocess.run(['python3',str(r/'run.py'),name,*command],capture_output=True,text=True)
    (r/(name+'-driver.log')).write_text(p.stdout+p.stderr)
    row={'name':name,'command':command,'exit':p.returncode,'expected_exit':expected,'wall_seconds':time.monotonic()-begin}
    checks.append(row);(r/'native-checks.json').write_text(json.dumps(checks,indent=2));print(row,flush=True)
    if p.returncode not in ([0,1] if expected is None else [expected]):
        print(p.stdout[-5000:]);sys.exit(p.returncode or 99)
for mode,app in [('before',before),('after',after)]:
    fixture=r/'gpu-fixtures'/('legacy-render.save.json' if mode=='before' else 'modern.save.json')
    for scene,source in [('demo',None),('qualified',fixture)]:
        for view in ['sluice','outlet','river']:
            name=f'{mode}-{scene}-frozen-{view}'
            run(name,app,source,['--freeze','--capture-motion',str(r/name),'--capture-view',view,'--capture-seconds','1','--capture-hz','2'])
    for view in (['outlet'] if mode=='before' else ['sluice','outlet','river']):
        name=mode+'-qualified-motion-'+view
        run(name,app,fixture,['--capture-motion',str(r/name),'--capture-view',view,'--capture-seconds','4','--capture-hz','6'])
    if mode=='after':
        run('after-demo-motion-outlet',app,None,['--capture-motion',str(r/'after-demo-motion-outlet'),'--capture-view','outlet','--capture-seconds','4','--capture-hz','6'])
    name=mode+'-benchmark'
    run(name,app,fixture,['--flow-benchmark',str(r/(name+'.json')),'--benchmark-seconds','20'],expected=None)
