from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,re
r=Path(__file__).parent;w=Path.cwd();s=json.loads((r/'start.json').read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda name:json.loads((r/name).read_text());prefix='docs/playtests/2026-10-27-independent-gold'
source={name:h(w/name) for name in s['sources']};new=[name for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if name.endswith(('.rs','.wgsl'))]
source.update({name:h(w/name) for name in new});changed=[name for name in s['sources'] if source[name]!=s['sources'][name]]
quality=read('quality.json')[:4]+read('quality-v2.json');assert all(j['exit']==0 for j in quality)
for label in ['cpu-final','gpu-world','gpu-spatial','gpu-original','worker-tests','app-tests-v2']:
 assert read(label+'.log.supervisor.json')['exit']==0
cpu_pass=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',(r/'cpu-final.log').read_text()));assert cpu_pass==63
trials={}
for label in ['gpu-world','gpu-spatial']:
 trials[label]=next(json.loads(line) for line in (r/(label+'.log')).read_text().splitlines() if line.startswith('{"'))
bench={label:read(label+'-benchmark.json') for label in ['before','after']}
for j in bench.values():
 assert j['bulk_budget_passed'] and j['dry_mass_budget_passed'] and j['failure'] is None and abs(j['gold_balance_error_g'])<1e-7 and abs(j['water_balance_error_m3'])<2e-5
installed=read('installed.json');native=read('analysis.json');equality=read('installed-state-equality.json');assert installed['smoke_passed'] and equality['rgb_equal']
original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose');assert all(h(original/name)==value for name,value in s['original_files'].items());assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==s['stash']
assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes'])
owned=read('owned-tracker-rows.json');before=(r/'issues-before.jsonl').read_bytes();after=(w/'.beads/issues.jsonl').read_bytes();assert len(before.splitlines())==260 and len(after.splitlines())==261
assert [line for line in before.splitlines(keepends=True) if json.loads(line)['id'] not in owned]==[line for line in after.splitlines(keepends=True) if json.loads(line)['id'] not in owned]
cleanup=read('cleanup.json');assert cleanup['exit']==0
receipt={'stage':'Independent downstream gold integration','started_utc':s['started_utc'],'baseline_commit':s['head'],'source_manifest':source,'changed_sources':changed,'new_sources':new,'final_focused_tests':{'cpu':63,'worker':6,'application':77,'real_metal':3,'passed_total':149,'optional_app_profiles_ignored':2,'full_workspace_suite_passed':False},'quality':quality,'historical_quality':read('quality.json'),'gpu_trials':trials,'native':native,'native_checks':read('native-checks.json'),'benchmarks':bench,'installed':installed,'installed_equality':equality,'tracker':{'owned_ids':list(owned),'original_rows':260,'final_rows':261,'unrelated_raw_rows_literal':257},'preservation':{'original_nine_dirty_files_exact':True,'stash':s['stash'],'no_new_panic_or_windowserver_report':True,'cleanup':cleanup},'independent_downstream_gold_implemented':True,'empirically_calibrated':False,'full_gold_population_history_preserved':False,'full_operation_complete':False,'goal_status':'active','limits':['Dilute one-way point parcels; depth-averaged flow, no turbulent lift, shape drag, granular collisions or water reaction.','Existing bulk excavation/dump/intake/hopper boundaries lose grading/history and reconstitute gold sizes.','Mineral first-impact receiver still uses inherited coarse terrain classes.','No complete mining/processing/pond replay or new manual driving qualification.','Wet-ground, bridging/clogging, screens, modular plants, vehicles and floods remain unfinished.','Water rendering remains visually provisional; numerical bounds and recovery have not been tuned for FPS.']}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));(w/(prefix+'.json')).write_bytes((r/'receipt.json').read_bytes())
for suffix,input in [('outlet','demo-outlet-comparison.jpg'),('sluice','after-qualified-motion-sluice-contact.jpg'),('river','after-qualified-motion-river-contact.jpg')]:shutil.copyfile(r/input,w/(prefix+'-'+suffix+'.jpg'))
a,b=bench['before'],bench['after'];g=trials['gpu-world'];native_count=native['native_frames'];newissue=next(i for i in owned if i not in ['menace-sfu','menace-sfu.1','menace-sfu.1.1'])
doc=f'''# Independent downstream gold checkpoint

Pure gold leaving the actual sluice now continues into a saved world owner. It settles in environmental water, contacts the terrain triangles, can be buried/uncovered, collected by finite cuts or mobile pump intake, and exported across the claim boundary. It does not acquire fictitious paydirt. This advances the Gold Rush operation; it does not complete realistic gold hydraulics or the full mine.

## Implemented behavior

The original in-sluice FLIP/APIC, DEM, riffle equations, terrain grid and water timestep policy are unchanged. Full outgoing Grain state is retained. The downstream model uses physical diameter rather than a weighted parcel's large collision envelope. Existing particles advance once; first-contact admission advances only the new particle through its remaining fixed time. Bed impact is localized before supported motion. Sediment burial retains the particle's actual position instead of raising it onto the new surface.

Active gold is Site inventory; finite boundary exports are counted once. Excavation/intake receipts are diagnostics rather than extra stock. Failed admission retains donors or the pre-step owner. The 65,536-particle storage limit and bounded numerical work are resource guards, never physical clogging. Modern version-13 saves retain this owner while preserving the inner mechanism version. Laboratory v12/older loads retain their existing policy; modern app loading enables the new owner. Historic pooled gold keeps its old owner because its former position/grading cannot be reconstructed.

The [model description](../physics/independent-gold.md) states the limitations: dilute one-way point parcels, depth-averaged horizontal flow, prototype terminal relaxation/friction, no resolved turbulence/lift, flakes, collisions or drag reaction on water. Bulk tool/haul/dump/intake/feed still discard individual grading and reconstruct nominal or sampled sizes. That is tracked in `{newissue}`. These models are not empirically calibrated gold recovery.

Review also corrected pure-gold hopper occupancy, pending feed shutdown overfill, save-state flags and sub-tolerance material receipt. No hand bucket volume limit was reintroduced.

## Verification

**149 final focused checks pass:** 63 CPU, six worker, 77 application and three actual Metal regressions. Two optional app profiles remain ignored. Selected strict Clippy, changed-package formatting, signed packaging and installed smoke pass. This is not a full workspace-suite pass; the earlier bounded broad-soil attempts remain incomplete. The dependency `game` still emits its existing dead-code warning during Cargo commands.

CPU controls cover analytic free/wet motion, size/weight independence, contact/refinement, static and moving bed response, burial/uncovering including repeated 10-nm deposits, finite excavation/intake/exports, donor-safe refusal, tiny stock, pure-gold handling and exact save continuation. The flat collinear contact trial at 60/120/480/960 Hz agrees to 5.33e-15 m. This establishes the specified constant-field point model, not real gold-flake behavior.

The new real-Metal fixture debits finite geological gold and injects four separated 50/100/200/500-µm weighted parcels just beyond the buffered sluice lip. All **{g['actual_gold_exit_records']} actual gold exits** match complete world state and survive airborne/world save/load. They admit {g['admitted_g']:.15g} g; final gold residual is {g['gold_error_g']:.4g} g, bulk {g['bulk_error_m3']:.4g} m³ and water {g['water_error_m3']:.4g} m³ over 360 post-pulse ticks. This is a buffered-lip handoff control, not an inlet-through-riffles recovery assay. The 600-tick mineral test still matches 383 actual exits and the original excavation/pump/camera/live-restore GPU control also passes.

## Native inspection and throughput

Reviewed {native_count} native samples covering the default flowing demo, finite GPU fixture, outlet, sluice and river, plus two installed smoke frames. Every capture passes its inventory checks. All six frozen scene/view comparisons preserve flow, water tracks, surface samples and machine state. The old app receives independent gold in its old tailings pool because it cannot read v13; fixture site data is identical except the gold owner and sluice destination inventory. This pairs endpoint ownership, not identical whole runtime policies. Installed physical fields and RGB match the qualified candidate exactly.

| Paired finite fixture, 20 s after 5 s warmup | Previous spatial app | Independent-gold app |
|---|---:|---:|
| Render FPS | {a['mean_fps']:.2f} | {b['mean_fps']:.2f} |
| Physical seconds / wall second | {a['simulation_wall_ratio']:.5f} | {b['simulation_wall_ratio']:.5f} |
| Real-time acceptance | {'Pass' if a['passed'] else 'Fail'} | {'Pass' if b['passed'] else 'Fail'} |

Both runs preserve material, gold and water budgets. A single pair is not a speedup claim, and this workload differs from the preceding dense-demo/mineral fixture. Keep FPS separate from physical time.

The screenshots still show rough sluice/crest optics, conspicuous mineral proxies and a flat muddy river sheet. This stage does not improve those visuals. Native world gold is retained at physical size and can be subpixel; no artificial gold enlargement or visual motion replaces the model. No new manual controls, machinery placement or complete processing-shift replay is claimed.

![Frozen demo outlet comparison](2026-10-27-independent-gold-outlet.jpg)

![Native sluice motion samples](2026-10-27-independent-gold-sluice.jpg)

![Native river motion samples](2026-10-27-independent-gold-river.jpg)

## Remaining operation and evidence

`menace-sfu.1.1`, tailings parent `menace-sfu.1` and shift milestone `menace-sfu` remain in progress. Gold size/shape history, phase coupling, empirical operating assays and mineral runout/stacking need work. Next plant integration is `menace-sfu.2`: persisted modules and a first real finite hopper/screen transfer. Both trommel and shaker, upgrades, clearing/haulage, actual washout/loading/clogging, ponds/recirculation, cleanup and saved continuation remain required. Wet access/slumps, bogging, deep-cut collapse, uncertain surveys, wet-feed bridging/blinding, berm breaches, tailings instability, malfunctions and flood/bridge damage remain required future systems under `menace-9z3` and the [canonical operation plan](../../plans/2026-10-22-realistic-operation.md).

The [receipt](2026-10-27-independent-gold.json) records exact sources, gates, GPU/native/benchmark reports, install/backup identity and limits. The [compressed evidence](2026-10-27-independent-gold-reports.zip) includes final sources, input saves, frame records/contact sheets, logs and failed historical attempts. Run focused tests serially with Cargo `--jobs 1` and `--test-threads=1`; the new `mining-physics --test world_gold -- --ignored` needs a real Metal/Vulkan adapter. Set `SLUICE_WORLD_GOLD_OUTPUT` to a nonexistent directory for fixtures. Preserve original water/riffle fidelity and report actual physical throughput.

All original nine dirty files and stash remain exact; the previous signed app is backed up in the receipt. No new panic/WindowServer report appears. Required scoped cleanup has run; its exact process summary is in the receipt. Only four owned issue rows change, with 257 unrelated rows literal. Landing/push is recorded separately in the stage artifact, and the full goal remains active.
'''
(w/(prefix+'.md')).write_text(doc)
p=w/'plans/2026-10-22-realistic-operation.md';p.write_text(p.read_text()+f'\n27 October: the [independent downstream gold checkpoint](../docs/playtests/2026-10-27-independent-gold.md) adds saved size-based point-parcel motion, contact/burial, excavation/intake and finite exports without fictitious paydirt. 149 focused CPU/app/Metal checks pass; {native_count} native samples plus installed equality qualify this bounded integration. {b["mean_fps"]:.2f} FPS / {b["simulation_wall_ratio"]:.5f}x physical time remains below real time. Gold grading/history through bulk boundaries (`{newissue}`), shape/turbulence/dense coupling and empirical calibration remain open. All tailings/shift parents, module/first screen and the complete operation remain unfinished.\n')
archive=w/(prefix+'-reports.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in r.iterdir():
  if p.is_file() and not p.name.endswith('.save.json') and p.suffix in ['.json','.log','.py','.txt','.stderr','.jpg']:z.write(p,p.name)
 for directory in ['gpu-fixtures','installed-smoke']:
  for p in (r/directory).glob('*.json'):z.write(p,str(p.relative_to(r)))
 for p in r.glob('*/frames.json'):
  if p.parent.name!='installed-smoke':z.write(p,str(p.relative_to(r)))
 for name in changed+new:z.write(w/name,'source/'+name)
 assert z.testzip() is None
print(json.dumps({'sources':len(source),'changed_sources':changed,'new_sources':new,'archive_bytes':archive.stat().st_size,'passed':149,'native_frames':native_count},indent=2))
