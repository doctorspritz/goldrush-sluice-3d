from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,re,os
r=Path(__file__).parent;w=Path.cwd();read=lambda n:json.loads((r/n).read_text());s=read('start.json');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='docs/playtests/2026-10-27-plant-screen'
quality=read('quality-v5.json');assert len(quality)==12 and all(j['exit']==0 for j in quality)
source={n:h(w/n) for n in s['sources']};new=[n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if n.endswith(('.rs','.wgsl'))];source.update({n:h(w/n) for n in new});changed=[n for n in s['sources'] if source[n]!=s['sources'][n]]
assert source==read('candidate-source-manifest.json')
counts={}
contact_record=read('qualified-contact.json');contact=contact_record['unit_label'];assert contact_record['screen_sha256']==h(w/'crates/mining-sim/src/screen.rs');assert all(j['exit']==0 for j in read(contact_record['run_report']))
for name,label in [('cpu','cpu-final-v3'),('contact',contact),('worker','worker-tests'),('application','app-tests')]:
 counts[name]=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(r/(label+'.log')).read_text())))
counts['actual_adapter']=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(r/(label+'.log')).read_text()))) for label in ['gpu-screen','gpu-gold','gpu-spatial','gpu-original']);counts['passed_total']=sum(counts.values())
trial=next(json.loads(line) for line in (r/'gpu-screen.log').read_text().splitlines() if line.startswith('{"'));assert trial['ticks']==480 and trial['full_state_underflow_matches']>30 and trial['live_plant_restored'];assert abs(trial['gold_error_g'])<1e-7 and abs(trial['bulk_error_m3'])<1e-5 and abs(trial['water_error_m3'])<2e-5
bench={k:read(k+'-benchmark.json') for k in ['before','after']}
for b in bench.values():assert b['failure'] is None and b['bulk_budget_passed'] and b['dry_mass_budget_passed'] and abs(b['gold_balance_error_g'])<1e-7 and abs(b['water_balance_error_m3'])<2e-5
native=read('analysis.json');controls=read('native-screen-controls/receipt.json');installed=read('installed.json');equality=read('installed-state-equality.json');video=read('video.json');cleanup=read('cleanup.json');assert controls['passed'] and installed['smoke_passed'] and equality['rgb_equal'] and video['passed'] and cleanup['exit']==0
original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose');assert all(h(original/n)==v for n,v in s['original_files'].items());assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==s['stash'];assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes'])
owned=read('owned-tracker-rows.json');before=(r/'issues-before.jsonl').read_bytes();after=(w/'.beads/issues.jsonl').read_bytes();assert len(before.splitlines())==261 and len(after.splitlines())==262;assert [x for x in before.splitlines(keepends=True) if json.loads(x)['id'] not in owned]==[x for x in after.splitlines(keepends=True) if json.loads(x)['id'] not in owned]
limits=['Plastic simultaneous impacts omit elastic preload/rebound; menace-sfu.2.1 remains required.','Dilute independent physical-diameter weighted particles; no parcel packing, grain collisions, clay cohesion or blinding.','Prescribed dry screen and product stores; no spray/film/slurry screen hydraulics or resolved drive load.','Fixed typed circuit; general placement, interchangeable trommel, wear, failures and repairs remain required.','Underflow waits for the next unchanged two-tick sluice interval; no fractional-age coupled solver.','Bulk tool/transport/hopper boundaries still discard grading/history; menace-sfu.1.2.','No calibrated mine recovery, full shift or manual first/third-person qualification claimed.','Wet access, bogging/slump/collapse, surveys, ponds/berm breaches, tailings instability and flood/bridge incidents remain required.']
receipt={'stage':'First fixed dry-screen plant circuit','started_utc':s['started_utc'],'baseline_commit':s['head'],'goal_status':'active','full_operation_complete':False,'empirically_calibrated':False,'source_manifest':source,'changed_sources':changed,'new_sources':new,'focused_checks':counts,'full_workspace_suite_passed':False,'quality':quality,'equivalent_lint_edits':read('equivalent-lint-edits.json'),'gpu_screen':trial,'native':native,'native_checks':read('native-checks.json'),'native_controls':controls,'video':video,'benchmarks':bench,'installed':installed,'installed_equality':equality,'tracker':{'owned_ids':list(owned),'total_rows':262,'unrelated_literal_rows':259},'preservation':{'nine_original_files_exact':True,'stash':s['stash'],'no_new_crash_reports':True,'cleanup':cleanup},'limits':limits}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));(w/(prefix+'.json')).write_bytes((r/'receipt.json').read_bytes());shutil.copyfile(r/'screen-model.md',w/'docs/physics/plant-screen.md')
for suffix,name in [('screen','after-qualified-motion-screen-contact.jpg'),('plant','after-qualified-motion-plant-contact.jpg'),('water','qualified-sluice-comparison.jpg')]:shutil.copyfile(r/name,w/(prefix+'-'+suffix+'.jpg'))
shutil.copyfile(r/'screen-motion.mp4',w/(prefix+'-screen.mp4'))
b=bench['after'];a=bench['before']
doc=f'''# First connected screen checkpoint

The finite hopper now feeds a saved moving wire screen, receiving gutter, original wet sluice and reject bin. The flowing demo includes this circuit. This advances the required processing operation; the complete Gold Rush mine remains unfinished.

## Playing

Near the hopper, on foot: **K** fits/stops/restarts the screen; **L** empties all stopped screen stock into the temporary unlimited hand; **M** cycles 3/6/12 mm apertures when stopped and entirely empty. Maintenance works while paused. F5/F9 retain finite stock, settings, phase and connections. A connected screen must be stopped and empty before moving the sluice. The raised hopper accepts actual hand-dumped material.

## Model and checks

Real grain diameter interacts with moving wire capsules, gravity, friction, spin and the receiving gutter. Oversize is retained after actual bin-floor contact. Undersize enters the existing sluice with full position, velocity, orientation, spin and affine state; attached moisture becomes accounted feed water. Donors remain owned on refusal. Version14 saves own the plant and its explicit impact policy; older envelopes cannot silently discard its inventory. Original water/riffle/terrain equations and numerical policies remain unchanged.

The [model](../physics/plant-screen.md) defines the collision method and limits. This is a dilute dry screen with independent weighted particles. Dense beds, clay cohesion, blinding, spray/film hydraulics, calibrated throughput, trommel and general module placement remain required. Simultaneous impacts use a declared plastic contact policy; isolated impacts retain rebound. Elastic wedging/preload/rebound remains required under `menace-sfu.2.1`. Numerical storage/work limits are refusals, never simulated clogging.

**{counts['passed_total']} focused checks pass:** {counts['cpu']} CPU integration, {counts['contact']} contact, {counts['worker']} worker, {counts['application']} app and {counts['actual_adapter']} actual Metal checks. Selected strict Clippy, formatting, signed packaging and installed smoke pass; this is not a full workspace-suite claim. The 480-tick real-pay Metal test preserves {trial['full_state_underflow_matches']} full-state handoffs and live plant save/restore, with actual underflow and caught rejects. Gold residual {trial['gold_error_g']:.4g}g; bulk {trial['bulk_error_m3']:.4g}m³; water {trial['water_error_m3']:.4g}m³.

Finite feed exposed genuine contact/CCD defects. Configured friction, actual geometry and the energy gate remain fixed. The inconsistent simultaneous Newton restitution law is replaced with an explicit plastic impact policy, not selected as a solver-failure fallback. Evidence retains failed historical trials; isolated contact passes were not accepted as integrated success.

## Native review and performance

Reviewed {native['native_frames']} native samples across screen, plant, sluice, outlet and river, with 30Hz screen/plant sampling. The native synthetic-keyboard replay covers pause, stop, whole cleanout, aperture change, F5/F9 and restart and saves seven screenshots. It is not a manual driving qualification. Six frozen comparisons preserve flow, tracked water, surface and machine state. Installed state and RGB match the qualified candidate. Water optics remain provisional.

| 20-second finite fixture | Previous circuit | Connected screen |
|---|---:|---:|
| Render FPS | {a['mean_fps']:.2f} | {b['mean_fps']:.2f} |
| Physical seconds / wall second | {a['simulation_wall_ratio']:.5f} | {b['simulation_wall_ratio']:.5f} |
| Real-time acceptance | {a['passed']} | {b['passed']} |

The old fixture returns screen stock to its hopper, so these circuits/runtime policies differ. This is not a controlled speedup comparison. Capture overhead is separate from the benchmark.

![Screen motion samples](2026-10-27-plant-screen-screen.jpg)

![Plant motion samples](2026-10-27-plant-screen-plant.jpg)

[Native screen video](2026-10-27-plant-screen-screen.mp4) · [Frozen water comparison](2026-10-27-plant-screen-water.jpg)

The [receipt](2026-10-27-plant-screen.json) and [evidence archive](2026-10-27-plant-screen-reports.zip) record sources, fixtures, gates and failures, controls, frame records, installation and backup. Original nine dirty files and stash remain exact; no new panic/WindowServer report appeared. Scoped cleanup ran. Two owned issue rows update and one required accuracy child is added;259 unrelated rows remain literal.

`menace-sfu.2` and the full shift remain in progress. Wet/cohesive screening, loading/haulage, trommel/shaker options, ponds/recirculation, calibrated gold loss/cleanup, grading/history, wet-ground mechanics and all site/equipment failure chains remain required by the [operation plan](../../plans/2026-10-22-realistic-operation.md). This checkpoint does not complete the goal.
'''
(w/(prefix+'.md')).write_text(doc)
p=w/'plans/2026-10-22-realistic-operation.md';text=p.read_text();text=text.replace('The playable Session owns one sluice. Archived screen/trommel/shaker prototypes are not integrated plant components.','A first fixed dry screen/gutter/reject circuit now feeds the original wet sluice from finite hopper stock. Wet/dense screening, spray hydraulics, calibrated separation and an interchangeable trommel remain unfinished.').replace('No persisted modular plant/port configuration or upgrade loop currently exists. Upgrades must not become a fixed recovery-percentage bonus.','The first fixed typed circuit and stopped/empty aperture changes are saved. General module placement, replacement, connection and upgrade loops remain unfinished. Upgrades must not become a fixed recovery-percentage bonus.');p.write_text(text+f'\n27 October: the [first connected dry-screen checkpoint](../docs/playtests/2026-10-27-plant-screen.md) connects finite hopper feed, moving wires, receiving gutter, original wet sluice and retained rejects. {counts["passed_total"]} focused CPU/app/Metal checks, native maintenance/save replay and installed equality pass. Native {b["mean_fps"]:.2f}FPS / {b["simulation_wall_ratio"]:.5f}x physical time. This is dilute prescribed dry-screen physics, not dense wet processing or calibrated recovery. Module/shift parents remain active; all unfinished operation/failure requirements remain required.\n')
with zipfile.ZipFile(w/(prefix+'-reports.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.py','.txt','.stderr','.md']:z.write(p,p.name)
 for p in r.glob('*/frames.json'):z.write(p,str(p.relative_to(r)))
 for directory in ['gpu-fixtures','native-screen-controls']:
  for p in (r/directory).glob('*.json'):z.write(p,str(p.relative_to(r)))
 for n in changed+new:z.write(w/n,'source/'+n)
 assert z.testzip() is None
print(json.dumps({'checks':counts,'native_frames':native['native_frames'],'sources':changed+new},indent=2))
