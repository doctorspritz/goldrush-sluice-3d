from pathlib import Path
import subprocess,json
r=Path(__file__).parent;w=Path.cwd()
def bd(label,*args):
 p=subprocess.run(['bd','--sandbox',*args,'--json'],capture_output=True,text=True);(r/(label+'.stderr')).write_text(p.stderr);p.check_returncode();j=json.loads(p.stdout);(r/(label+'.json')).write_text(json.dumps(j,indent=2));return j
assert json.loads((r/'installed.json').read_text())['smoke_passed']
assert json.loads((r/'native-screen-controls/receipt.json').read_text())['passed']
notes='First dry-screen integration is implemented, saved and installed: fixed typed screen/gutter/sluice/bin circuit; real finite hopper feed and physical aperture/wire contact; full-state underflow acceptance; explicit stopped maintenance/aperture change and v14 continuation. Focused CPU/actual Metal/native evidence and separate render/physical throughput are in docs/playtests/2026-10-27-plant-screen.md. Keep IN_PROGRESS: this is dilute one-way weighted point parcels on a prescribed dry deck, no dense packing/cohesion/blinding, coupled spray/film/slurry hydraulics, calibrated throughput, general module placement or trommel. Simultaneous contacts use declared plastic response; isolated rebound remains. Persistent elastic strain/rebound is required under menace-sfu.2.1. Resource bounds are numerical refusals, never physical clogs. Per-size state survives screen-to-sluice but upstream bulk grading/history remains menace-sfu.1.2. Full Gold Rush operation/failure scope remains required.'
bd('screen-qualified','update','menace-sfu.2','--status','in_progress','--append-notes',notes)
bd('shift-progress','update','menace-sfu','--append-notes','First fixed dry-screen circuit now connects actual finite hopper material to the original wet sluice and physical reject bin. Native K/L/M/save/reload/restart check and motion inspection qualify this bounded integration; see docs/playtests/2026-10-27-plant-screen.md. Keep menace-sfu.2 and this full-shift milestone IN_PROGRESS: wet/dense screen and trommel, general configurations, vehicles/haulage, ponds/recirculation, clogs/washout, calibration and all geology/wet-ground/plant/flood incidents remain required. No parent closes.')
ids=['menace-sfu.2','menace-sfu','menace-sfu.2.1'];before=(r/'issues-before.jsonl').read_bytes();existing={json.loads(line)['id']:json.loads(line) for line in before.splitlines()};owned={};display={'parent','dependents','epic_total_children','epic_closed_children','epic_closeable'}
for id in ids:
 fresh=bd('final-'+id,'--readonly','show',id)[0];row=dict(existing.get(id,{}));row.update({k:v for k,v in fresh.items() if k not in display and k!='dependencies'})
 if 'dependencies' in fresh:row['dependencies']=[{'issue_id':id,'depends_on_id':d.get('depends_on_id',d.get('id')),'type':d.get('type',d.get('dependency_type'))} for d in fresh['dependencies']]
 owned[id]=row
lines=[]
for line in before.splitlines(keepends=True):
 id=json.loads(line)['id'];lines.append((json.dumps(owned[id],separators=(',',':'),ensure_ascii=False)+'\n').encode() if id in owned else line)
lines.extend((json.dumps(row,separators=(',',':'),ensure_ascii=False)+'\n').encode() for id,row in owned.items() if id not in existing)
out=b''.join(lines)
assert len(before.splitlines())==261 and len(out.splitlines())==262
assert [line for line in before.splitlines(keepends=True) if json.loads(line)['id'] not in owned]==[line for line in out.splitlines(keepends=True) if json.loads(line)['id'] not in owned]
assert all(owned[id]['status']=='in_progress' for id in ['menace-sfu','menace-sfu.2']) and owned['menace-sfu.2.1']['status']=='open'
assert (w/'.beads/issues.jsonl').read_bytes()==before
(w/'.beads/issues.jsonl').write_bytes(out);(r/'owned-tracker-rows.json').write_text(json.dumps(owned,indent=2));print({'owned_rows':3,'unrelated_literal_rows':259,'total_rows':262})
