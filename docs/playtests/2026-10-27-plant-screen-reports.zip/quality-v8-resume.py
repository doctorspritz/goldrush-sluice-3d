from pathlib import Path
import json,subprocess,os,time,sys,hashlib
r=Path(__file__).parent
jobs=json.loads((r/'quality-v5.json').read_text())
prior=json.loads((r/"quality-v8.json").read_text())
(r/"quality-v8-held-attempt.json").write_text(json.dumps(prior,indent=2))
checks=[]
for row in prior:
    if row["exit"]:break
    checks.append(row)
env={**os.environ,'SLUICE_SCREEN_OUTPUT':str(r/'gpu-fixtures-v8')}
for job in jobs[len(checks):]:
    name='q8r-'+job['name'];args=list(job['command'])
    if job['name']=='package':args[-1]=str(r/'app-v8')
    begin=time.monotonic()
    p=subprocess.run(['python3',str(r/'run.py'),name,*args],capture_output=True,text=True,env=env)
    (r/(name+'-driver.log')).write_text(p.stdout+p.stderr)
    checks.append({'name':name,'command':args,'exit':p.returncode,'wall_seconds':time.monotonic()-begin})
    (r/'quality-v8.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode:print(p.stdout[-6500:]);sys.exit(p.returncode)
screen=Path.cwd()/'crates/mining-sim/src/screen.rs'
(r/'qualified-contact-v8.json').write_text(json.dumps({'unit_label':'contact-unit-v28','run_report':'quality-v8.json','screen_sha256':hashlib.sha256(screen.read_bytes()).hexdigest(),'focused_contact_tests':14,'finite_actual_pay_route_passed':True,'route_gate':'q8-cpu-final-v3; complete screen, feed and plant integration targets'},indent=2))
baseline=json.loads((r/'start.json').read_text())['sources']
names=list(baseline)+[n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if n.endswith(('.rs','.wgsl'))]
(r/'candidate-source-manifest-v8.json').write_text(json.dumps({n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names},indent=2))
