from pathlib import Path
import json,subprocess,os,time,sys,hashlib
r=Path(__file__).parent
assert json.loads((r/'package-v6.log.supervisor.json').read_text())['exit']==0
jobs=json.loads((r/'quality-v5.json').read_text())
checks=[]
env={**os.environ,'SLUICE_SCREEN_OUTPUT':str(r/'gpu-fixtures-v6')}
for job in jobs[:-1]:
    name='q6-'+job['name']; args=job['command']; begin=time.monotonic()
    p=subprocess.run(['python3',str(r/'run.py'),name,*args],capture_output=True,text=True,env=env)
    (r/(name+'-driver.log')).write_text(p.stdout+p.stderr)
    checks.append({'name':name,'command':args,'exit':p.returncode,'wall_seconds':time.monotonic()-begin})
    (r/'quality-v6.json').write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
    if p.returncode:print(p.stdout[-6500:]);sys.exit(p.returncode)
checks.append({'name':'package-v6','command':['bash','scripts/package-mining-macos.sh',str(r/'app-v6')],'exit':0,'order':'Packaged and benchmarked before full quality checks; source frozen throughout.'})
(r/'quality-v6.json').write_text(json.dumps(checks,indent=2))
p=subprocess.run(['python3',str(r/'contact.py'),'v26'],capture_output=True,text=True,env=env)
(r/'contact-v26-driver.log').write_text(p.stdout+p.stderr);print(p.stdout[-6500:],flush=True)
if p.returncode:sys.exit(p.returncode)
screen=Path.cwd()/'crates/mining-sim/src/screen.rs'
(r/'qualified-contact-v6.json').write_text(json.dumps({'unit_label':'contact-unit-v26','run_report':'contact-v26.json','screen_sha256':hashlib.sha256(screen.read_bytes()).hexdigest(),'focused_contact_tests':12,'finite_actual_pay_route_passed':True},indent=2))
baseline=json.loads((r/'start.json').read_text())['sources']
names=list(baseline)+[n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if n.endswith(('.rs','.wgsl'))]
(r/'candidate-source-manifest-v6.json').write_text(json.dumps({n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in names},indent=2))
