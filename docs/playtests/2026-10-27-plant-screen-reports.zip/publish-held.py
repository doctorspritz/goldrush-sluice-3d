from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,re
r=Path(__file__).parent;w=Path.cwd();read=lambda n:json.loads((r/n).read_text());s=read('start.json');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='docs/playtests/2026-10-27-plant-screen'
quality=read('quality-v8.json');assert len(quality)==12 and all(j['exit']==0 for j in quality)
source=read('candidate-source-manifest-v8.json');assert all(h(w/n)==v for n,v in source.items())
new=[n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines() if n.endswith(('.rs','.wgsl'))]
changed=[n for n in s['sources'] if source[n]!=s['sources'][n]]
contact=read('qualified-contact-v8.json');assert contact['screen_sha256']==h(w/'crates/mining-sim/src/screen.rs')
labels={'cpu':quality[0]['name'],'contact':'contact-unit-v28','worker':next(q['name'] for q in quality if 'worker::tests' in q['command']),'application':next(q['name'] for q in quality if q['command'][2:6]==['test','-p','mining','--bin'])}
counts={k:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(r/(label+'.log')).read_text()))) for k,label in labels.items()}
counts['actual_adapter']=sum(sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(r/(q['name']+'.log')).read_text()))) for q in quality[1:5]);counts['passed_total']=sum(counts.values())
trial=next(json.loads(line) for line in (r/'q8-gpu-screen.log').read_text().splitlines() if line.startswith('{"'));assert trial['ticks']==480 and trial['full_state_underflow_matches']>30 and trial['live_plant_restored']
bench={k:read('q8-'+k+'-benchmark.json') for k in ['before','after']}
for b in bench.values():assert b['failure'] is None and b['bulk_budget_passed'] and b['dry_mass_budget_passed'] and abs(b['gold_balance_error_g'])<1e-7 and abs(b['water_balance_error_m3'])<2e-5
native=read('analysis-v8.json');controls=read('q8-native-screen-controls/receipt.json');video=read('video-v8.json');cleanup=read('cleanup.json');assert controls['passed'] and video['passed'] and cleanup['exit']==0
original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose');installed=original/'target/bundles/First Bend.app/Contents/MacOS/mining'
assert h(installed)==s['app_sha256'];assert all(h(original/n)==v for n,v in s['original_files'].items());assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==s['stash'];assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes'])
owned=read('owned-tracker-rows.json');before=(r/'issues-before.jsonl').read_bytes();after=(w/'.beads/issues.jsonl').read_bytes();assert len(before.splitlines())==261 and len(after.splitlines())==262
assert [x for x in before.splitlines(keepends=True) if json.loads(x)['id'] not in owned]==[x for x in after.splitlines(keepends=True) if json.loads(x)['id'] not in owned]
candidate=r/'app-v8/First Bend.app';subprocess.run(['codesign','--verify','--deep','--strict',str(candidate)],check=True)
limits=['Installation is held for physical-time slowdown; previous signed app remains installed.','Plastic simultaneous impacts omit elastic preload/rebound; menace-sfu.2.1 remains required.','Dilute independent weighted physical-diameter spheres; no dense packing, cohesion, clay bridging, blinding or screen-water hydraulics.','Fixed typed circuit; general module placement, trommel, malfunctions, repairs and calibrated throughput/recovery remain required.','Underflow waits for a fresh unchanged two-tick sluice interval; no exact fractional-age coupling.','Bulk excavation/transport/hopper boundaries still discard grading/history; menace-sfu.1.2.','No full shift, empirical calibration or manual first/third-person control qualification claimed.','Wet access, bogging, slumps/deep cuts, surveys, constructed ponds/berm breaches, unstable tailings and flood/bridge incidents remain required.']
receipt={'stage':'First fixed dry-screen circuit, candidate held for performance','started_utc':s['started_utc'],'baseline_commit':s['head'],'goal_status':'active','full_operation_complete':False,'empirically_calibrated':False,'source_manifest':source,'changed_sources':changed,'new_sources':new,'focused_checks':counts,'full_workspace_suite_passed':False,'quality':quality,'contact':contact,'gpu_screen':trial,'native':native,'visual_review':read('visual-review.json'),'native_checks':read('native-checks-v8.json'),'native_controls':controls,'video':video,'benchmarks':bench,'earlier_same_fixture_benchmarks':{k:read(k+'.json') for k in ['after-benchmark','screen-cpu-profile','optimized-benchmark','optimized-profile']},'installation':{'performed':False,'reason':'Physical throughput remains below real time and the previous circuit; retain the previous playable app.','installed_executable':str(installed),'installed_executable_sha256':h(installed),'candidate':str(candidate),'candidate_executable_sha256':h(candidate/'Contents/MacOS/mining'),'candidate_signature_verified':True},'tracker':{'owned_ids':list(owned),'total_rows':262,'unrelated_literal_rows':261-sum(k in {json.loads(x)['id'] for x in before.splitlines()} for k in owned)},'preservation':{'nine_original_files_exact':True,'stash':s['stash'],'no_new_crash_reports':True,'cleanup':cleanup},'limits':limits}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));(w/(prefix+'.json')).write_bytes((r/'receipt.json').read_bytes());shutil.copyfile(r/'screen-model.md',w/'docs/physics/plant-screen.md')
for suffix,name in [('screen','q8-after-qualified-motion-screen-contact.jpg'),('plant','q8-after-qualified-motion-plant-contact.jpg'),('water','q8-qualified-sluice-comparison.jpg')]:shutil.copyfile(r/name,w/(prefix+'-'+suffix+'.jpg'))
shutil.copyfile(r/'q8-screen-motion.mp4',w/(prefix+'-screen.mp4'))
a,b=bench['before'],bench['after']
doc=f'''# First connected screen candidate — installation held

The finite hopper now feeds a saved moving wire screen, receiving gutter, original wet sluice and reject bin. The candidate demo includes this circuit. **This build is not installed:** the physical-time benchmark is too slow. The previous signed app stays in place. The complete Gold Rush operation remains active.

Near the hopper, on foot: **K** fits/stops/restarts the screen; **L** transfers all stopped screen stock and held water into the temporary unlimited hand; **M** cycles 3/6/12 mm apertures when stopped and entirely empty. Maintenance works while paused. F5/F9 retain finite stock, settings, phase and connections. Moving the connected sluice requires stopping and emptying the screen.

Real grain diameter interacts with moving wire capsules, gravity, friction, spin and the gutter. Oversize must contact the actual bin floor. Undersize enters the original sluice with complete position, velocity, orientation, spin and affine state; attached moisture becomes accounted feed water. Donors remain owned on refusal. Strict version14 saves retain the plant; old envelopes cannot silently hide its stock. Original water, riffle and terrain equations and numerical settings remain unchanged.

The [model and limits](../physics/plant-screen.md) describe the dilute dry screen. There is no dense bed, cohesion, clay bridging, blinding, spray/film solver, calibrated throughput/recovery, interchangeable trommel or general module placement. Simultaneous impacts explicitly use plastic response; isolated impacts retain configured rebound. Persistent elastic preload/rebound is required under `menace-sfu.2.1`. Numerical refusals are never called physical clogs. The logged GPU `collected_rejects` is the whole manual screen/bin cleanout, not a bin-only assay.

**{counts['passed_total']} focused checks pass:** {counts['cpu']} CPU integration, {counts['contact']} contact/geometry, {counts['worker']} worker, {counts['application']} app and {counts['actual_adapter']} actual Metal checks. Selected strict Clippy, formatting and signed packaging pass. This is not a full-workspace suite. The 480-tick real-pay Metal route verifies {trial['full_state_underflow_matches']} complete handoffs, live plant save/restore, actual underflow and caught oversize. Gold residual {trial['gold_error_g']:.4g}g; bulk {trial['bulk_error_m3']:.4g}m³; water {trial['water_error_m3']:.4g}m³.

## Performance and native review

The first native screen implementation measured about0.16x physical time while rendering around58FPS. CPU sampling found repeated contact roots and tiny matrix allocations. Stack elimination, residual-only line search, certified projected-map proposals, zero-projection early exits, immutable drive caching and conservative triangle rejection retain the existing contact tolerances, exact-phase CCD and physical step sizes. The first optimization measured0.34x on the same initial screen save, with all water/material budgets passing; evolving populations and workstation activity prevent treating these windows as controlled per-step speedup ratios.

| Final 20-second finite fixture | Previous circuit | Screen candidate |
|---|---:|---:|
| Render FPS | {a['mean_fps']:.2f} | {b['mean_fps']:.2f} |
| Physical seconds / wall second | {a['simulation_wall_ratio']:.5f} | {b['simulation_wall_ratio']:.5f} |
| Real-time acceptance | {a['passed']} | {b['passed']} |

The old fixture returns screen stock to its hopper, so these are different circuits, not a matched algorithm-only comparison. Both physical-time results are reported separately from FPS. The final screen remains below real time and is held from installation. `sluice-realtime` and `menace-sfu.2` remain in progress.

Reviewed {native['native_frames']} final-candidate native samples across screen, plant, sluice, outlet and river, including requested30Hz screen/plant sampling. Actual capture cadence is retained in the frame records and video. The native synthetic-keyboard replay passes pause, stop, whole cleanout, aperture change, save, reload and restart checks, with seven screenshots. This does not qualify manual driving. Three fresh frozen comparisons preserve flow, tracked water, surface samples and machine state; the earlier demo comparisons remain historical evidence. Close screen wires visibly alias and weighted grain proxies remain sparse. The finite hopper stock lacks a visible fill surface. Sluice crests/mineral proxies and river shoreline/optics remain provisional; no water-rendering improvement is claimed in this stage. The short low-flow fixture outlet view alone does not establish a natural developed discharge; the demo outlet and frame records are also retained.

![Native screen samples](2026-10-27-plant-screen-screen.jpg)

![Native plant samples](2026-10-27-plant-screen-plant.jpg)

[Actual native video](2026-10-27-plant-screen-screen.mp4) · [Frozen water comparison](2026-10-27-plant-screen-water.jpg) · [Receipt](2026-10-27-plant-screen.json) · [Evidence and failed historical attempts](2026-10-27-plant-screen-reports.zip)

Only one task-owned heavy job ran at a time; jobs queued when global capacity was full. No new panic/WindowServer reports appeared. Scoped cleanup ran. The nine original dirty files, stash and installed signed app remain exact. Only four owned tracker rows change/add;258 unrelated rows remain literal. Beads1.0.4 has no sync command; scoped rows are committed with the verified code instead of a tracker-wide export.

The [operation plan](../../plans/2026-10-22-realistic-operation.md) still requires wet/dense processing and clogs, trommel/shaker options and failures, configuration/upgrades, transport, constructed pads/ponds/berms/recirculation, calibrated washout/recovery, finite surveyed geology, wet access/dewatering, bogging, slumps/deep-cut collapse, tailings instability and flood/bridge failures. This candidate does not complete the goal.
'''
(w/(prefix+'.md')).write_text(doc)
p=w/'plans/2026-10-22-realistic-operation.md';text=p.read_text();text='\n'.join(line for line in text.splitlines() if not line.startswith('27 October: the [first connected dry-screen candidate]')).rstrip()+'\n';text=text.replace('The playable Session owns one sluice. Archived screen/trommel/shaker prototypes are not integrated plant components.','A saved fixed dry screen/gutter/reject circuit now connects finite feed to the original wet sluice in the candidate. Installation is held for physical-time slowdown; wet/dense processing, calibration and interchangeable trommel remain required.').replace('No persisted modular plant/port configuration or upgrade loop currently exists. Upgrades must not become a fixed recovery-percentage bonus.','The first fixed typed circuit and stopped/empty aperture changes are saved in the candidate. General placement, connections, replacements and upgrades remain required. Upgrades must not become a fixed recovery-percentage bonus.');p.write_text(text+f'\n27 October: the [first connected dry-screen candidate](../docs/playtests/2026-10-27-plant-screen.md) passes {counts["passed_total"]} focused CPU/app/Metal checks and native maintenance/save replay. Final {b["mean_fps"]:.2f}FPS / {b["simulation_wall_ratio"]:.5f}x physical time fails real time; installation is held and the previous signed app stays installed. Screen CPU work was profiled and reduced without coarsening original water/contact settings. This remains dilute dry processing, not dense wet screening or calibrated recovery. `menace-sfu.2`, `sluice-realtime`, the full-shift parent and every unfinished operation/failure requirement remain active.\n')
omitted={p.name:{'bytes':p.stat().st_size,'sha256':h(p),'retained_local':str(p)} for p in r.iterdir() if p.is_file() and (p.name.endswith('.save.json') or p.name.endswith('-unused.json') and p.name!='q8-native-screen-controls-unused.json')}
(r/'omitted-redundant-endpoint-saves.json').write_text(json.dumps({'reason':'Keep the archive under the GitHub file limit. Original fixture pairs, final actual maintenance save and all benchmark reports remain included. Redundant benchmark endpoint snapshots stay in local evidence.','files':omitted},indent=2))
with zipfile.ZipFile(w/(prefix+'-reports.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in r.iterdir():
        if p.is_file() and p.name not in omitted and p.suffix in ['.json','.log','.py','.txt','.stderr','.md']:z.write(p,p.name)
    for p in r.glob('q8-*/frames.json'):z.write(p,str(p.relative_to(r)))
    for directory in ['gpu-fixtures','gpu-fixtures-v8','q8-native-screen-controls']:
        for p in (r/directory).glob('*.json'):z.write(p,str(p.relative_to(r)))
    for n in changed+new:z.write(w/n,'source/'+n)
    assert z.testzip() is None
assert (w/(prefix+'-reports.zip')).stat().st_size<95_000_000
print(json.dumps({'checks':counts,'native_frames':native['native_frames'],'installation':'held','sources':changed+new},indent=2))
