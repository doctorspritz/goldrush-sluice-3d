from pathlib import Path
import json,os,hashlib,shutil,subprocess,time
r=Path(__file__).parent;s=json.loads((r/'start.json').read_text());installed=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/bundles/First Bend.app');candidate=r/'app-v6/First Bend.app';backup=r/'previous-app/First Bend.app';staging=installed.parent/'First Bend.plant-screen-20261027.app';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes']);assert h(installed/'Contents/MacOS/mining')==s['app_sha256'];assert not backup.exists() and not staging.exists();assert installed.stat().st_dev==r.stat().st_dev
parents={int(a):int(b) for a,b in (line.split() for line in subprocess.check_output(['ps','-axo','pid=,ppid='],text=True).splitlines())}
heavy={}
for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines():
 a=line.strip().split(None,1)
 if len(a)==2 and Path(a[1]).name in ['cargo','rustc','slurry-transport-after','mining','chrome-headless-shell']:heavy[int(a[0])]=Path(a[1]).name
roots=[]
for pid,name in heavy.items():
 ancestor=parents.get(pid,0);seen=set();child=False
 while ancestor and ancestor not in seen:
  if ancestor in heavy:child=True;break
  seen.add(ancestor);ancestor=parents.get(ancestor,0)
 if not child:roots.append({'pid':pid,'name':name})
(r/'install-existing-heavy-roots.json').write_text(json.dumps(roots,indent=2))
assert len(roots)<2,roots
status=json.loads(subprocess.check_output(['python3',str(r/'process-status.py')],text=True));assert status['available'],status
assert not any(name=='mining' for name in heavy.values()),'A mining app is already running; leave it untouched'
for app in [installed,candidate]:subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
def manifest(p):return {str(x.relative_to(p)):h(x) for x in p.rglob('*') if x.is_file()}
old=manifest(installed);new=manifest(candidate);shutil.copytree(candidate,staging,symlinks=True);assert manifest(staging)==new
backup.parent.mkdir();installed.rename(backup)
try:staging.rename(installed)
except BaseException:backup.rename(installed);raise
assert manifest(backup)==old and manifest(installed)==new;subprocess.run(['codesign','--verify','--deep','--strict',str(installed)],check=True)
name='installed-smoke';args=[str(installed/'Contents/MacOS/mining'),'--load',str(r/'gpu-fixtures-v6/modern.save.json'),'--freeze','--capture-motion',str(r/name),'--capture-view','sluice','--capture-seconds','1','--capture-hz','2'];env={**os.environ,'SLUICE_SAVE_PATH':str(r/'installed-unused.json')};p=subprocess.run(['python3',str(r/'supervise.py'),'--seconds','100','--log',str(r/(name+'.log')),'--',*args],env=env,capture_output=True,text=True);(r/(name+'-driver.log')).write_text(p.stdout+p.stderr);p.check_returncode();j=json.loads((r/name/'frames.json').read_text());assert j['passed'];result={'installed':str(installed),'backup':str(backup),'previous_executable_sha256':s['app_sha256'],'installed_executable_sha256':h(installed/'Contents/MacOS/mining'),'candidate_manifest':new,'backup_manifest':old,'installed_manifest_matches_candidate':True,'backup_manifest_matches_original':True,'signature_verified':True,'smoke_passed':True,'smoke_command':args};(r/'installed.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if not k.endswith('manifest')},indent=2))

candidate=json.loads((r/'q6-after-qualified-frozen-sluice/frames.json').read_text());a=candidate['frames'][0];b=j['frames'][0]
for field in ['sim_time','flow','tracks','surface','machine','tailings','loose_gold','plant']:
 assert a[field]==b[field],field
(r/'installed-state-equality.json').write_text(json.dumps({'fields_equal':['sim_time','flow','tracks','surface','machine','tailings','loose_gold','plant'],'qualified_candidate':str(r/'q6-after-qualified-frozen-sluice'),'installed_smoke':str(r/'installed-smoke')},indent=2))

from PIL import Image,ImageChops
a=candidate['frames'][0];b=j['frames'][0]
with Image.open(r/'q6-after-qualified-frozen-sluice'/a['file']) as one, Image.open(r/'installed-smoke'/b['file']) as two:
 assert one.size==two.size and ImageChops.difference(one.convert('RGB'),two.convert('RGB')).getbbox() is None
p=r/'installed-state-equality.json';e=json.loads(p.read_text());e['rgb_equal']=True;p.write_text(json.dumps(e,indent=2))
