from pathlib import Path
import subprocess,json
r=Path(__file__).parent;w=Path.cwd()
def bd(label,*args):
    p=subprocess.run(['bd','--sandbox',*args,'--json'],capture_output=True,text=True)
    (r/(label+'.stderr')).write_text(p.stderr);p.check_returncode();j=json.loads(p.stdout)
    (r/(label+'.json')).write_text(json.dumps(j,indent=2));return j
quality=json.loads((r/'quality-v8.json').read_text());assert len(quality)==12 and all(j['exit']==0 for j in quality)
assert json.loads((r/'q8-native-screen-controls/receipt.json').read_text())['passed']
b=json.loads((r/'q8-after-benchmark.json').read_text());assert b['failure'] is None and not b['passed']
notes='First fixed dry-screen candidate connects finite hopper stock, moving wire capsules, receiving gutter, original wet sluice and actual caught rejects. Full-state handoff, stopped maintenance/aperture changes, paused controls and strict v14 continuation are implemented. Focused CPU/actual Metal/native maintenance-save evidence is in docs/playtests/2026-10-27-plant-screen.md. Installation is HELD for physical-time slowdown; previous signed app remains untouched. Keep IN_PROGRESS: dilute independent weighted spheres, no dense packing, cohesion/clay bridging, blinding, coupled spray/film/slurry screen hydraulics, calibrated throughput, general module placement or trommel. Simultaneous contacts explicitly use plastic response and isolated rebound remains; persistent elastic preload/rebound is required under menace-sfu.2.1. Numerical work/storage refusals are not physical clogs. Upstream grading/history remains menace-sfu.1.2. Visual followups: finite hopper stock lacks a visible fill surface; close screen wires alias; reject records are not a resolved rising packed pile. Full wet-ground, operation and failure scope remains required.'
bd('screen-qualified-held','update','menace-sfu.2','--status','in_progress','--append-notes',notes)
bd('shift-progress-held','update','menace-sfu','--append-notes','First fixed dry-screen candidate connects finite hopper feed, moving wires/gutter, original wet sluice and retained rejects. Native maintenance/save/restart and actual Metal integration checks pass. Installation is held for physical-time slowdown; no new playable build is claimed. See docs/playtests/2026-10-27-plant-screen.md. Keep full shift IN_PROGRESS: wet/dense processing, trommel/shaker options and failures, haulage, ponds/recirculation, progressive clogging and washout, calibration, surveys, wet access, bogging, slumps/deep cuts, berm/tailings/flood/bridge incidents all remain required. No parent closes.')
bd('screen-realtime-held','update','sluice-realtime','--status','in_progress','--append-notes',f'27 Oct connected-screen candidate: initial native physical rate about0.16x; CPU sample found reduced contact roots/allocations. Stack pivot elimination, residual-only line search, certified exact-Jacobian proposals, feasible-zero projection, immutable drive cache and conservative static-triangle AABB rejection preserve physical steps, exact-phase CCD, geometry, friction/restitution policy and water/riffle/terrain settings. Intermediate same-save window0.34x. Final candidate {b["mean_fps"]:.2f} render FPS / {b["simulation_wall_ratio"]:.5f} physical seconds per wall second. Real-time FAILED and installation HELD; previous signed app unchanged. Focused CPU/Metal/app and native maintenance/save checks pass, but do not establish physical-time performance or empirical accuracy. Next profile remaining screen CCD/geometry and original GPU fluid/readback; no coarsening or fabricated animation. Evidence docs/playtests/2026-10-27-plant-screen.md. Keep issue and complete operation active.')
ids=['menace-sfu.2','menace-sfu','sluice-realtime','menace-sfu.2.1']
before=(r/'issues-before.jsonl').read_bytes();existing={json.loads(line)['id']:json.loads(line) for line in before.splitlines()};owned={};display={'parent','dependents','epic_total_children','epic_closed_children','epic_closeable'}
for id in ids:
    fresh=bd('held-final-'+id,'--readonly','show',id)[0];row=dict(existing.get(id,{}));row.update({k:v for k,v in fresh.items() if k not in display and k!='dependencies'})
    if 'dependencies' in fresh:row['dependencies']=[{'issue_id':id,'depends_on_id':d.get('depends_on_id',d.get('id')),'type':d.get('type',d.get('dependency_type'))} for d in fresh['dependencies']]
    owned[id]=row
lines=[]
for line in before.splitlines(keepends=True):
    id=json.loads(line)['id'];lines.append((json.dumps(owned[id],separators=(',',':'),ensure_ascii=False)+'\n').encode() if id in owned else line)
lines.extend((json.dumps(row,separators=(',',':'),ensure_ascii=False)+'\n').encode() for id,row in owned.items() if id not in existing)
out=b''.join(lines);assert len(before.splitlines())==261 and len(out.splitlines())==262
assert [line for line in before.splitlines(keepends=True) if json.loads(line)['id'] not in owned]==[line for line in out.splitlines(keepends=True) if json.loads(line)['id'] not in owned]
assert all(owned[id]['status']=='in_progress' for id in ids[:3]) and owned[ids[3]]['status']=='open'
assert (w/'.beads/issues.jsonl').read_bytes()==before
(w/'.beads/issues.jsonl').write_bytes(out);(r/'owned-tracker-rows.json').write_text(json.dumps(owned,indent=2));print({'owned_rows':4,'unrelated_literal_rows':258,'total_rows':262})
