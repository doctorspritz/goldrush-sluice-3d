from pathlib import Path
import subprocess,json,hashlib,zipfile
w=Path.cwd();r=Path(__file__).parent;s=json.loads((r/'start.json').read_text());receipt=json.loads((r/'receipt.json').read_text());commands=[]
def run(*args,input=None):
 p=subprocess.run(args,input=input,capture_output=True,text=True);commands.append({'args':list(args),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(r/'landing-commands.json').write_text(json.dumps(commands,indent=2));p.check_returncode();return p.stdout.rstrip('\n')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='docs/playtests/2026-10-27-plant-screen'
files=['.beads/issues.jsonl',*receipt['changed_sources'],*receipt['new_sources'],'docs/physics/plant-screen.md','plans/2026-10-22-realistic-operation.md',*[prefix+q for q in ['.md','.json','-reports.zip','-screen.jpg','-plant.jpg','-water.jpg','-screen.mp4']]]
assert len(set(files))==len(files);fingerprints={n:h(w/n) for n in files};(r/'final-file-manifest.json').write_text(json.dumps(fingerprints,indent=2))
def custody():
 assert all(h(w/n)==v for n,v in receipt['source_manifest'].items())
 assert all(h(w/n)==v for n,v in fingerprints.items())
 original=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose');assert all(h(original/n)==v for n,v in s['original_files'].items());assert subprocess.check_output(['git','rev-parse','refs/stash'],cwd=original,text=True).strip()==s['stash']
 a=receipt['installed'];assert h(Path(a['installed'])/'Contents/MacOS/mining')==a['installed_executable_sha256'];assert {str(p.relative_to(Path(a['backup']))):h(p) for p in Path(a['backup']).rglob('*') if p.is_file()}==a['backup_manifest']
 assert not {p.name for p in Path('/Library/Logs/DiagnosticReports').iterdir() if p.name.startswith(('panic-full-','.WindowServer-'))}-set(s['crashes'])
 assert (r/'receipt.json').read_bytes()==(w/(prefix+'.json')).read_bytes()
 old=(r/'issues-before.jsonl').read_bytes();new=(w/'.beads/issues.jsonl').read_bytes();owned=json.loads((r/'owned-tracker-rows.json').read_text());assert len(old.splitlines())==261 and len(new.splitlines())==262 and len(owned)==3
 assert [line for line in old.splitlines(keepends=True) if json.loads(line)['id'] not in owned]==[line for line in new.splitlines(keepends=True) if json.loads(line)['id'] not in owned]
 assert {j['id']:j for line in new.splitlines() if (j:=json.loads(line))['id'] in owned}==owned
 assert all(q['exit']==0 for q in receipt['quality']) and len(receipt['quality'])==12
 assert receipt['gpu_screen']['full_state_underflow_matches']>30 and receipt['gpu_screen']['live_plant_restored']
 assert all(j['passed'] for j in receipt['native']['native_reports'].values()) and receipt['installed_equality']['rgb_equal']
 assert receipt['native_controls']['passed'] and receipt['video']['passed']
 assert not receipt['empirically_calibrated'] and not receipt['full_operation_complete'] and receipt['goal_status']=='active'
 assert all(j['bulk_budget_passed'] and j['dry_mass_budget_passed'] and j['failure'] is None for j in receipt['benchmarks'].values())
 assert receipt['preservation']['cleanup']['exit']==0
 with zipfile.ZipFile(w/(prefix+'-reports.zip')) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
  for n in receipt['changed_sources']+receipt['new_sources']:assert z.read('source/'+n)==(w/n).read_bytes()
  for n in ['modern.save.json','legacy-render.save.json']:assert z.read('gpu-fixtures/'+n)==(r/'gpu-fixtures'/n).read_bytes()
custody();assert run('git','rev-parse','HEAD')==s['head'];assert run('git','branch','--show-current')=='codex/direct-mining';assert not run('git','diff','--cached','--name-only');assert {line[3:] for line in run('git','status','--porcelain','-uall').splitlines()}==set(files)
assert run('git','remote','get-url','origin')=='https://github.com/doctorspritz/goldrush-sluice-3d.git'
assert json.loads(run('gh','repo','view','--json','nameWithOwner,isPrivate,viewerPermission'))=={'nameWithOwner':'doctorspritz/goldrush-sluice-3d','isPrivate':False,'viewerPermission':'ADMIN'}
run('git','fetch','--prune','origin');assert run('git','rev-parse','origin/codex/direct-mining')==s['head'],'Remote changed: inspect before landing';run('git','merge-base','--is-ancestor','origin/main','HEAD');run('git','diff','--check');run('git','add','--',*files);assert set(run('git','diff','--cached','--name-only').splitlines())==set(files);run('git','diff','--cached','--check');(r/'staged-stat.txt').write_text(run('git','diff','--cached','--stat'));custody()
# Preserve shared hooks/config. The tracker-wide hook export was previously
# rejected; land exact owned rows with explicit qualified checks, no global
# bd export, no hook/trust edits and no unrelated tracker/stash mutation.
tree=run('git','write-tree');c=receipt['focused_checks'];b=receipt['benchmarks']['after']
message=f'''feat(mining): connect finite hopper screen and original wet sluice

Add a saved fixed circuit, physical wire/gutter/bin geometry, finite real
feed, complete underflow state and retained rejects/spills. Keep the wet
sluice/riffle/terrain equations unchanged. Add stopped maintenance and
aperture changes, paused controls and strict version14 ownership.

Declare plastic simultaneous sphere impacts and isolated rebound after
proving the old coupled Newton/Coulomb law incompatible for real pay.
Preserve actual geometry, friction and work/energy guards. Retain the
elastic-preload/rebound followup menace-sfu.2.1 and all wet/dense screen,
trommel/haulage/pond/full-operation work; no empirical calibration claim.

Pass {c['passed_total']} focused CPU/worker/app/Metal checks, selected strict
lint and format, signed packaging and native maintenance/save replay.
Inspect real motion and preserve six frozen water comparisons. Record
{b['mean_fps']:.2f}FPS and {b['simulation_wall_ratio']:.5f}x physical time separately.
Verify installed state/RGB and preserve the previous signed app, nine
original dirty files and stash. Update only scoped tracker rows and keep
the complete Gold Rush goal active.
''';(r/'commit-message.txt').write_text(message)
commit=run('git','commit-tree',tree,'-p',s['head'],input=message);run('git','update-ref','-m','commit: first fixed screen circuit','HEAD',commit,s['head']);assert not run('git','status','--porcelain','-uall');run('git','pull','--rebase','--prune');assert run('git','rev-parse','HEAD')==commit;run('git','push','origin','HEAD:refs/heads/codex/direct-mining');remote=run('git','ls-remote','origin','refs/heads/codex/direct-mining').split()[0];assert remote==run('git','rev-parse','@{upstream}')==commit;assert not run('git','status','--porcelain','-uall');custody();result={'commit':commit,'remote':remote,'all_owned_changes_committed_and_pushed':True,'status':run('git','status','--short','--branch'),'preservation_verified':True,'files':files};(r/'landing.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
