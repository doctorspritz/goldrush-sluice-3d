from pathlib import Path
import json,math
from PIL import Image,ImageChops,ImageDraw
r=Path(__file__).parent;reports={};sheets=[];comparisons=[]
for p in sorted(r.glob('q6-*/frames.json')):
    j=json.loads(p.read_text());assert j['passed'],p
    frames=j['frames'];assert frames
    for f in frames:assert (p.parent/f['file']).is_file()
    reports[p.parent.name]={'frames':len(frames),'passed':j['passed'],'first_sim_time':frames[0]['sim_time'],'last_sim_time':frames[-1]['sim_time'],'water_balance_error_m3':j['water_balance_error_m3'],'gold_balance_error_g':j['gold_balance_error_g']}
    if 'motion' not in p.parent.name:continue
    canvas=Image.new('RGB',(1440,math.ceil(len(frames)/6)*174),(18,24,24));draw=ImageDraw.Draw(canvas)
    for i,f in enumerate(frames):
        with Image.open(p.parent/f['file']) as im:
            im=im.convert('RGB');im.thumbnail((240,150));canvas.paste(im,((i%6)*240,(i//6)*174+24))
        draw.text(((i%6)*240+5,(i//6)*174+5),f"{i} / {f['sim_time']:.3f}s",fill=(240,240,240))
        plant=f.get('plant')
        if plant:
            s=plant['screen'];assert s['motor_on']
            assert s['config']['aperture_m']==.003
    name=p.parent.name+'-contact.jpg';canvas.save(r/name,quality=88);sheets.append(name)
    if frames[0].get('plant'):
        a,b=frames[0]['plant'],frames[-1]['plant'];assert b['screen']['time']>a['screen']['time']
        reports[p.parent.name]['plant_first_last']=[{k:f['plant']['screen'][k] for k in ['time','particles','undersize','oversize','spills','admitted','delivered']} for f in [frames[0],frames[-1]]]
for scene in ['demo','qualified']:
    for view in ['sluice','outlet','river']:
        before=r/f'q6-before-{scene}-frozen-{view}';after=r/f'q6-after-{scene}-frozen-{view}'
        a=json.loads((before/'frames.json').read_text())['frames'][0];b=json.loads((after/'frames.json').read_text())['frames'][0]
        row={'scene':scene,'view':view,'flow_equal':a['flow']==b['flow'],'water_tracks_equal':a['tracks']==b['tracks'],'surface_samples_equal':a['surface']==b['surface'],'machine_equal':a['machine']==b['machine']}
        with Image.open(before/a['file']) as old,Image.open(after/b['file']) as new:
            diff=ImageChops.difference(old.convert('RGB'),new.convert('RGB'));row['different_rgb_pixels']=sum(max(v)>0 for v in diff.getdata());row['total_pixels']=old.width*old.height
            comparison=Image.new('RGB',(1440,480),(18,24,24));d=ImageDraw.Draw(comparison)
            for index,(im,label) in enumerate([(old,'Previous circuit'),(new,'Integrated moving screen')]):
                im=im.convert('RGB');im.thumbnail((720,450));comparison.paste(im,(index*720,30));d.text((index*720+8,8),f'{scene} / {view} / {label}',fill=(240,240,240))
            comparison.save(r/f'q6-{scene}-{view}-comparison.jpg',quality=90)
        assert all(row[k] for k in ['flow_equal','water_tracks_equal','surface_samples_equal','machine_equal']),row
        comparisons.append(row)
modern=json.loads((r/'gpu-fixtures-v6/modern.save.json').read_text());legacy=json.loads((r/'gpu-fixtures-v6/legacy-render.save.json').read_text())
assert modern['site']==legacy['site']
assert {k:v for k,v in modern['sluice'].items() if k not in ['hopper','feed_water_credit_m3']}=={k:v for k,v in legacy['sluice'].items() if k not in ['hopper','feed_water_credit_m3']}
result={'native_reports':reports,'native_frames':sum(j['frames'] for j in reports.values()),'frozen_comparisons':comparisons,'fixture_site_equal':True,'fixture_sluice_equal_except_plant_inventory_returned_to_hopper_and_water_credit':True,'motion_contact_sheets':sheets,'limits':['Dry dilute moving screen; no dense packing, cohesion, blinding or coupled screen-water solver.','Paired fixture returns active screen material to the old hopper; whole circuits/runtime policies differ.','Native capture affects cadence; benchmark is reported separately.','Visible proxies and the first dry circuit do not establish calibrated processing or a complete shift.']}
(r/'analysis-v6.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['native_reports','frozen_comparisons']},indent=2))
