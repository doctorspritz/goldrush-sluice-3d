from pathlib import Path
p=Path('/Users/simonheikkila/.codex/worktrees/direct-mining/the-sluice-moose/crates/mining-sim/src/screen.rs')
s=p.read_text()
start=s.index('        // A bounded exact-Jacobian proposal')
end=s.index('        use ContactMode::{Open, Slide, Stick};',start)
s=s[:start]+s[end:]
needle='''            trial.mode = Some(modes);
            let Some(response)'''
assert s.count(needle)==1
s=s.replace(needle,'''            // Keep the original double-stick branch first. For the other
            // modes an exact-Jacobian proposal can avoid repeated seed
            // searches. It changes no law/tolerance and must certify every
            // original contact and the final boundary-work energy gate.
            if modes == [Slide, Stick] {
                let mut fast = self.contact_trial(problem, mu, &zero, 8)?;
                if fast.converged {
                    self.count_query()?;
                    if let Some(state) = problem.evaluate(&fast.impulses, mu) {
                        let inferred = std::array::from_fn(|i| {
                            let row = &problem.rows[i];
                            if state.normal_impulse(i) <= 1e-9
                                && fast.impulses[2*i].hypot(fast.impulses[2*i+1]) < 1e-10 {
                                Open
                            } else {
                                let n = row.hit.normal;
                                let relative = state.velocity + state.scaled_spin.cross(-n) - row.hit.velocity;
                                if (relative - n * relative.dot(n)).length() < 3.5e-10 { Stick } else { Slide }
                            }
                        });
                        if contact_candidate(problem, inferred, &fast.impulses, mu) {
                            fast.mode = Some(inferred);
                            return Ok(ContactSolution { iterations: fast.iterations, trial: fast, trial_mu: mu, seed_attempts: 0 });
                        }
                    }
                }
            }
            trial.mode = Some(modes);
            let Some(response)''')
needle='''fn halfspace_projection(rows: &[(DVec3, f64)]) -> Option<Projection> {
    let mut best'''
assert s.count(needle)==1
s=s.replace(needle,'''fn halfspace_projection(rows: &[(DVec3, f64)]) -> Option<Projection> {
    // The original empty active set is already the unique minimum-norm
    // correction when feasible. Enumerating nonzero faces cannot improve it.
    if rows.iter().all(|(n, b)| n.dot(DVec3::ZERO) >= *b - 1e-12) {
        return Some(Projection { point: DVec3::ZERO, active: [(0, 0.); 3], count: 0 });
    }
    let mut best''')
needle='''    #[test]
    fn captured_open_neighbor_is_not_a_restitution_support()'''
assert s.count(needle)==1
s=s.replace(needle,'''    #[test]
    fn stack_contact_elimination_preserves_complete_pivoting() {
        for seed in 0..512 {
            let mut state = seed as u64 + 1;
            let mut next = || {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
                ((state >> 32) % 2001) as f64 / 1000. - 1.
            };
            let mut matrix: [[f64;4];4] = std::array::from_fn(|_| std::array::from_fn(|_| next()));
            if seed % 3 == 0 { matrix[3] = matrix[1]; }
            if seed % 7 == 0 { matrix[2] = [0.;4]; }
            let rhs = std::array::from_fn(|_| next());
            let dynamic = rank_solve(matrix.map(|row| row.to_vec()).to_vec(), &rhs);
            let fixed = rank_solve_fixed(matrix, rhs).map(|x| x.to_vec());
            assert_eq!(dynamic, fixed);
        }
    }
    #[test]
    fn residual_only_line_search_preserves_the_reduced_contact_map() {
        let normals = [DVec3::new(0.8,0.6,0.), DVec3::new(-0.8,0.6,0.)];
        let rows: Vec<_> = normals.into_iter().enumerate().map(|(index, normal)| Contact {
            hit: Hit { u:0., normal, velocity:DVec3::ZERO, surface:Surface::Wire, index }, target:0.
        }).collect();
        let bases:Vec<_> = normals.into_iter().map(tangent_basis).collect();
        let problem = ContactProblem { rows:&rows, bases:&bases, velocity:DVec3::new(0.2,-0.5,0.3), spin:DVec3::new(0.1,0.2,0.3) };
        for modes in [[ContactMode::Slide,ContactMode::Stick], [ContactMode::Stick,ContactMode::Slide], [ContactMode::Slide,ContactMode::Slide]] {
            let response = contact_response(&problem,[true,true]).unwrap();
            for exponent in -6..=6 {
                let logs = vec![(3.5_f64 * 10_f64.powi(exponent)).ln(); modes.iter().filter(|m| **m == ContactMode::Slide).count()];
                let full = reduced_contact(&response,modes,0.4,&logs);
                let residual = reduced_contact_value(&response,modes,0.4,&logs,false);
                if let Some(full) = full {
                    let residual = residual.unwrap();
                    assert_eq!(full.tangent, residual.tangent);
                    assert_eq!(full.residual, residual.residual);
                }
            }
        }
    }
    #[test]
    fn captured_open_neighbor_is_not_a_restitution_support()''')
p.write_text(s)
print('Preserved sticking precedence, inferred certified modes, added equivalent-elimination controls.')
