from pathlib import Path
import subprocess,json,sys
r=Path(__file__).parent;tag=sys.argv[1];checks=[]
common=['--profile','playable','--locked','--jobs','1']
commands=[('contact-unit-'+tag,['cargo','+nightly','test','-p','mining-sim','--lib','screen::tests']+common+['--','--test-threads=1','--nocapture']),('contact-plant-'+tag,['cargo','+nightly','test','-p','mining-sim','--test','plant','finite_dug_hopper_runs_through_screen_gutter_and_into_existing_sluice']+common+['--','--exact','--test-threads=1','--nocapture'])]
for label,args in commands:
 p=subprocess.run(['python3',str(r/'run.py'),label,*args],capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'name':label,'command':args,'exit':p.returncode});(r/('contact-'+tag+'.json')).write_text(json.dumps(checks,indent=2));print(checks[-1],flush=True)
 if p.returncode:print(p.stdout[-4500:]);sys.exit(p.returncode)
