from pathlib import Path
import json

r=Path(__file__).parent
p=Path('/Users/simonheikkila/.codex/worktrees/direct-mining/the-sluice-moose/crates/mining-sim/src/screen.rs')
s=p.read_text()
(r/'screen-before-contact-optimization.rs').write_text(s)

def replace(a,b):
    global s
    assert s.count(a)==1, (s.count(a),a[:100])
    s=s.replace(a,b)

replace('        seed: &[f64],\n    ) -> Result<ContactTrial, String> {','        seed: &[f64],\n        sweeps: usize,\n    ) -> Result<ContactTrial, String> {')
replace('        for _ in 0..MANIFOLD_SWEEPS {\n            result.iterations', '        for _ in 0..sweeps {\n            result.iterations')
replace('            let jacobian = projected_contact_jacobian(problem, &state, &x, mu)\n                .ok_or("Screen projected contact derivative is singular; state retained")?;', '            let jacobian = projected_contact_jacobian(problem, &state, &x, mu);')
replace('for (kind, direction) in [rank_solve(jacobian, &rhs), Some(rhs)]','for (kind, direction) in [jacobian.and_then(|j| rank_solve(j, &rhs)), Some(rhs)]')
replace('            let trial = self.contact_trial(problem, mu, &vec![0.; problem.rows.len() * 2])?;', '            let trial = self.contact_trial(problem, mu, &zero, MANIFOLD_SWEEPS)?;')
replace('        use ContactMode::{Open, Slide, Stick};','''        // A bounded exact-Jacobian proposal usually certifies a two-contact
        // root before the exhaustive mode/seed search. It changes neither
        // the Coulomb map nor its tolerances; unsuccessful proposals leave
        // the complete reduced search available. The final original map and
        // boundary-work gate still decide whether state may advance.
        let fast = self.contact_trial(problem, mu, &zero, 8)?;
        if fast.converged {
            return Ok(ContactSolution {
                iterations: fast.iterations,
                trial: fast,
                trial_mu: mu,
                seed_attempts: 0,
            });
        }
        use ContactMode::{Open, Slide, Stick};''')
replace('reduced_contact(&response, modes, mu, &candidate)', 'reduced_contact_value(&response, modes, mu, &candidate, false)')
replace('''    let mut matrix = response.mobility.map(|row| row.to_vec()).to_vec();
    let mut rhs = response.offset.map(|v| -v).to_vec();''','''    reduced_contact_value(response, modes, mu, logs, true)
}
fn reduced_contact_value(
    response: &ContactResponse,
    modes: [ContactMode; 2],
    mu: f64,
    logs: &[f64],
    derivative: bool,
) -> Option<ReducedContact> {
    let mut matrix = response.mobility;
    let mut rhs = response.offset.map(|v| -v);''')
replace('let tangent = rank_solve(matrix.clone(), &rhs)?;', 'let tangent = rank_solve_fixed(matrix, rhs)?;')
replace('''    for (column, source) in slides.iter().enumerate() {
        let mut rhs = vec![0.; 4];''', '''    for (column, source) in slides.iter().enumerate().filter(|_| derivative) {
        let mut rhs = [0.; 4];''')
replace('let delta = rank_solve(matrix.clone(), &rhs)?;', 'let delta = rank_solve_fixed(matrix, rhs)?;')
replace('''    Some(ReducedContact {
        tangent,
        residual,''', '''    Some(ReducedContact {
        tangent: tangent.to_vec(),
        residual,''')
start=s.index('fn rank_solve(mut matrix:')
end=s.index('\nfn quad(',start)
fixed=s[start:end].replace('fn rank_solve(mut matrix: Vec<Vec<f64>>, rhs: &[f64]) -> Option<Vec<f64>> {','fn rank_solve_fixed<const N: usize>(mut matrix: [[f64; N]; N], rhs: [f64; N]) -> Option<[f64; N]> {').replace('let size = rhs.len();','let size = N;').replace('let mut b = rhs.to_vec();','let mut b = rhs;').replace('let mut order: Vec<_> = (0..size).collect();','let mut order: [usize; N] = std::array::from_fn(|i| i);').replace('let mut permuted = vec![0.; size];','let mut permuted = [0.; N];').replace('let mut result = vec![0.; size];','let mut result = [0.; N];')
s=s[:end]+ '\n/// Stack storage preserves complete-pivot order and rank thresholds.\n#[allow(clippy::needless_range_loop, reason = "Complete pivoting uses explicit indices")]\n'+fixed+s[end:]
p.write_text(s)
(r/'pending-status.json').write_text(json.dumps({'goal_status':'active','candidate_qualified':False,'installed_app_unchanged':True,'last_attempt':'Native profile found 0.1565x physical time; contact optimization awaiting CPU and native qualification','installation_hold':'screen simulation slowdown','head':'9dd35d188e5e1ecdf2848721a6d9141a27f9ac8f'},indent=2))
print('Applied contact acceleration; source snapshot retained. Qualification pending.')
