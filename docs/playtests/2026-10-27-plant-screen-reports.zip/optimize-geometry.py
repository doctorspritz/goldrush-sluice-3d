from pathlib import Path
r=Path(__file__).parent
p=Path('/Users/simonheikkila/.codex/worktrees/direct-mining/the-sluice-moose/crates/mining-sim/src/screen.rs')
s=p.read_text();(r/'screen-before-geometry-cache.rs').write_text(s)
def replace(a,b):
    global s
    assert s.count(a)==1,(s.count(a),a[:80])
    s=s.replace(a,b)
replace('    next_id: u64,\n}', '''    next_id: u64,
    /// Transaction-local immutable geometry; never persisted or retained by
    /// a completed step. Configuration changes cannot leave a stale cache.
    #[serde(skip)]
    frame: Option<ScreenFrame>,
}
#[derive(Clone, Copy, Debug)]
struct ScreenFrame {
    downstream: DVec3,
    across: DVec3,
    normal: DVec3,
    tangent_amplitude: DVec3,
    normal_amplitude: DVec3,
    omega: f64,
    slope_tan: f64,
    slope_cos: f64,
}
impl ScreenFrame {
    fn new(screen: &Screen) -> Self {
        let downstream=screen.downstream();
        let across=screen.across();
        let normal=screen.normal();
        Self { downstream, across, normal,
            tangent_amplitude:downstream*screen.config.amplitude_downstream_m,
            normal_amplitude:normal*screen.config.amplitude_normal_m,
            omega:std::f64::consts::TAU*screen.config.frequency_hz,
            slope_tan:screen.config.slope_deg.to_radians().tan(),
            slope_cos:screen.config.slope_deg.to_radians().cos(),
        }
    }
}''')
replace('            next_id: 0,','            next_id: 0,\n            frame: None,')
replace('''        DVec3::new((self.yaw as f64).sin(), 0., (self.yaw as f64).cos())''','''        self.frame.map_or_else(|| DVec3::new((self.yaw as f64).sin(), 0., (self.yaw as f64).cos()), |frame| frame.downstream)''')
replace('''        DVec3::new((self.yaw as f64).cos(), 0., -(self.yaw as f64).sin())''','''        self.frame.map_or_else(|| DVec3::new((self.yaw as f64).cos(), 0., -(self.yaw as f64).sin()), |frame| frame.across)''')
replace('''        (DVec3::Y + self.downstream() * self.config.slope_deg.to_radians().tan()).normalize()''','''        self.frame.map_or_else(|| (DVec3::Y + self.downstream() * self.config.slope_deg.to_radians().tan()).normalize(), |frame| frame.normal)''')
replace('''        let w = std::f64::consts::TAU * self.config.frequency_hz;
        let phase = w * if self.motor_on { time } else { self.time };
        let tangent = self.downstream() * self.config.amplitude_downstream_m;
        let normal = self.normal() * self.config.amplitude_normal_m;''','''        let frame=self.frame.unwrap_or_else(|| ScreenFrame::new(self));
        let w=frame.omega;
        let phase = w * if self.motor_on { time } else { self.time };
        let tangent = frame.tangent_amplitude;
        let normal = frame.normal_amplitude;''')
replace('''        next.last_step = ScreenStep::default();''','''        next.last_step = ScreenStep::default();
        next.frame = Some(ScreenFrame::new(&next));''')
replace('''        if !next.valid() {
            return Err("Screen postcondition refused; state retained".into());''','''        next.frame = None;
        if !next.valid() {
            return Err("Screen postcondition refused; state retained".into());''')
replace('''        (p.y + p.x * self.config.slope_deg.to_radians().tan())
            * self.config.slope_deg.to_radians().cos()''','''        let frame=self.frame.unwrap_or_else(|| ScreenFrame::new(self));
        (p.y + p.x * frame.slope_tan) * frame.slope_cos''')
replace('''        let q0 = sweep.start + sweep.delta * lo - self.offset_at(phase(lo)).0;''','''        let (offset0, velocity) = self.offset_at(phase(lo));
        let q0 = sweep.start + sweep.delta * lo - offset0;''')
replace('''        let velocity = self.offset_at(phase(lo)).1;
        if gap <= CONTACT_SKIN_M''','''        if gap <= CONTACT_SKIN_M''')
replace('''                        if let Some((u, normal)) = cast_triangle(start, end - start, *tri, r) {''','''                        if !triangle_bounds_overlap(start, end, *tri, r + 1e-12) { continue; }
                        if let Some((u, normal)) = cast_triangle(start, end - start, *tri, r) {''')
replace('''                let closest = triangle_closest(p.position, *t);''','''                if !triangle_bounds_overlap(p.position, p.position, *t, r + skin + 1e-12) { continue; }
                let closest = triangle_closest(p.position, *t);''')
replace('''fn triangle_closest(p: DVec3, t: [DVec3; 3]) -> DVec3 {''','''/// Conservative swept-sphere AABB rejection only; admitted triangles retain
/// the original exact narrowphase, contact ordering, skin and time policy.
fn triangle_bounds_overlap(start: DVec3, end: DVec3, t: [DVec3;3], radius: f64) -> bool {
    let pad=DVec3::splat(radius);
    let low=start.min(end)-pad;
    let high=start.max(end)+pad;
    !t[0].min(t[1]).min(t[2]).cmpgt(high).any()
        && !t[0].max(t[1]).max(t[2]).cmplt(low).any()
}
fn triangle_closest(p: DVec3, t: [DVec3; 3]) -> DVec3 {''')
replace('''    #[test]
    fn stack_contact_elimination_preserves_complete_pivoting()''','''    #[test]
    fn transaction_frame_keeps_exact_drive_geometry_and_is_not_saved() {
        for yaw in [0.,0.37,-1.2,3.1] {
            for slope in [0.,12.,25.] {
                let mut screen=Screen::new(Vec3::new(14.,2.,17.),yaw);
                screen.config.slope_deg=slope;
                screen.time=0.321;
                for motor in [false,true] {
                    screen.motor_on=motor;
                    let frame=ScreenFrame::new(&screen);
                    let plain=serde_json::to_value(&screen).unwrap();
                    for time in [0.,0.01,0.123,1.2,17.8] {
                        let drive=screen.offset_at(time);
                        let local=screen.to_local(DVec3::new(14.3,1.8,17.4));
                        let distance=screen.deck_distance(local);
                        screen.frame=Some(frame);
                        assert_eq!(drive,screen.offset_at(time));
                        assert_eq!(local,screen.to_local(DVec3::new(14.3,1.8,17.4)));
                        assert_eq!(distance,screen.deck_distance(local));
                        assert_eq!(plain,serde_json::to_value(&screen).unwrap());
                        screen.frame=None;
                    }
                }
            }
        }
    }
    #[test]
    fn triangle_broadphase_keeps_face_edge_corner_and_initial_overlap_hits() {
        let t=[DVec3::new(-1.,0.,-1.),DVec3::new(1.,0.,-1.),DVec3::new(0.,0.,1.)];
        let mut hits=0;
        for radius in [0.0001,0.01,0.2] {
            for x in -20..=20 {
                for z in -20..=20 {
                    let start=DVec3::new(x as f64/16.,0.3,z as f64/16.);
                    for delta in [DVec3::new(0.,-0.8,0.),DVec3::new(0.2,-0.3,-0.1)] {
                        if cast_triangle(start,delta,t,radius).is_some() {
                            hits+=1;
                            assert!(triangle_bounds_overlap(start,start+delta,t,radius+1e-12));
                        }
                    }
                    let closest=triangle_closest(start-DVec3::Y*0.3,t);
                    assert!(triangle_bounds_overlap(closest,closest,t,radius+1e-12));
                }
            }
        }
        assert!(hits>1000);
    }
    #[test]
    fn stack_contact_elimination_preserves_complete_pivoting()''')
p.write_text(s);print('Cached immutable drive basis and rejected only provably disjoint static triangles.')
