from pathlib import Path
import hashlib,json
w=Path.cwd();r=Path(__file__).parent;start=json.loads((r/'start.json').read_text());p=w/'crates/game/src/gpu/pressure_3d.rs';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()==start['sources']['crates/game/src/gpu/pressure_3d.rs']
helper=r'''// Optional transient dispatch data, never pressure or saved physical state.
struct ActiveBuffers {
    cells: wgpu::Buffer,
    arguments: wgpu::Buffer,
    arguments_pipeline: wgpu::ComputePipeline,
    arguments_group: wgpu::BindGroup,
}
impl ActiveBuffers {
    fn new(device: &wgpu::Device, count: usize) -> Option<Self> {
        let bytes = u64::try_from(count.checked_mul(2)?.checked_add(2)?.checked_mul(4)?).ok()?;
        let limits = device.limits();
        if limits.max_storage_buffers_per_shader_stage < 8
            || limits.max_compute_workgroup_size_x < 128
            || limits.max_compute_invocations_per_workgroup < 128
            || count.div_ceil(128) > limits.max_compute_workgroups_per_dimension as usize
            || bytes > limits.max_buffer_size
            || bytes > u64::from(limits.max_storage_buffer_binding_size)
        {
            return None;
        }
        let cells = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Pressure active counts and parity lists"),
            size: bytes,
            usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let arguments = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Pressure active indirect arguments"),
            size: 24,
            usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::INDIRECT,
            mapped_at_creation: false,
        });
        let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Pressure active argument construction"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: true },
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Storage { read_only: false },
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });
        let arguments_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Pressure active argument construction"),
            layout: &layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: cells.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: arguments.as_entire_binding() },
            ],
        });
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Pressure active argument construction"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/pressure_active_args.wgsl").into()),
        });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Pressure active argument construction"),
            bind_group_layouts: &[&layout],
            push_constant_ranges: &[],
        });
        let arguments_pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
            label: Some("Pressure active argument construction"),
            layout: Some(&pipeline_layout),
            module: &module,
            entry_point: Some("build_arguments"),
            compilation_options: Default::default(),
            cache: None,
        });
        Some(Self { cells, arguments, arguments_pipeline, arguments_group })
    }
}
struct ActivePressure {
    buffers: ActiveBuffers,
    prepare: wgpu::ComputePipeline,
    red: wgpu::ComputePipeline,
    black: wgpu::ComputePipeline,
}

'''
s=s.replace('impl GpuPressure3D {',helper+'impl GpuPressure3D {',1).replace('    pub cached_stencil: bool,','    pub cached_stencil: bool,\n    /// Dispatch only current fluid cells; dense paths remain available for validation.\n    pub active_cells: bool,\n    active: Option<ActivePressure>,',1)
s=s.replace('        // Create pressure bind group layout','        let active_buffers = ActiveBuffers::new(device, cell_count);\n\n        // Create pressure bind group layout',1)
a=s.index('        // Create pressure bind group layout');b=s.index('        // Create gradient bind group layout',a);old=s[a:b];first=old.index('entries: &[')+len('entries: &[');last=old.rindex('],');entries=old[first:last]
s=s[:a]+'''        // The optional lists add only one storage binding, retaining the
        // ordinary eight-storage-buffer device limit. Counts and indices share it.
        let mut pressure_layout_entries = vec!['''+entries+'''];
        if active_buffers.is_some() {
            pressure_layout_entries.push(wgpu::BindGroupLayoutEntry {
                binding: 8,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: false },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            });
        }
        let pressure_bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Pressure 3D Bind Group Layout"),
            entries: &pressure_layout_entries,
        });

'''+s[b:]
a=s.index('        let pressure_bind_group = device.create_bind_group');b=s.index('        let gradient_bind_group =',a);old=s[a:b];first=old.index('entries: &[')+len('entries: &[');last=old.rindex('],');entries=old[first:last]
s=s[:a]+'''        let mut pressure_entries = vec!['''+entries+'''];
        if let Some(active) = &active_buffers {
            pressure_entries.push(wgpu::BindGroupEntry { binding: 8, resource: active.cells.as_entire_binding() });
        }
        let pressure_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Pressure 3D Bind Group"),
            layout: &pressure_bind_group_layout,
            entries: &pressure_entries,
        });
        drop(pressure_entries);

'''+s[b:]
a=s.index('        Self {\n            compact_iterations: true,');s=s[:a]+'''        let active = active_buffers.map(|buffers| ActivePressure {
            buffers,
            prepare: pipeline(&pressure_shader, &pressure_pipeline_layout, "prepare_stencil_active"),
            red: pipeline(&pressure_shader, &pressure_pipeline_layout, "pressure_red_active"),
            black: pipeline(&pressure_shader, &pressure_pipeline_layout, "pressure_black_active"),
        });
'''+s[a:];s=s.replace('            cached_stencil: true,','            cached_stencil: true,\n            active_cells: true,\n            active,',1)
a=s.index('        if self.compact_iterations {',s.index('    pub fn encode_iterations_only_profiled('))
s=s[:a]+r'''        if self.compact_iterations && self.cached_stencil && self.active_cells {
            if let Some(active) = &self.active {
                // Rebuild from GPU-current flags for every density/velocity solve.
                // Unused old list entries are unreachable after these count resets.
                encoder.clear_buffer(&active.buffers.cells, 0, Some(8));
                {
                    let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                        label: Some("Build current pressure parity lists"),
                        timestamp_writes: timer.as_deref_mut().map(|timer| timer.pass(profile_label)),
                    });
                    pass.set_bind_group(0, &self.pressure_bind_group, &[]);
                    pass.set_pipeline(&active.prepare);
                    pass.dispatch_workgroups(workgroups_x, workgroups_y, workgroups_z);
                }
                {
                    let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                        label: Some("Build pressure indirect arguments"),
                        timestamp_writes: timer.as_deref_mut().map(|timer| timer.pass(profile_label)),
                    });
                    pass.set_bind_group(0, &active.buffers.arguments_group, &[]);
                    pass.set_pipeline(&active.buffers.arguments_pipeline);
                    pass.dispatch_workgroups(1, 1, 1);
                }
                // Arguments are not bound as storage in this pass. The preceding
                // pass must end before their indirect consumption (including zero).
                let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                    label: Some("Ordered active pressure sweeps"),
                    timestamp_writes: timer.as_deref_mut().map(|timer| timer.pass(profile_label)),
                });
                pass.set_bind_group(0, &self.pressure_bind_group, &[]);
                for _ in 0..iterations {
                    pass.set_pipeline(&active.red);
                    pass.dispatch_workgroups_indirect(&active.buffers.arguments, 0);
                    pass.set_pipeline(&active.black);
                    pass.dispatch_workgroups_indirect(&active.buffers.arguments, 12);
                }
                return;
            }
        }
'''+s[a:];p.write_text(s)
p=w/'crates/game/src/gpu/shaders/pressure_3d.wgsl';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()==start['sources']['crates/game/src/gpu/shaders/pressure_3d.wgsl'];anchor='\nfn neighbour_mask(id:vec3<u32>)->u32 {';assert s.count(anchor)==1
s=s.replace(anchor,r'''
// Counts[red, black], followed by two capacity-N linear-index lists. All
// integer ownership is transient; the existing per-cell solve is unchanged.
@group(0) @binding(8) var<storage,read_write> active_cells:array<atomic<u32>>;
@compute @workgroup_size(8,8,4)
fn prepare_stencil_active(@builtin(global_invocation_id) id:vec3<u32>) {
    if !is_valid(id.x,id.y,id.z) {return;}
    let idx=get_index(id.x,id.y,id.z);
    if cell_type[idx]!=CELL_FLUID {stencil[idx]=0u;return;}
    stencil[idx]=neighbour_mask(id);
    let colour=(id.x+id.y+id.z)&1u;
    let slot=atomicAdd(&active_cells[colour],1u);
    let stride=params.width*params.height*params.depth;
    atomicStore(&active_cells[2u+colour*stride+slot],idx);
}
fn solve_active(slot:u32,colour:u32) {
    if slot>=atomicLoad(&active_cells[colour]) {return;}
    let stride=params.width*params.height*params.depth;
    let idx=atomicLoad(&active_cells[2u+colour*stride+slot]);
    let id=vec3(idx%params.width,(idx/params.width)%params.height,idx/(params.width*params.height));
    solve_stencil(id);
}
@compute @workgroup_size(128)
fn pressure_red_active(@builtin(global_invocation_id) id:vec3<u32>) {solve_active(id.x,0u);}
@compute @workgroup_size(128)
fn pressure_black_active(@builtin(global_invocation_id) id:vec3<u32>) {solve_active(id.x,1u);}
''' + anchor,1);p.write_text(s)
p=w/'crates/game/src/gpu/shaders/pressure_active_args.wgsl';assert not p.exists();p.write_text('''// This pass ends before indirect reads. The arguments buffer is never bound\n// as storage during pressure iterations. Zero active cells yield zero groups.\n@group(0) @binding(0) var<storage,read> cells:array<u32>;\n@group(0) @binding(1) var<storage,read_write> arguments:array<u32>;\n@compute @workgroup_size(1)\nfn build_arguments() {\n    arguments[0]=(cells[0]+127u)/128u;\n    arguments[1]=1u;arguments[2]=1u;\n    arguments[3]=(cells[1]+127u)/128u;\n    arguments[4]=1u;arguments[5]=1u;\n}\n''')
print('Implemented current-cell parity lists with separate indirect-argument pass; original pressure equations and dense fallback retained.')
