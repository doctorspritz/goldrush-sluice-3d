from pathlib import Path
r=Path('/Users/simonheikkila/.codex/worktrees/direct-mining/the-sluice-moose');a=Path('/Users/simonheikkila/.codex/visualizations/2026/10/18/01a14ce3-309f-7782-9a7c-ccd0efaf3227/pressure-active-20261027')
p=r/'crates/game/src/gpu/shaders/pressure_3d.wgsl';s=p.read_text();(a/'pressure_3d.wgsl.v2').write_text(s)
s=s.replace('// Counts[red, black], followed by two capacity-N linear-index lists. All','// Counts[red, black], followed by two capacity-N packed-coordinate lists. All')
b=s.index('@compute @workgroup_size(8,8,4)\nfn prepare_stencil_active');e=s.index('@compute @workgroup_size(128)',b)
s=s[:b]+'''override ACTIVE_X_BITS:u32=0u;
override ACTIVE_Y_BITS:u32=0u;
var<workgroup> tile_counts:array<atomic<u32>,2>;
var<workgroup> tile_base:array<u32,2>;
@compute @workgroup_size(8,8,4)
fn prepare_stencil_active(@builtin(global_invocation_id) id:vec3<u32>,@builtin(local_invocation_index) lane:u32) {
    // Every lane participates, including outside a partial tile and air/solid.
    if lane==0u {
        atomicStore(&tile_counts[0],0u);
        atomicStore(&tile_counts[1],0u);
    }
    workgroupBarrier();
    var fluid=false;
    let colour=(id.x+id.y+id.z)&1u;
    var local_slot=0u;
    if is_valid(id.x,id.y,id.z) {
        let idx=get_index(id.x,id.y,id.z);
        fluid=cell_type[idx]==CELL_FLUID;
        if fluid {
            stencil[idx]=neighbour_mask(id);
            local_slot=atomicAdd(&tile_counts[colour],1u);
        } else {
            stencil[idx]=0u;
        }
    }
    workgroupBarrier();
    if lane==0u {
        for(var c=0u;c<2u;c+=1u) {
            let count=atomicLoad(&tile_counts[c]);
            tile_base[c]=0u;
            if count!=0u {tile_base[c]=atomicAdd(&active_cells.counts[c],count);}
        }
    }
    workgroupBarrier();
    if fluid {
        let stride=params.width*params.height*params.depth;
        let packed=id.x|(id.y<<ACTIVE_X_BITS)|(id.z<<(ACTIVE_X_BITS+ACTIVE_Y_BITS));
        active_cells.indices[colour*stride+tile_base[colour]+local_slot]=packed;
    }
}
fn solve_active(slot:u32,colour:u32) {
    if slot>=atomicLoad(&active_cells.counts[colour]) {return;}
    let stride=params.width*params.height*params.depth;
    let packed=active_cells.indices[colour*stride+slot];
    let id=vec3(packed&((1u<<ACTIVE_X_BITS)-1u),(packed>>ACTIVE_X_BITS)&((1u<<ACTIVE_Y_BITS)-1u),packed>>(ACTIVE_X_BITS+ACTIVE_Y_BITS));
    solve_stencil(id);
}
''' +s[e:];p.write_text(s)
p=r/'crates/game/src/gpu/pressure_3d.rs';s=p.read_text();(a/'pressure_3d.rs.v2').write_text(s)
s=s.replace('let active_buffers = ActiveBuffers::new(device, cell_count);','''let coordinate_bits = [width, height, depth].map(|n| u32::BITS - (n - 1).leading_zeros());
        let packed_coordinates_supported = coordinate_bits.iter().sum::<u32>() < 32;
        let active_buffers = packed_coordinates_supported
            .then(|| ActiveBuffers::new(device, cell_count))
            .flatten();
        let mut pressure_constants = mobility_constants.clone();
        for (name, bits) in ["ACTIVE_X_BITS", "ACTIVE_Y_BITS"].into_iter().zip(coordinate_bits) {
            pressure_constants.insert(name.to_string(), f64::from(if packed_coordinates_supported {bits} else {0}));
        }''')
# Only pressure shader pipelines get its coordinate overrides; gradient does not declare them.
b=s.index('let pipeline = |');e=s.index('let packed_red',b);part=s[b:e];assert 'constants: &mobility_constants' in part
s=s[:b]+part.replace('constants: &mobility_constants','constants: &pressure_constants')+s[e:];p.write_text(s)
