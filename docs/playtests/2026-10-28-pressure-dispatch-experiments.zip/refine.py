from pathlib import Path
w=Path.cwd();r=Path(__file__).parent;p=w/'crates/game/src/gpu/pressure_3d.rs';s=p.read_text();s=s.replace('    pub active_cells: bool,','    pub active_cells: bool,\n    /// Compare GPU-generated indirect arguments against a fixed upper-bound launch.\n    pub active_indirect: bool,',1).replace('            active_cells: true,','            active_cells: true,\n            active_indirect: std::env::var_os("SLUICE_PROFILE_ACTIVE_PRESSURE_INDIRECT").is_some(),',1)
a=s.index('                {\n                    let mut pass = encoder.begin_compute_pass',s.index('pass.dispatch_workgroups(workgroups_x, workgroups_y, workgroups_z);',s.index('if self.compact_iterations && self.cached_stencil && self.active_cells')));b=s.index('                // Arguments are not bound as storage',a);part=s[a:b];s=s[:a]+'                if self.active_indirect {\n'+part+'                }\n'+s[b:]
s=s.replace('''                    pass.dispatch_workgroups_indirect(&active.buffers.arguments, 0);
                    pass.set_pipeline(&active.black);
                    pass.dispatch_workgroups_indirect(&active.buffers.arguments, 12);''','''                    if self.active_indirect {
                        pass.dispatch_workgroups_indirect(&active.buffers.arguments, 0);
                    } else {
                        pass.dispatch_workgroups((self.width*self.height*self.depth).div_ceil(2).div_ceil(128), 1, 1);
                    }
                    pass.set_pipeline(&active.black);
                    if self.active_indirect {
                        pass.dispatch_workgroups_indirect(&active.buffers.arguments, 12);
                    } else {
                        pass.dispatch_workgroups((self.width*self.height*self.depth).div_ceil(2).div_ceil(128), 1, 1);
                    }''',1);p.write_text(s)
p=w/'crates/game/src/gpu/shaders/pressure_3d.wgsl';s=p.read_text().replace('@group(0) @binding(8) var<storage,read_write> active_cells:array<atomic<u32>>;','''struct ActiveCellData {
    counts:array<atomic<u32>,2>,
    indices:array<u32>,
}
@group(0) @binding(8) var<storage,read_write> active_cells:ActiveCellData;''').replace('atomicAdd(&active_cells[colour],1u)','atomicAdd(&active_cells.counts[colour],1u)').replace('atomicStore(&active_cells[2u+colour*stride+slot],idx);','active_cells.indices[colour*stride+slot]=idx;').replace('atomicLoad(&active_cells[colour])','atomicLoad(&active_cells.counts[colour])').replace('atomicLoad(&active_cells[2u+colour*stride+slot])','active_cells.indices[colour*stride+slot]');p.write_text(s)
p=w/'crates/mining-physics/tests/pressure_active.rs';s=p.read_text();s=s.replace('let make = |active|','let make = |active, indirect|').replace('                solver.active_cells = active;','                solver.active_cells = active;\n                solver.active_indirect = indirect;');s=s.replace('let dense = make(false);','let dense = make(false, false);').replace('let active = make(true);','let active = make(true, false);\n            let indirect = make(true, true);');s=s.replace('for solver in [&dense, &active]','for solver in [&dense, &active, &indirect]');a=s.index('                let b = read(');b=s.index('                comparisons += 1;',a)+len('                comparisons += 1;');old=s[a:b];new='''                for (name, candidate) in [("fixed", &active), ("indirect", &indirect)] {
'''+old.replace('&active.pressure_buffer','&candidate.pressure_buffer').replace('weighted{weighted} stage{stage}','weighted{weighted} {name} stage{stage}')+'\n                }';s=s[:a]+new+s[b:];s=s.replace('assert_eq!(comparisons, 56);','assert_eq!(comparisons, 112);');p.write_text(s)
print('Added separate fixed and indirect controls; only list counters use atomics, index storage is ordinary u32.')
