from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path(__file__).parent;checks=[]
def run(label,args,env=None):
 t=time.monotonic();p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],env=env,capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'exit':p.returncode,'args':args,'wall_seconds':time.monotonic()-t});(r/'trial-v3-checks.json').write_text(json.dumps(checks,indent=2));print(label,p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-4000:],flush=True);raise SystemExit(p.returncode)
run('build-active-v3',['cargo','+nightly','build','-p','mining-physics','--example','flow_probe','--profile','playable','--locked','--jobs','1']);(r/'candidate-v3').mkdir(exist_ok=True);p=r/'candidate-v3/mining';shutil.copyfile('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/playable/examples/flow_probe',p);p.chmod(0o755);(r/'candidate-v3-binary.json').write_text(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2));fixture=r.parent/'plant-screen-20261027/gpu-fixtures-v8/modern.save.json'
for variant,env in [('reference',None),('fixed',None),('indirect',{'SLUICE_PROFILE_ACTIVE_PRESSURE_INDIRECT':'1'}),('reference-last',None)]:
 binary=r/'reference/mining' if variant.startswith('reference') else r/'candidate-v3/mining'
 label=variant+'-device-v3';run(label,[str(binary),str(fixture),'60',str(r/(label+'.json')),'30'],{**os.environ,'SLUICE_PROFILE_GPU_TIMESTAMPS':'1',**(env or {})});j=json.loads((r/(label+'.json')).read_text());print(json.dumps({'variant':variant,'physical_ratio':j['simulation_wall_ratio'],'gpu':{n:v for n,v in j['gpu_device_stage_ms'].items() if n in ['Density pressure sweeps','Velocity pressure sweeps','G2P 3D Pass','P2G 3D Scatter Pass']}},indent=2),flush=True)
