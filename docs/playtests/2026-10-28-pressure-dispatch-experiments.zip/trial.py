from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path(__file__).parent;checks=[]
def run(label,args,env=None):
 t=time.monotonic();p=subprocess.run(['python3',str(r/'queued-run.py'),label,*args],env=env,capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr);checks.append({'label':label,'exit':p.returncode,'args':args,'wall_seconds':time.monotonic()-t});(r/'trial-checks.json').write_text(json.dumps(checks,indent=2));print(label,p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-6000:],flush=True);raise SystemExit(p.returncode)
run('build-active',['cargo','+nightly','build','-p','mining-physics','--example','flow_probe','--profile','playable','--locked','--jobs','1']);(r/'candidate').mkdir();p=r/'candidate/mining';shutil.copyfile('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/playable/examples/flow_probe',p);p.chmod(0o755);(r/'candidate-binary.json').write_text(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2));fixture=r.parent/'plant-screen-20261027/gpu-fixtures-v8/modern.save.json'
for variant in ['reference','candidate']:
 label=variant+'-probe';run(label,[str(r/variant/'mining'),str(fixture),'120',str(r/(label+'.json')),'30']);j=json.loads((r/(label+'.json')).read_text());print(json.dumps({'variant':variant,**{k:j[k] for k in ['simulation_wall_ratio','session_mean_ms','solver_mean_ms','timings_ms','gold_balance_error_g','whole_water_balance_error_m3']}},indent=2),flush=True)
for variant in ['reference','candidate']:
 label=variant+'-device';run(label,[str(r/variant/'mining'),str(fixture),'60',str(r/(label+'.json')),'30'],{**os.environ,'SLUICE_PROFILE_GPU_TIMESTAMPS':'1'});j=json.loads((r/(label+'.json')).read_text());print(json.dumps({'variant':variant,**{k:j[k] for k in ['simulation_wall_ratio','gpu_device_stage_ms']}},indent=2),flush=True)
