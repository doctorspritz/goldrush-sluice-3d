Maximum agent steps reached; no tools were used (task was read-only analysis, so nothing is left incomplete). The review:

**Correctness pitfalls**

1. **Parity mismatch (critical).** Current red cells are `x*2+((y+z)&1)` → parity `(x+y+z)&1`. The compaction shader must reproduce exactly this mapping; otherwise a sweep writes cells of the opposite color → intra-sweep races, wrong convergence.
2. **Flag/stencil coherence.** Lists built from live `CELL_FLUID` must agree with the `stencil` valid-bit (`0x80000000`). Rebuild lists and stencil in the same pass/order per solve, or a skipped/extra cell changes results vs. dense path.
3. **Count reset ordering.** Reset counts before the rebuild dispatch; within one compute pass dispatches are implicitly ordered, but a `write_buffer` reset must precede submission of the rebuild encoder.
4. **Indirect arg math.** Workgroup counts must be `div_ceil(count, workgroup_size)` with the *new* one-cell-per-thread mapping (dense used 2 cells/thread in x). Clamp to device dispatch limits — WebGPU drops invalid indirect dispatches, but older wgpu/backends had bugs; clamping in-shader is cheap insurance. Handle count==0 (legal no-op).
5. **Usage separation.** Args buffer needs `INDIRECT` usage; never bound as writable storage in the same pass — the proposed separate buffer + ended pass is correct. Verify offset/size (2×12 B, 4-byte aligned).

**Performance costs**

- One full-grid rebuild pass per solve (atomics, scattered appends) — amortized fine over 80 sweeps, but savings scale with fluid fraction; at >80% fluid expect parity with dense. Loss of 2-cells-per-thread x-compression adds gather overhead.
- Nondeterministic list order is fine (parity set is fixed), but don't rely on run-to-run bit equality for lists themselves.

**Discriminating tests**

1. Parity-equivalence: dense vs. list path, mixed/solid/open grids, `variable_mobility` both ways — pressures identical within ULP tolerance.
2. Stale-flag test: mutate cell types between solves; results must match dense rebuild-from-scratch.
3. Edge counts: zero fluid cells, odd/non-multiple-of-workgroup sizes, count exactly at capacity N.
4. Validation run: wgpu with validation/GPU debug enabled over thousands of solves — no usage conflicts, no device loss.
5. GPU-timer benchmark across fluid fractions (10/50/90%) and iteration counts vs. dense.

No remaining tasks.