from pathlib import Path
import shutil,subprocess
w=Path.cwd();r=Path(__file__).parent
shutil.copy2(r/'tailings.rs',w/'crates/mining-sim/src/tailings.rs')
p=w/'crates/mining-sim/src/lib.rs';s=p.read_text();s=s.replace('pub mod tracks;','pub mod tracks;\npub mod tailings;');p.write_text(s)
p=w/'crates/mining-sim/src/session.rs';s=p.read_text();old='    pub active_soil: Option<crate::soil::ActiveSoil>,\n';assert s.count(old)==1;s=s.replace(old,old+'    pub tailings: Option<crate::tailings::Tailings>,\n')
old='    active_soil: Option<crate::soil::ActiveSoil>,\n';assert s.count(old)==1;s=s.replace(old,old+'    #[serde(default, skip_serializing_if = "Option::is_none")]\n    tailings: Option<crate::tailings::Tailings>,\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    mechanical_version: Option<u32>,\n')
s=s.replace('            active_soil: None,','            active_soil: None,\n            tailings: None,',1)
pos=s.index('    pub fn near_plant(')
s=s[:pos]+'''    /// Current playable profile. `new` retains the existing laboratory/legacy
    /// format; the app's new shifts and demo use spatial discharge.
    pub fn new_operation() -> Self {
        let mut session=Self::new();
        session.enable_spatial_tailings().expect("empty new operation");
        session
    }
    /// Migrate a historical pooled pile only once, at its former visible
    /// location. Its discarded historical particle trajectories are unknown.
    pub fn enable_spatial_tailings(&mut self)->Result<(),String> {
        if self.tailings.is_some() {return Ok(());}
        let m=self.sluice.tailings;
        let mut t=crate::tailings::Tailings::default();
        if m.volume()>0. || m.gold_g>0. || m.pore_water_m3>0. {
            let p=self.sluice.placement.ok_or("Place the existing tailings pile before migration")?;
            let at=p.outlet()+p.forward()*0.8;
            self.site.receive_tailings(at,m,true)?;
            t.released=m;t.received=m;t.historic_bed=m;
            self.sluice.tailings=Material::default();
        }
        self.tailings=Some(t);Ok(())
    }
''' +s[pos:]
old='        let dt = FIXED_DT;\n        self.sim_time';assert s.count(old)==1;s=s.replace(old,'        let dt = FIXED_DT;\n        if let Some(t)=&mut self.tailings {\n            let exported=t.step(&mut self.site,dt);\n            self.water_balance.boundary_outflow_m3+=exported.pore_water_m3;\n        }\n        self.sim_time')
old='            + self.falling.iter().map(|l| l.material.gold_g).sum::<f64>()';s=s.replace(old,old+'\n            + self.tailings.as_ref().map_or(0.,|t|t.active_material().gold_g+t.exported.gold_g)',1)
old='        total\n    }\n    /// Finite terrain';assert old in s;s=s.replace(old,'        if let Some(t)=&self.tailings {total.add(t.active_material());total.add(t.exported);}\n        total\n    }\n    /// Finite terrain')
a=s.index('            version: if self.machine.bucket_model()');b=s.index('            site,',a);expression=s[a:b].removeprefix('            version: ').rstrip().removesuffix(',')
s=s[:a]+'''            version: if self.tailings.is_some() {12} else {mechanical_version},
            mechanical_version: self.tailings.as_ref().map(|_|mechanical_version),
            tailings: self.tailings.clone(),
'''+s[b:]
s=s.replace('    pub fn save_json(&self) -> Result<String, String> {','    pub fn save_json(&self) -> Result<String, String> {\n        let mechanical_version = '+expression+';',1)
a=s.index('    pub fn load_json(');head=s[:a];tail=s[a:];tail=tail.replace('s.version','version')
needle='        let s: Save = serde_json::from_str(json).map_err(|e| e.to_string())?;';assert needle in tail
tail=tail.replace(needle,needle+'''
        let version=if s.version==12 {
            if s.tailings.is_none() || s.water_balance.is_none() {return Err("Spatial save lacks tailings or water ownership".into());}
            s.mechanical_version.filter(|v|(6..=11).contains(v)).ok_or("Invalid spatial save mechanism version")?
        } else {
            if s.tailings.is_some() || s.mechanical_version.is_some() {return Err("Legacy save contains unsupported spatial tailings".into());}
            s.version
        };
        if s.tailings.as_ref().is_some_and(|t|!t.valid()) {return Err("Invalid spatial tailings state".into());}
''',1)
tail=tail.replace('        let carried_water = s\n','        let carried_water = s.tailings.as_ref().map_or(0.,|t|t.active_material().pore_water_m3) + s\n',1)
tail=tail.replace('            active_soil: s.active_soil,','            active_soil: s.active_soil,\n            tailings: s.tailings,',1)
tail=tail.replace('        self.site.water_volume_m3()\n','        self.tailings.as_ref().map_or(0.,|t|t.active_material().pore_water_m3) + self.site.water_volume_m3()\n',1)
s=head+tail;p.write_text(s)
p=w/'crates/mining-physics/src/lib.rs';s=p.read_text();needle='        let exit_domain = if self.grain_exit_capture.enabled() {';assert needle in s
s=s.replace(needle,'''        if let Some(t)=&mut s.tailings {
            let count=s.sluice.grains.iter().filter(|g|!in_domain(g.position)).count();
            t.prepare_batch(count)?;
            for g in s.sluice.grains.iter().filter(|g|!in_domain(g.position)) {
                mining_sim::tailings::world_grain(&s.sluice,g)?;
            }
        }
'''+needle,1)
old='''                s.sluice
                    .tailings
                    .add(s.sluice.grains.swap_remove(i).material);''';assert old in s
s=s.replace(old,'''                if let Some(t)=&mut s.tailings {
                    let g=mining_sim::tailings::world_grain(&s.sluice,&s.sluice.grains[i]).expect("preflighted exit");
                    t.accept(g);
                    s.sluice.grains.swap_remove(i);
                } else {
                    s.sluice.tailings.add(s.sluice.grains.swap_remove(i).material);
                }''',1);p.write_text(s)
for name in ['crates/mining/src/app.rs','crates/mining/src/demo.rs']:
 p=w/name;s=p.read_text().replace('Session::new()','Session::new_operation()')
 if name.endswith('demo.rs'):s=s.replace('    session.message =','    session.enable_spatial_tailings()?;\n    session.message =',1)
 p.write_text(s)
subprocess.run(['cargo','+nightly','fmt','-p','mining-sim','-p','mining-physics','-p','mining'],check=True)
print('Implemented spatial owner, actual exit handoff, modern save envelope and playable defaults.')
