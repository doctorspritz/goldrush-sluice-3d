from pathlib import Path
import json,subprocess,hashlib,shutil,zipfile
r=Path(__file__).parent;w=Path.cwd();s=json.loads((r/'start.json').read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==s['head']
quality=json.loads((r/'quality.json').read_text());assert all(q['exit']==0 for q in quality)
assert {q['name'] for q in quality}>={'gpu-tailings-v4','gpu-original','sim-lint','physics-lint-v2','app-tests-v2','app-lint','format','package'}
for name in ['cpu-tailings-final','cpu-worker','cpu-targets']:assert json.loads((r/(name+'.log.supervisor.json')).read_text())['exit']==0
assert json.loads((r/'cleanup.json').read_text())['exit']==0
assert json.loads((r/'installed-state-equality.json').read_text())['rgb_equal']
gpu=next(json.loads(line) for line in (r/'gpu-tailings-v4.log').read_text().splitlines() if line.startswith('{"actual_exit_records"'))
analysis=json.loads((r/'analysis.json').read_text());benchmarks={mode:json.loads((r/(mode+'-benchmark.json')).read_text()) for mode in ['before','after']}
assert all(not j['passed'] and j['bulk_budget_passed'] and j['dry_mass_budget_passed'] for j in benchmarks.values())
def bd(label,*args):
    p=subprocess.run(['bd','--sandbox',*args,'--json'],capture_output=True,text=True);(r/(label+'.stderr')).write_text(p.stderr);p.check_returncode();j=json.loads(p.stdout);(r/(label+'.json')).write_text(json.dumps(j,indent=2));return j
bd('tailings-qualified-notes','update','menace-sfu.1','--append-notes','Mineral/flight checkpoint qualified and installed: 10 focused tailings CPU checks, 6 worker checks, 77 app checks (2 optional profiles ignored), 2 real Metal regressions, selected strict lint and signed package pass. Actual 600-tick trial matches 383 complete exit records; bulk residual 4.72e-9 m3, dry mass 8.39e-6 kg, gold -6.37e-12 g, water 2.74e-7 m3. Native 139 samples plus 2 installed smoke frames; 918 sampled ballistic comparisons, max 9.37e-6 m positional discrepancy. Frozen water tracks/flow/surface/machine equal across all 6 old/new scene/view pairs. Qualified fixture 56.84 FPS / 0.59648x physical time; real time FAILS. Original demo migration removes fake pile and preserves historic gold owner. Independent downstream gold remains contact_pending, so this parent stays IN_PROGRESS; no calibrated runout/impact/scour, wet slumps, plant clogs, modules or full shift completion. Two broad legacy soil-suite attempts stopped at bounded 300s deadlines; completed subchecks pass, full suite is not passed. Evidence docs/playtests/2026-10-27-spatial-tailings.md.')
bd('shift-progress-notes','update','menace-sfu','--append-notes','27 October first integration boundary: playable spatial mineral tailings now change terrain/suspension, with saved full flight and explicit pending-gold contact custody. Signed app installed and scoped CPU/GPU/native gates pass; real time and complete shift remain open. menace-sfu.1 stays IN_PROGRESS for independent free-gold receiver menace-sfu.1.1. Next plant graph/first screen menace-sfu.2; expanded wet-ground/geology/plant/flood failure epic menace-9z3. Canonical plan preserves all user requirements; no isolated checkpoint completes this milestone.')
ids=['sluice-realistic-operation','menace-sfu','menace-sfu.1','menace-sfu.1.1','menace-sfu.2','menace-9z3'];before=(r/'issues-before.jsonl').read_bytes();existing={json.loads(line)['id']:json.loads(line) for line in before.splitlines()};owned={}
assert len(existing)==256
display={'parent','dependents','epic_total_children','epic_closed_children','epic_closeable'}
for id in ids:
    fresh=bd('final-'+id,'--readonly','show',id)[0];row=dict(existing.get(id,{}));row.update({k:v for k,v in fresh.items() if k not in display and k!='dependencies'})
    if 'dependencies' in fresh:row['dependencies']=[{'issue_id':id,'depends_on_id':d.get('depends_on_id',d.get('id')),'type':d.get('type',d.get('dependency_type'))} for d in fresh['dependencies']]
    owned[id]=row
lines=[]
for line in before.splitlines(keepends=True):
    id=json.loads(line)['id'];lines.append((json.dumps(owned[id],separators=(',',':'),ensure_ascii=False)+'\n').encode() if id in owned else line)
for id in sorted(set(owned)-set(existing)):lines.append((json.dumps(owned[id],separators=(',',':'),ensure_ascii=False)+'\n').encode())
out=b''.join(lines);assert len(out.splitlines())==260
assert [line for line in before.splitlines(keepends=True) if json.loads(line)['id'] not in owned]==[line for line in out.splitlines(keepends=True) if json.loads(line)['id'] not in owned]
assert all(owned[id]['status']=='in_progress' for id in ['sluice-realistic-operation','menace-sfu','menace-sfu.1'])
(w/'.beads/issues.jsonl').write_bytes(out);(r/'owned-tracker-rows.json').write_text(json.dumps(owned,indent=2))
source_manifest={str(p.relative_to(w)):h(p) for folder in ['crates','vendor','examples'] for p in (w/folder).rglob('*') if p.is_file() and p.suffix in ['.rs','.wgsl']}
changed=[name for name,old in s['sources'].items() if source_manifest.get(name)!=old];new=sorted(set(source_manifest)-set(s['sources']));assert len(new)==3
installed=json.loads((r/'installed.json').read_text())
receipt={'baseline_commit':s['head'],'source_manifest':source_manifest,'changed_sources':changed,'new_sources':new,'quality':quality,'final_focused_tests':{'tailings_cpu_passed':10,'worker_passed':6,'application_passed':77,'application_optional_ignored':2,'unique_real_gpu_tests_passed':2,'passed_total':95},'additional_earlier_cpu_support_checks':28,'partial_broad_cpu':{'first_deadline_seconds':300,'second_deadline_seconds':300,'completed_checks_in_twelve_binaries':181,'soil_cases_completed':['activation','bank scoop/hold/discharge','asymmetric tumbling','fast tumbling'],'incomplete_case_at_second_deadline':'delayed_operator_inputs_do_not_push_complete_clods_through_the_substrate','full_suite_passed':False},'gpu_trial':gpu,'native':analysis,'benchmarks':benchmarks,'installed':installed,'installed_equality':json.loads((r/'installed-state-equality.json').read_text()),'tracker':{'starting_rows':256,'ending_rows':260,'owned_ids':ids,'unrelated_raw_lines_preserved':254,'all_operation_parents_in_progress':True},'preservation':{'original_files':s['original_files'],'stash':s['stash'],'no_new_crash_reports':True,'cleanup':json.loads((r/'cleanup.json').read_text())},'empirically_calibrated':False,'downstream_free_gold_implemented':False,'wet_slump_and_plant_clog_models_implemented':False,'full_operation_complete':False}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2))
prefix='docs/playtests/2026-10-27-spatial-tailings';(w/(prefix+'.json')).write_bytes((r/'receipt.json').read_bytes())
for src,suffix in [('demo-outlet-comparison.jpg','-outlet.jpg'),('after-qualified-motion-sluice-contact.jpg','-sluice.jpg'),('after-qualified-motion-river-contact.jpg','-river.jpg')]:shutil.copyfile(r/src,w/(prefix+suffix))
doc='''# Spatial mineral tailings and the remaining full operation

Actual outgoing sluice grains now retain their complete world-space state and gravity flight. Gold-free packets enter the real terrain bed or water suspension at first contact. The old decorative pile is removed from new/demo operations. This is a usable mineral-discharge integration step; it does not complete tailings mechanics, independent downstream gold, plant modules, wet failures or the full playable shift.

## Ownership and compatibility

The reflected downstream/up/right grid basis transforms polar velocity and affine state with B, angular velocity with det(B)B, and proper grain rotation with BRBᵀ. Diameter, represented stock and pore water remain intact. Removal reserves the complete outgoing batch and validates every world packet before removing donors. A finite 65,536-packet numerical storage guard retains the full batch on refusal and allows saving; it is not a physical hopper or clogging law.

Flight resolves the first crossing of bilinear ground/water, split at grid boundaries. A quadratic root finds interior impacts even when both endpoints are clear. Boundary exits are explicit exports. Dry impacts use a four-node local receiving footprint and positive bed remainders; wet impacts enter existing class suspension. Raising the bed preserves free water, mobile inventory and horizontal water momentum. Cumulative release/receipt diagnostics are never counted again as inventory.

**Gold needs its own downstream model.** Review caught that existing terrain gold is class-3 paydirt provenance, whereas these mineral tailings use classes 0–2. Putting independent gold there could strand it. Gold-bearing packets therefore retain their complete first-contact state in saved `contact_pending` custody, counted once and omitted from simulated-motion rendering. They do not continue settling, advect, become recovered gold or support re-excavation. Pending contacts share the numerical storage bound. No fictitious mineral carrier is added. Follow-up `menace-sfu.1.1` must integrate water/contact, independent bed ownership, excavation, intake/export and cleanup before the tailings parent can close.

The version-12 envelope retains the validated inner mechanical version 6–11 plus flight/contact ownership. New/demo shifts enable it. A playable worker already in spatial mode migrates an older loaded shift before replacing current state; invalid migration retains the current shift. Direct laboratory `Session::new` and legacy loads preserve their existing policy. Historical pooled minerals are reconstructed once at the former visible pile location, preserving water and leaving historical gold in its original owner. Old particle trajectories and grading were discarded and cannot be reconstructed. This is explicit historical reconstruction, not observed old deposition.

## Verification

Ten focused tailings CPU checks, six worker checks, 77 application checks and two unique real-Metal regressions pass (95 final focused checks). Two optional application profiles remain ignored. Controls cover reflected motion, analytic/refined flight at 30/60/240 Hz, interior ridge contact, wet/dry handoff, sub-ULP bed/water custody, numerical admission refusal, first-contact gold retention, exact saved continuation, inner mechanical guards, legacy policy and migration refusal. Selected strict Clippy, changed-package formatting, signed packaging and installed smoke pass. The dependency `game` still emits its existing dead-code warning during Cargo commands; this is not a warning-free whole-workspace gate.

The actual 600-tick GPU run records **383 complete exit callbacks**, matches every admitted world packet field, restores live flight and continues 1,200 sluice solver steps. It receives 0.000518017992983198 m³ of mineral stock, with bulk residual 4.720106971944915e-9 m³, dry-mass residual 8.391914889216423e-6 kg, gold residual -6.366462912410498e-12 g and water residual 2.738987046058128e-7 m³. This short trial discharges soil; it does not establish downstream gold or gravel kinetics. The existing original excavation/pump/camera/live-restore GPU regression also passes.

An additional 28 soil-water, subgrid-bed, track and water controls passed earlier in the stage. Two broader serial CPU attempts hit their unchanged 300-second supervision deadlines. Twelve completed binaries pass 181 checks; activation, bank scoop/hold/discharge and two tumbling cases complete. The delayed-input soil case and remaining broad-suite work are incomplete. **The full CPU suite is not passed.** No crash report accompanied either deadline; no retry loop or resource-limit relaxation was used.

## Native inspection and throughput

Reviewed five motion contact sheets and six paired frozen scene/view comparisons: 139 native samples across the original demo, a finite GPU-qualified shift, outlet, sluice and river. Each capture passes its inventory checks. The 918 matched sampled flight transitions agree with ballistic continuation to 9.369526553479908e-6 m position and 5.584023892168943e-7 m/s velocity. Those checks establish flight, not post-impact drag/contact dynamics. Two installed smoke frames match qualified candidate physical fields and RGB exactly.

All six frozen comparisons preserve water tracks, flow metrics, surface samples and machine state exactly. The three qualified-fixture views and demo river RGB are exact. Demo outlet/sluice pixels change where the fake pile and reconstructed terrain differ. The paired qualified saves retain identical site/sluice state except destination inventory: the old app receives active flight stock in its old pool because it cannot read version 12. Their whole endpoint policies are therefore not identical.

| Paired finite-shift benchmark | Previous app | Spatial mineral tailings |
|---|---:|---:|
| Render FPS | 57.42 | 56.84 |
| Physical seconds / wall second | 0.58980 | 0.59648 |
| Real-time acceptance | Fail | Fail |

Both 20-second measured runs (after five-second warmup) pass material, dry-mass, gold and water budgets. Sluice water residual is zero in the candidate. One pair does not establish a speedup. The older dense-demo benchmark from the carrier stage is a different workload and is not this comparison. Existing water appearance remains provisional; brown sheets/crest optics and terrain edges are not fixed by this stage. No new manual driving, placement or complete mining/processing replay is claimed.

![Default demo: previous decorative pile and new actual mineral ownership](2026-10-27-spatial-tailings-outlet.jpg)

![Native sluice motion samples](2026-10-27-spatial-tailings-sluice.jpg)

![Native river motion samples](2026-10-27-spatial-tailings-river.jpg)

## Remaining physical and gameplay work

Jet/air drag, solid/water impact momentum coupling, shape contact/runout, repose, compaction, size-resolved downstream grains, re-entrainment and independent gold remain unqualified. The terrain receiver uses its existing coarse material classes after first impact. This is not a validated tailings-pile stability, blocked-outlet, wet-soil or pond-failure model.

The canonical operation plan now includes the user's additional requirements: wet slumps and inaccessible pay, bogging/recovery, deep-cut collapse, uncertain surveys of varying finite deposits, wet-feed hopper/chute bridging or plugging and screen blinding, berm breach/overtopping, unstable/obstructive tailings, plant malfunctions and floods washing out bridges. Moisture response must depend on material and geometry, with actual drainage/clearing/repair and saved stocks; these models are not implemented by this checkpoint. They are tracked in `menace-9z3`. Persisted plant modules/first screen are `menace-sfu.2`. Parents `menace-sfu.1`, `menace-sfu` and the full operation epic remain in progress.

The full [operation acceptance plan](../../plans/2026-10-22-realistic-operation.md) still requires stripping, separate spoil/pay stocks, haulage, both screen types, physical modifications/upgrades, sluice loading/clogging and gold washout, constructed ponds/recirculation, cleanup and continuation. No unfinished stage is closed here.

## Reproduce and evidence

Use one heavy job at a time with Cargo `--jobs 1` and tests `--test-threads=1`. Run `cargo +nightly test -p mining-sim --test tailings --profile playable --locked --jobs 1 -- --test-threads=1`, the `mining-physics` library `worker::tests`, and the ignored `spatial_tailings` integration test with an actual Metal/Vulkan adapter. Set `SLUICE_TAILINGS_OUTPUT` to a nonexistent directory to emit matched modern/legacy endpoint fixtures. Replay that modern save with the app's ordinary `--load`, `--capture-motion` and `--capture-view` options; use `--freeze` for fixed physical-state comparisons. Do not substitute rendered FPS for physical throughput.

The [receipt](2026-10-27-spatial-tailings.json) records all source fingerprints, gates, benchmark reports, native comparisons, install/backup identity and limitations. The [compressed evidence](2026-10-27-spatial-tailings-reports.zip) includes qualified input saves, final changed sources, native records, checks, historical failed attempts and capture sheets. The previous complete signed bundle is retained in the receipt's backup location. Required cleanup reports no browser/test/Playwright processes and four unrelated Node processes left untouched. Original nine dirty files and stash remain exact; no new panic/WindowServer diagnostic appears. Only six owned tracker rows change; 254 unrelated raw lines remain literal. Commit/push identity is recorded separately in the stage artifact landing receipt.
'''
(w/(prefix+'.md')).write_text(doc)
p=w/'plans/2026-10-22-realistic-operation.md';text=p.read_text().replace('Aggregate tailings custody exists; spatial deposition/stacking and integrated discharge equipment are missing.','Spatial mineral flight/terrain and suspension receipt are integrated. Gold-bearing packets retain pending-contact custody; independent downstream gold, stacking/runout, instability and discharge equipment remain incomplete.')
text+='\n27 October: the [spatial mineral-tailings checkpoint](../docs/playtests/2026-10-27-spatial-tailings.md) connects actual sluice exits to saved world flight and conservative local bed/suspension receipt. It preserves complete gold-bearing first-contact packets rather than stranding them in the terrain paydirt-tag model. Ten CPU, six worker, 77 app and two real-GPU checks pass; 139 native samples and installed equality pass. Native 56.84 FPS / 0.59648x physical time remains below real time. Independent downstream gold (`menace-sfu.1.1`), modules/first screen (`menace-sfu.2`), wet-ground/plant/flood incidents (`menace-9z3`) and the full shift remain open; no parent operation issue closes.\n';p.write_text(text)
p=w/'docs/physics/accuracy.md';text=p.read_text();text+='\nThe [spatial mineral-tailings integration](../playtests/2026-10-27-spatial-tailings.md) preserves full world exit state, resolves first contact and transfers gold-free mineral stock to existing terrain classes with conservative bed/water bookkeeping. Those classes are not a size-resolved downstream grain model. Because terrain gold is a paydirt provenance tag, independent gold-bearing exits retain explicit saved contact custody until a real downstream gold owner/dynamics/receiver is integrated. No gold carrier is invented, and pending contact is not recovery, continued settling or re-excavation. Runout/shape/impact coupling, wet instability and empirical qualification remain open. The same operation plan now explicitly includes wet-ground slumps, bogging, deep-cut collapse, uncertain surveys, wet-feed plugging/screen blinding, pond berm breach, plant failure and flood/bridge damage; the current dry mechanics and partial tailings do not implement those systems.\n';p.write_text(text)
archive=w/(prefix+'-reports.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in [*changed,*new]:z.write(w/name,'source/'+name)
    for p in r.glob('*.json'):
        if p.stat().st_size<12_000_000:z.write(p,'stage/'+p.name)
    for p in r.glob('*.py'):z.write(p,'reproduce/'+p.name)
    for p in r.glob('*.log'):z.write(p,'logs/'+p.name)
    for p in r.glob('*/*.json'):
        if p.parent.name in ['gpu-fixtures-v4','installed-smoke'] or p.name=='frames.json':z.write(p,str(p.relative_to(r)))
    for p in r.glob('*-contact.jpg'):z.write(p,p.name)
    for p in r.glob('*-comparison.jpg'):z.write(p,p.name)
print(json.dumps({'changed_sources':changed,'new_sources':new,'source_count':len(source_manifest),'archive_bytes':archive.stat().st_size,'tracker_rows':260,'final_focused_passed':95},indent=2))
