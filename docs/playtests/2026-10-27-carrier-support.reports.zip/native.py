from pathlib import Path
import subprocess,os,json,time,sys,re,hashlib
r=Path(__file__).parent
fixture=r.parent/'storage-final-2026-10-23/grown.json.save.json'
before=Path('/Users/simonheikkila/Documents/12-Coding/the-sluice-moose/target/bundles/First Bend.app/Contents/MacOS/mining')
after=r/'app/First Bend.app/Contents/MacOS/mining'
checks=[]
def run(name,app,args,expected=0):
 roots=[]
 for line in subprocess.check_output(['ps','-axo','pid=,comm=,args='],text=True).splitlines():
  a=line.strip().split(None,2)
  if len(a)==3 and (Path(a[1]).name in ['cargo','rustc','slurry-transport-after','mining'] or (Path(a[1]).name=='chrome-headless-shell' and '--type=' not in a[2])):roots.append({'pid':a[0],'name':Path(a[1]).name})
 assert len(roots)<2,roots
 command=['python3',str(r/'supervise.py'),'--seconds','100','--log',str(r/(name+'.log')),'--',str(app),'--load',str(fixture),*args]
 env={**os.environ,'SLUICE_SAVE_PATH':str(r/(name+'-unused.json'))}
 started=time.monotonic();p=subprocess.run(command,env=env,capture_output=True,text=True)
 (r/(name+'-driver.log')).write_text(p.stdout+p.stderr)
 row={'name':name,'command':command,'exit':p.returncode,'expected_exit':expected,'wall_seconds':time.monotonic()-started,'existing_heavy_roots':roots};checks.append(row);(r/'native-checks.json').write_text(json.dumps(checks,indent=2));print({k:v for k,v in row.items() if k not in ['command','existing_heavy_roots']},flush=True)
 if p.returncode!=expected:print(p.stdout[-5000:]);raise SystemExit(p.returncode or 99)
for mode,app in [('before',before),('after',after)]:
 for view in ['sluice','outlet','river']:
  name=mode+'-frozen-'+view
  run(name,app,['--freeze','--capture-motion',str(r/name),'--capture-view',view,'--capture-seconds','1','--capture-hz','2'])
 for view in (['sluice'] if mode=='before' else ['sluice','outlet','river']):
  name=mode+'-motion-'+view
  run(name,app,['--capture-motion',str(r/name),'--capture-view',view,'--capture-seconds','6','--capture-hz','10'])
 name=mode+'-benchmark'
 run(name,app,['--flow-benchmark',str(r/(name+'.json')),'--benchmark-seconds','20'],expected=1)
