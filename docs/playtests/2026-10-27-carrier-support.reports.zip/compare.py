from pathlib import Path
import json,hashlib,subprocess,collections
r=Path(__file__).parent;old=r.parent/'fine-pulse-20261027/final';cases=['bare_low','bare_nominal','bare_high','riffles_low','riffles_nominal','riffles_high']
def canonical(j):
 for name in ['spheres','planes','sdf']:j['sluice']['contacts'][name].sort(key=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')))
 return json.dumps(j,sort_keys=True,separators=(',',':')).encode()
identity=[]
for case in cases:
 a=canonical(json.loads((old/(case+'-warm')/'state.save.json').read_text()));b=canonical(json.loads((r/'after'/(case+'-warm')/'state.save.json').read_text()))
 row={'case':case,'complete_canonical_state_equal':a==b,'before_sha256':hashlib.sha256(a).hexdigest(),'after_sha256':hashlib.sha256(b).hexdigest()};identity.append(row)
 assert a==b,row
(r/'water-identity.json').write_text(json.dumps(identity,indent=2))
subprocess.run(['python3',str(r/'analyse.py'),str(r/'after')],check=True)
comparison=[];masks=collections.Counter();exits=[]
for case in cases:
 for order in [2,4,6]:
  a=json.loads((old/(case+'-q'+str(order))/'report.json').read_text());b=json.loads((r/'after'/(case+'-q'+str(order))/'report.json').read_text())
  assert a['initial_pulse']==b['initial_pulse']
  for i,d in enumerate(b['initial_pulse']['diameters_m']):
   initial=b['initial_per_bin_solid_m3'][i]
   comparison.append({'case':case,'order':order,'diameter_um':round(d*1e6),'before_exit_fraction':a['cumulative_all_boundary_exit_m3'][i]/initial,'after_exit_fraction':b['cumulative_all_boundary_exit_m3'][i]/initial,'delta_percentage_points':100*(b['cumulative_all_boundary_exit_m3'][i]-a['cumulative_all_boundary_exit_m3'][i])/initial})
  for e in b['exit_events']:masks[str(e['faces'])]+=1;exits.append(e)
(r/'before-after.json').write_text(json.dumps({'water_identity':identity,'fixed_initial_pulse_exact':True,'comparisons':comparison,'exit_records':len(exits),'exit_face_counts':dict(masks),'minimum_exit_x_m':min(e['position_m'][0] for e in exits),'prelip_records':sum(e['position_m'][0]<1.5 for e in exits)},indent=2))
print(json.dumps({'warm_states_exact':len(identity),'pulse_cases':18,'exit_records':len(exits)}))
