from pathlib import Path
import subprocess,sys,json,time,re,hashlib
r=Path(__file__).parent;binary=r/'slurry-transport-after';results=[]
def room(label):
 parents={};commands={};names={}
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,comm='],text=True).splitlines():
  a=line.strip().split(None,2)
  if len(a)==3:parents[int(a[0])]=int(a[1]);names[int(a[0])]=Path(a[2]).name
 for line in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
  a=line.strip().split(None,1)
  if len(a)==2:commands[int(a[0])]=a[1]
 heavy=set()
 for pid,name in names.items():
  args=commands.get(pid,'')
  if name in ['cargo','rustc','slurry-transport','slurry-transport-final','slurry-transport-after','mining'] or (name=='chrome-headless-shell' and '--type=' not in args) or (name in ['node','nodejs'] and re.search(r'(vitest|playwright[^ ]* test|next[ /]build|storybook)',args)):
   heavy.add(pid)
 roots=[]
 for pid in sorted(heavy):
  ancestor=parents.get(pid,0);seen=set();child=False
  while ancestor and ancestor not in seen:
   if ancestor in heavy:child=True;break
   seen.add(ancestor);ancestor=parents.get(ancestor,0)
  if not child:roots.append({'pid':pid,'name':names[pid],'command':commands.get(pid,'')})
 (r/(label+'-processes.json')).write_text(json.dumps(roots,indent=2))
 if len(roots)>=2:raise SystemExit('Two existing heavy jobs; no trial launched')
def run(label,args):
 label='after-'+label;room(label);began=time.monotonic();p=subprocess.run(['python3',str(r/'supervise.py'),'--seconds','150','--log',str(r/(label+'.log')),'--',str(binary),*map(str,args)],capture_output=True,text=True);(r/(label+'-driver.log')).write_text(p.stdout+p.stderr)
 output=Path(args[2]);report=json.loads((output/'report.json').read_text()) if (output/'report.json').exists() else None
 result={'label':label,'command':[str(binary),*map(str,args)],'exit':p.returncode,'wall_seconds':time.monotonic()-began,'report':str(output/'report.json'),'passed':report and report.get('passed')};results.append(result);(r/'after-trials.json').write_text(json.dumps(results,indent=2));print({k:result[k] for k in ['label','exit','wall_seconds','passed']},flush=True)
 if p.returncode or not report or not report.get('passed'):print(p.stdout[-6500:]);raise SystemExit(p.returncode or 1)
for case in ['riffles_nominal','bare_nominal','riffles_low','bare_low','riffles_high','bare_high']:
 warm=r/'after'/(case+'-warm');run(case+'-warm',['warm',case,warm,8])
 for order in [2,4,6]:run(case+'-q'+str(order),['pulse',warm,r/'after'/(case+'-q'+str(order)),order,8])
