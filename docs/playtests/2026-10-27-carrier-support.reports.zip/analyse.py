from pathlib import Path
import json,csv,math,subprocess,sys
r=Path(__file__).parent;folder=Path(sys.argv[1]) if len(sys.argv)>1 else r;rows=[];runs=[];comparisons=[]
for case in ['bare_low','bare_nominal','bare_high','riffles_low','riffles_nominal','riffles_high']:
 selected=[]
 for order in [2,4,6]:
  p=folder/(case+'-q'+str(order))/'report.json';j=json.loads(p.read_text());assert j['passed'] and j['custody_passed'];runs.append(j);selected.append(j)
  for i,b in enumerate(j['final_observation']['resident']['bins']):
   initial=j['initial_per_bin_solid_m3'][i];centroid=b['centroid_m'];cov=b['covariance_m2']
   row={'case':case,'order':order,'initial_parcels':j['initial_pulse']['parcels'],'diameter_um':round(b['diameter_m']*1e6),'initial_solid_m3':initial,'resident_fraction':b['solid_volume_m3']/initial,'all_face_exit_fraction':j['cumulative_all_boundary_exit_m3'][i]/initial,'positive_x_only_exit_fraction':j['cumulative_positive_x_only_exit_m3'][i]/initial,'restricted_resident_integral_s':j['restricted_resident_integral_s'][i],'conditional_observed_exit_time_s':j['conditional_mean_observed_exit_time_s'][i],'physical_seconds':j['physical_seconds'],'wall_seconds':j['wall_seconds'],'actual_delivered_Lps':j['delivered_external_water_m3']/j['physical_seconds']*1000,'contact_overlap_pairs':j['initial_pulse']['support']['overlapping_contact_pairs'],'max_pulse_relative_closure':j['maximum_pulse_relative_closure'],'max_independent_tailings_relative_error':j['maximum_relative_independent_tailings_error']}
   cohort_events=[e for e in j['exit_events'] if e['cohort_bin']==i]
   row['post_lip_boundary_exit_fraction']=sum(e['solid_volume_m3'] for e in cohort_events if e['position_m'][0]>=1.5)/initial
   row['pre_lip_boundary_exit_fraction']=sum(e['solid_volume_m3'] for e in cohort_events if e['position_m'][0]<1.5)/initial
   for flag in ['wet_moving','dry_moving','resting']:row[flag+'_fraction']=b[flag]['solid_volume_m3']/initial
   for axis in range(3):
    row['centroid_'+str(axis)+'_m']=centroid[axis] if centroid else None
    for other in range(3):row['covariance_'+str(axis)+str(other)+'_m2']=cov[axis][other] if cov else None
   rows.append(row)
   data=[]
   for v in j['series']:
    a=v['resident']['bins'][i];c=a['centroid_m'];cv=a['covariance_m2'];data.append([v['time_s'],a['solid_volume_m3']/initial,c[0] if c else float('nan'),math.sqrt(max(0,cv[0][0])) if cv else float('nan')])
   (r/(case+'-q'+str(order)+'-d'+str(i)+'.dat')).write_text('\n'.join(' '.join(map(str,a)) for a in data)+'\n')
 for i in range(3):
  fractions=[j['cumulative_all_boundary_exit_m3'][i]/j['initial_per_bin_solid_m3'][i] for j in selected]
  comparisons.append({'case':case,'diameter_um':round(selected[0]['initial_pulse']['diameters_m'][i]*1e6),'exit_fractions_q2_q4_q6':fractions,'spread_percentage_points':100*(max(fractions)-min(fractions)),'q4_q6_difference_percentage_points':100*abs(fractions[2]-fractions[1])})
with (r/'summary.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
summary={'runs':len(runs),'physical_pulse_seconds':sum(j['physical_seconds'] for j in runs),'maximum_pulse_relative_closure':max(j['maximum_pulse_relative_closure'] for j in runs),'maximum_tailings_relative_error':max(j['maximum_relative_independent_tailings_error'] for j in runs),'maximum_whole_water_error_m3':max(j['water_budget']['maximum_finite_abs_whole_error_m3'] for j in runs),'maximum_local_water_error_m3':max(j['water_budget']['maximum_finite_abs_sluice_error_m3'] for j in runs),'contact_overlaps_by_order':{str(j['initial_pulse']['quadrature_order']):j['initial_pulse']['support']['overlapping_contact_pairs'] for j in runs},'comparisons':comparisons,'summary_rows':rows}
(r/'analysis.json').write_text(json.dumps(summary,indent=2));(r/'raw-reports.json').write_text(json.dumps(runs,separators=(',',':')))
for metric,column,label in [('retention',2,'Resident quartz fraction'),('spread',4,'Resident streamwise standard deviation (m)')]:
 script=['set terminal pngcairo size 1600,900 font "Arial,12"','set output '+json.dumps(str(r/(metric+'.png'))),'set datafile missing "nan"','set multiplot layout 2,3 rowsfirst title "Nominal 3.75 L/s - fixed-mass quartz pulse; weighted-parcel refinement"','set xlabel "Seconds after pulse"','set ylabel '+json.dumps(label),'set xrange [0:8]','set grid','set key bottom left','set linetype 1 lc rgb "#0072B2" lw 2','set linetype 2 lc rgb "#D55E00" lw 2','set linetype 3 lc rgb "#009E73" lw 2']
 if metric=='retention':script+=['set yrange [0:1.04]']
 for case in ['bare_nominal','riffles_nominal']:
  for i,diameter in enumerate([47,97,173]):
   script+=['set title '+json.dumps(('Bare channel' if case.startswith('bare') else 'Riffles')+' / '+str(diameter)+' um')]
   script+=['plot '+', '.join(json.dumps(str(r/(case+'-q'+str(q)+'-d'+str(i)+'.dat')))+' using 1:'+str(column)+' with lines lt '+str(n+1)+' title "'+str(3*q**3)+' parcels"' for n,q in enumerate([2,4,6]))]
 script+=['unset multiplot'];path=r/(metric+'.gnuplot');path.write_text('\n'.join(script)+'\n');subprocess.run(['gnuplot',str(path)],check=True)
print(json.dumps({k:v for k,v in summary.items() if k not in ['comparisons','summary_rows']},indent=2));print(json.dumps(sorted(comparisons,key=lambda j:j['q4_q6_difference_percentage_points'],reverse=True)[:6],indent=2))
