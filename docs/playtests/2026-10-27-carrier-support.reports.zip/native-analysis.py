from pathlib import Path
from PIL import Image,ImageDraw,ImageOps
import json,math
r=Path(__file__).parent;rows=[]
crops={'sluice':(360,260,1430,790),'outlet':(650,180,1180,790),'river':(0,190,1120,780)}
for name in ['before-motion-sluice','after-motion-sluice','after-motion-outlet','after-motion-river']:
 j=json.loads((r/name/'frames.json').read_text());frames=j['frames'];assert j['passed'];view=name.split('-')[-1]
 stats={'name':name,'passed':j['passed'],'frames':len(frames),'physical_span_s':frames[-1]['sim_time']-frames[0]['sim_time'],'wall_span_s':frames[-1]['wall']-frames[0]['wall'],'worker_advancing_intervals':sum(b['solver_steps']>a['solver_steps'] for a,b in zip(frames,frames[1:])),'presentation_advancing_intervals':sum(b['presentation']['presented_sim_time']>a['presentation']['presented_sim_time'] for a,b in zip(frames,frames[1:])),'presentation_regressions':sum(b['presentation']['presented_sim_time']<a['presentation']['presented_sim_time'] for a,b in zip(frames,frames[1:])),'buffer_underrun_frames':j['water_presentation']['buffer_underrun_frames'],'sheets':[]}
 assert stats['worker_advancing_intervals']>0 and stats['presentation_advancing_intervals']>0 and stats['presentation_regressions']==0
 for page in range(math.ceil(len(frames)/30)):
  sheet=Image.new('RGB',(1920,1040),'#17201d');draw=ImageDraw.Draw(sheet)
  for local,f in enumerate(frames[page*30:(page+1)*30]):
   i=page*30+local;x=(local%6)*320;y=(local//6)*208;im=Image.open(r/name/f['file']).convert('RGB').crop(crops[view]);im=ImageOps.contain(im,(318,180));sheet.paste(im,(x+(320-im.width)//2,y));draw.text((x+5,y+183),f"#{i} wall {f['wall']:.2f} / sim {f['sim_time']:.3f}",fill='white')
  target=f'{name}-{page+1}.jpg';sheet.save(r/target,quality=88);stats['sheets'].append(target)
 rows.append(stats)
(r/'motion-analysis.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
